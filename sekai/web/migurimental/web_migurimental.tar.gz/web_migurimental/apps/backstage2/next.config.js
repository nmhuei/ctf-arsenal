module.exports = {
  assetPrefix: '/cdn',
}
