
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "mat.h"
#define N  64
#define M  164
#define Q  12289
#define beta 10


struct matrix *A;
struct vec32 *secret_vec;
struct vec32 *salt;
struct vec64 *flag_hash;



struct vec32 *generate_secret() {
  secret_vec = generate_random_vector(MatCols(A));
  vec32_mod(secret_vec, beta);
  return secret_vec;
}

struct vec32 *hash_single(struct vec32 *msg) {
  struct vec64 *res = create_vec64(MatRows(A));

  mat_mul(res, A, msg);
  vec64_mod(res, Q);
  struct vec32 *result = vec64_to_vec32(res);
  free_vec64(res);
  return result;
}
struct vec32 **multi_hash(size_t n, struct vec32 **msgs) {
  struct matrix *B = create_matrix(MatCols(A), n);
  for (size_t i = 0; i < n; i++) {
    mat_insert_column(B, msgs[i], i);
  }

  struct matrix *B_t = transpose_matrix(B);
  struct matrix *A_t = transpose_matrix(A);
  struct matrix *tmp = create_matrix(MatRows(B_t), MatCols(A_t));
  for (size_t col = 0; col < MatCols(A_t); col++) {
    struct vec32 *a_col = mat_get_col(A_t, col);
    struct vec64 *acc = create_vec64(MatRows(B_t));
    mat_mul(acc, B_t, a_col);
    vec64_mod(acc, Q);
    struct vec32 *acc32 = vec64_to_vec32(acc);
    mat_insert_column(tmp, acc32, col);
    free_vec32(a_col);
    free_vec64(acc);
    free_vec32(acc32);
  }
  struct matrix *res_mat = transpose_matrix(tmp);

  struct vec32 **results = malloc(n * sizeof(struct vec32 *));
  for (size_t i = 0; i < n; i++) {
    results[i] = mat_get_col(res_mat, i);
    vec32_mod(results[i], Q);
  }

  free_matrix(B);
  free(B);
  free_matrix(B_t);
  free(B_t);
  free_matrix(A_t);
  free(A_t);
  free_matrix(tmp);
  free(tmp);
  free_matrix(res_mat);
  free(res_mat);

  return results;
}



void setup_challenge() {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);
  A = create_matrix(N, M);
  generate_random_matrix(A);
  matrix_mod(A, Q);
generate_secret();
  if (secret_vec == NULL) {
    printf("failed to read flag, exiting\n");
    exit(1);
  }
  flag_hash = create_vec64(MatRows(A));

  // not performance critical, so we can use the naive version
  mat_mul_naive(flag_hash, A, secret_vec);
  vec64_mod(flag_hash, Q);
}
struct vec32 *read_vect(size_t n) {
  printf("would you like try our secret sauce ?? [y/n]: ");
  char c;
  if (scanf(" %c", &c) != 1 || (c == 'y' || c == 'Y')) {
    struct vec32 *v = create_vec32(n);
    for (size_t i = 0; i < n; i++) {
      Vec(v, i) = Vec(secret_vec, i);
    }
    return v;
  }
  struct vec32 *vec = create_vec32(n);
  printf("then throw in your [%zu] own supplies if you dont like ours:", n);
  for (size_t i = 0; i < n; i++) {
    uint32_t val;
    if (scanf("%u", &val) != 1) {
      free_vec32(vec);

      return NULL;
    }
    Vec(vec, i) = val;
  }
  return vec;
}

struct vec32 *read_vect_sauce_pitch_failed(size_t n) {
  struct vec32 *vec = create_vec32(n);
  printf("then throw in your [%zu] own supplies if you dont like ours:", n);
  for (size_t i = 0; i < n; i++) {
    uint32_t val;
    if (scanf("%u", &val) != 1) {
      free_vec32(vec);

      return NULL;
    }
    Vec(vec, i) = val;
  }
  return vec;
}

void multi_hash_read_vectors(size_t n, struct vec32 **vecs) {
  for (size_t i = 0; i < n; i++) {
    printf("Would you like the secret sauce [1] or a custom item [2] for %ld "
           "ingridient",
           i);
    int n;
    scanf("%d", &n);
    if (n == 1) {
      struct vec32 *v = create_vec32(MatCols(A));
      for (size_t j = 0; j < MatCols(A); j++) {
        Vec(v, j) = Vec(secret_vec, j);
      }
      vecs[i] = v;
      continue;
    } else if (n != 2) {
      printf("invalid input, exiting\n");
      exit(1);
    }
    struct vec32 *vec = read_vect_sauce_pitch_failed(MatCols(A));
    if (vec == NULL) {
      printf("invalid input, exiting\n");
      exit(1);
    }
    vecs[i] = vec;
  }
}

void menu() {
  printf("0) Check your work \n");
  printf("1) Hash a single vector\n");
  printf("2) Hash multiple vectors\n");
  printf("3) Exit\n");
  printf("Your choice: ");
  fflush(0);
}

int main() {
        alarm(200);
      setup_challenge();
  printf("Break this hash to obtain the flag \n");
  print_vector64(flag_hash);
  fflush(0);
  while (1) {
    menu();
    size_t choice;
    if (scanf("%zu", &choice) != 1) {
      printf("invalid input, exiting\n");
      exit(1);
    }
    switch (choice) {
    case 0: {
      struct vec32 *guess = read_vect_sauce_pitch_failed(MatCols(A));
      if (guess == NULL) {
        printf("invalid input, exiting\n");
        exit(1);
      }
      for (size_t i = 0; i < secret_vec->size; i++) {
        if (Vec(guess, i) != Vec(secret_vec, i)) {
          printf("Wrong guess! Try again.\n");
          free_vec32(guess);
          print_vector32(secret_vec);
          exit(0);
          goto end_guess;
        }
      }
      printf("Impossible the recipe was a lie.\n");
      printf("%s", getenv("FLAG"));
      exit(0);
    }
    end_guess:
      continue;
    case 1: {
      struct vec32 *vec = read_vect(MatCols(A));
      if (vec == NULL) {
        printf("invalid input, exiting\n");
        exit(1);
      }
      struct vec32 *hash = hash_single(vec);

      print_vector32(hash);
      free_vec32(vec);
      free_vec32(hash);
      fflush(0);
    }
      continue;
    case 2: {
      size_t n;
      printf("How many vectors do you want to hash? (max 100): ");
      if (scanf("%zu", &n) != 1 || n == 0 || n > 100) {
        printf("invalid input, exiting\n");
        exit(1);
      }
      struct vec32 **vecs = malloc(n * sizeof(struct vec32 *));
      multi_hash_read_vectors(n, vecs);
      struct vec32 **hashes = multi_hash(n, vecs);
      for (size_t i = 0; i < n; i++) {
        print_vector32(hashes[i]);
        free_vec32(vecs[i]);
        free_vec32(hashes[i]);
      }
      free(vecs);
      free(hashes);
    }
      continue;
    default:
      printf("invalid choice, exiting\n");
      exit(1);
    }
    return 0;
  }
}
