
/* vibed headers for cleaner setup*/

#ifndef MATRIX_H
#define MATRIX_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
/* ── Constants ─────────────────────────────────────────────────────────── */
/* ── Accessor macros ───────────────────────────────────────────────────── */

/** Access element (i, j) of a logical matrix stored in transposed order. */
#define Mat(m, i, j) ((m)->data[(j) * (m)->cols + (i)])

/** Logical row/column counts (matrix is stored transposed). */
#define MatRows(m) ((m)->cols)
#define MatCols(m) ((m)->rows)

/** Access element i of a vector. */
#define Vec(v, i) ((v)->data[(i)])

/* ── Data structures ───────────────────────────────────────────────────── */

/**
 * Matrix stored in row-major order of its transpose.
 * NOTE: following the transposed convention used throughout this library,
 * `cols` corresponds to the logical number of rows and vice-versa.
 */
struct matrix {
  size_t cols;
  size_t rows;
  uint32_t *data;
};

/** 32-bit unsigned integer vector. */
struct vec32 {
  size_t size;
  uint32_t *data;
};

/** 64-bit unsigned integer vector (used to hold un-reduced products). */
struct vec64 {
  size_t size;
  uint64_t *data;
};

struct matrix *read_matrix();
/* ── RNG ───────────────────────────────────────────────────────────────── */

/**
 * Returns a cryptographically secure 32-bit random number via getrandom(2).
 */
uint32_t secure_rand(void);

/* ── Construction / destruction ────────────────────────────────────────── */

/**
 * Allocate and zero-initialise a matrix of the given dimensions.
 * Caller is responsible for calling free_matrix() when done.
 */
struct matrix *create_matrix(size_t rows, size_t cols);

/**
 * Fill an already-dimensioned matrix with pseudorandom values in [0, 99].
 * Returns `mat` on success, NULL on failure.
 */
struct matrix *generate_random_matrix(struct matrix *mat);

/**
 * Allocate and zero-initialise a vec32 of the given size.
 * Caller is responsible for calling free_vec32() when done.
 */
struct vec32 *create_vec32(size_t size);

/**
 * Allocate and zero-initialise a vec64 of the given size.
 * Caller is responsible for calling free_vec64() when done.
 */
struct vec64 *create_vec64(size_t size);

/**
 * Allocate a vec32 of the given size and fill every element with a
 * pseudorandom value (currently a placeholder — see TODO in source).
 */
struct vec32 *generate_random_vector(size_t size);

/**
 * Free the data buffer of `mat` and reset its fields.
 * Does NOT free the struct itself (mirrors the stack-allocated use pattern).
 */
void free_matrix(struct matrix *mat);

/** Free a vec32 and its data buffer. */
void free_vec32(struct vec32 *vec);

/** Free a vec64 and its data buffer. */
void free_vec64(struct vec64 *vec);

/* ── Vector utilities ──────────────────────────────────────────────────── */

/** Set every element of `v` to `val`. */
void set_vector(struct vec32 *v, uint32_t val);

/** Print all elements of a vec32 followed by a newline. */
void print_vector32(struct vec32 *vec);

/** Print all elements of a vec64 followed by a newline. */
void print_vector64(struct vec64 *vec);

/**
 * Convert a vec64 to a vec32 by keeping only the low 32 bits of each element.
 * Returns a newly allocated vec32; caller must free_vec32() it.
 */
struct vec32 *vec64_to_vec32(struct vec64 *v);

/* ── Matrix utilities ──────────────────────────────────────────────────── */

/** Print the matrix to stdout (respects the transposed storage convention). */
void print_matrix(struct matrix *mat);

/**
 * Return a newly allocated vec32 containing column `col_index` of `mat`.
 * Caller must free_vec32() the result.
 */
struct vec32 *mat_get_col(struct matrix *mat, size_t col_index);
struct vec32 *mat_get_row(struct matrix *mat, size_t row_index);

/**
 * Write `col` into column `col_index` of `mat` in-place.
 * `col` must have at least `mat->rows` elements.
 */
void mat_insert_column(struct matrix *mat, struct vec32 *col, size_t col_index);

/**
 * Write `row` into row `row_index` of `mat` in-place.
 * `row` must have at least `mat->cols` elements.
 */
void mat_insert_row(struct matrix *mat, struct vec32 *row, size_t row_index);

/**
 * Return a newly allocated matrix that is the transpose of `mat`.
 * Caller must free_matrix() and then free() the result.
 */
struct matrix *transpose_matrix(struct matrix *mat);

/* ── Multiplication ────────────────────────────────────────────────────── */

/**
 * Matrix-vector multiply:  res = mat · src_vect
 *
 * Accumulates into `res` (does NOT zero it first — zero before calling if
 * needed).  Uses a 4-wide unrolled inner loop for performance.
 *
 * Dimensions required:
 *   src_vect->size == MatCols(mat)   (logical columns)
 *   res->size      == MatRows(mat)   (logical rows)
 */
void mat_mul(struct vec64 *res, struct matrix *mat, struct vec32 *src_vect);

/**
 * Matrix-matrix multiply:  res = matA · matB
 *
 * `res` must already be allocated with the correct dimensions.
 * Internally calls mat_mul() once per column of matB.
 */
void mat_mat_mul(struct matrix *res, struct matrix *matA, struct matrix *matB);

void matrix_mod(struct matrix *M, uint32_t mod);

void vec32_mod(struct vec32 *v, uint32_t mod);

void vec64_mod(struct vec64 *v, uint32_t mod);

bool vec32_eq(struct vec32 *v1, struct vec32 *v2);
void mat_mul_naive(struct vec64 *res, struct matrix *mat,
                   struct vec32 *src_vect);
#endif /* MATRIX_H */
