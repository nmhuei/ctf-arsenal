from Crypto.PublicKey import ECC
from hashlib import sha256
from uuid import UUID, uuid3

secret_key = ECC.generate(curve="p521")
public_key = secret_key.public_key()
secure_namespace = UUID(bytes=b"kitchenexplosion")

def secure_random(sk: ECC.EccKey, message: bytes) -> int:
    """
    Use sha256 as a secure but deterministic random generator
    to create randomness from the private key and message.

    :param sk: The private signing key
    :param message: The message to sign

    :return: A secure random number
    """

    key_id = uuid3(secure_namespace, sk.export_key(format="PEM")).bytes
    msg_id = uuid3(secure_namespace, message).bytes

    random_generator = sha256(key_id)
    random_generator.update(msg_id)

    return int.from_bytes(random_generator.digest()) % (int(sk._curve.order) - 1) + 1

def hash_message(message: bytes) -> int:
    """
    Create a collision resistant hash for the message to sign.

    :param message: The message to sign

    :return: The hash value
    """

    h = sha256(message).digest()
    return int.from_bytes(h)

def sign(sk: ECC.EccKey, message: bytes) -> tuple[int,int]:
    """
    Sign a message using ECDSA.

    :param sk: The secret key for signing
    :param message: The message to sign

    :return: The signature
    """

    if not sk.has_private():
        raise RuntimeError("That is not a secret key.")

    n = int(sk._curve.order)

    e = hash_message(message)
    z = e & ~(1 << n.bit_length())

    k = secure_random(sk, message)
    P = k * sk._curve.G

    r = P.x % n
    if r == 0:
        raise RuntimeError("Could not create signature")

    s = pow(k, -1, n) * (z + int(r * sk.d)) % n
    if s == 0:
        raise RuntimeError("Could not create signature")

    return (int(r), int(s))

def verify(pk: ECC.EccKey, message: bytes, signature: tuple[int,int]) -> bool:
    """
    Verify an ECDSA signature for a message against a public key.

    :param pk: The public key to verify against
    :param message: The message the signature is for
    :param signature: The signature to verify

    :return: Whether the signature is valid
    """

    Q = pk.pointQ
    r, s = signature
    n = int(pk._curve.order)

    if Q.is_point_at_infinity() or n * Q != Q.point_at_infinity():
        raise RuntimeError("Invalid key")

    if not (1 <= r < n and 1 <= s < n):
        return False

    e = hash_message(message)
    z = e & ~(1 << n.bit_length())

    inv_s = pow(s, -1, n)
    u1 = z * inv_s % n
    u2 = r * inv_s % n

    P = u1 * pk._curve.G + u2 * Q

    if P.is_point_at_infinity():
        return False
    return r == int(P.x % n)

def main():
    from os import environ
    flag = environ.get("FLAG")
    if flag is None:
        raise RuntimeError("Please set the flag as environment variable")

    print(f"Welcome to the Mongolian barbecue.\nUse `sign [hex recipe]` to get your recipe signed by us.\nYou can get the public key to verify signatures using `get pkey`.\nWhen you are ready to taste our freshly made flag, say `flag please`.\nIf you would like to leave, just say `check please`.")
    already_signed = []
    while True:
        command = input("\n> ").lower().split()

        match command:
            case ["sign", recipe]:
                try:
                    recipe = bytes.fromhex(recipe)
                except ValueError:
                    print("That recipe is illegible.")
                s1, s2 = sign(secret_key, recipe)
                already_signed.append(recipe)
                print(f"s1: {hex(s1)}\ns2: {hex(s2)}")

            case ["get", "pkey"]:
                print(f"x: {int(public_key.pointQ.x)}\ny: {int(public_key.pointQ.y)}")

            case ["flag", "please"]:
                print("To decide if you are worthy of our special flag you neeed to provide us a signed recipe we don't already know.")
                recipe = None
                while recipe is None:
                    try:
                        recipe = bytes.fromhex(input("recipe (hex): "))
                    except ValueError:
                        print("That recipe is illegible.")
                if recipe in already_signed:
                    print("We already know that one.")
                    continue
                s1 = None
                while s1 is None:
                    try:
                        s1 = int(input("s1 (hex): "), 16)
                    except ValueError:
                        print("That doesn't look right.")
                s2 = None
                while s2 is None:
                    try:
                        s2 = int(input("s2 (hex): "), 16)
                    except ValueError:
                        print("That doesn't look right.")

                if verify(public_key, recipe, (s1, s2)):
                    print(f"Congratulations. Here is your flag: {flag}")
                else:
                    print("That recipe is not signed properly. No flag for you.")

            case ["check", "please"]:
                print("I hope everything was to your liking. Please visit us again soon.")
                break

            case _:
                print("I CAN'T HEAR YOU WITH ALL THE KITCHEN NOISES.")

if __name__ == "__main__":
    from sys import argv

    main()
