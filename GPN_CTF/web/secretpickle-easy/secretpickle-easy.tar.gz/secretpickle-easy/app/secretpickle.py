# secret pickle: my own encrypted & comppressed pickle format 

import base64
import pickle

# default prefix that every pickled dict has; we don't need to send it every time
SECRETPICKLE_OBJECT_PREFIX = bytes.fromhex("8004 950000000000000000 7d 94 28")

# 128 random bits, so same security as AES-128
SECRETPICKLE_XOR_KEY = bytes.fromhex("77c07f8fd2ae7ad9f5aabc008c79d0d3")

def xor_repeating(data, key):
    return bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])

def secretpickle_encrypt(value):
    return xor_repeating(value, SECRETPICKLE_XOR_KEY)

def secretpickle_dump(decoded, encoder=pickle.dumps):
    raw = encoder(decoded)
    trimmed = raw[len(SECRETPICKLE_OBJECT_PREFIX):]
    xored = secretpickle_encrypt(trimmed)
    encoded = base64.b64encode(xored).decode()
    return encoded

def secretpickle_load(encoded, decoder=pickle.loads):
    decoded = base64.b64decode(encoded)
    xored = secretpickle_encrypt(decoded)
    untrimmed = SECRETPICKLE_OBJECT_PREFIX + xored
    raw = decoder(untrimmed)
    return raw
