# ozTrus

Coords: 2.064032, 12.650132


[CORRUPTED]
