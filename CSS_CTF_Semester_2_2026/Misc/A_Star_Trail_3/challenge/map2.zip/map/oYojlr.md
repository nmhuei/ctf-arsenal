# oYojlr

Coords: 1.695937, 75.944096


[CORRUPTED]
