# zkefs0

Coords: 0.377473, 46.955570


[CORRUPTED]
