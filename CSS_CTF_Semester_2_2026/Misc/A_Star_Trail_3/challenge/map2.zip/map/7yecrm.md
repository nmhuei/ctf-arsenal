# 7yecrm

Coords: 1.509093, 65.339788


[CORRUPTED]
