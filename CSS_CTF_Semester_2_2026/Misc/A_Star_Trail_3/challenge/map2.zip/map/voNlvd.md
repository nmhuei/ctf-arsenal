# voNlvd

Coords: 0.368363, 44.279945


[CORRUPTED]
