# dlo3mr

Coords: 1.957751, 36.320259


[CORRUPTED]
