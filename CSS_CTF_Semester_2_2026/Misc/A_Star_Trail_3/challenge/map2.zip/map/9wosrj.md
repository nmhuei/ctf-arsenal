# 9wosrj

Coords: 1.390354, 76.934539


[CORRUPTED]
