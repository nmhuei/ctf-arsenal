# bHmolm

Coords: 0.121834, 66.808306


[CORRUPTED]
