# bn4soq

Coords: 1.273315, 43.417207


[CORRUPTED]
