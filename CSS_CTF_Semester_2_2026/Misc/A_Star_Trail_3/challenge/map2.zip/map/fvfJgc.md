# fvfJgc

Coords: 1.036714, 76.196718


[CORRUPTED]
