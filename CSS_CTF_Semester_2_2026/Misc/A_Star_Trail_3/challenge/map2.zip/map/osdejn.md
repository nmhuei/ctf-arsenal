# osdejn

Coords: 0.786571, 12.752891


[CORRUPTED]
