# wMdsag

Coords: 1.478767, 21.666222


[CORRUPTED]
