# phweoc

Coords: 1.703927, 7.965561


[CORRUPTED]
