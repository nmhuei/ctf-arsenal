# 9foejs

Coords: 1.732984, 35.155368


[CORRUPTED]
