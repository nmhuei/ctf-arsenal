# kwphdE

Coords: 1.291554, 11.157328


[CORRUPTED]
