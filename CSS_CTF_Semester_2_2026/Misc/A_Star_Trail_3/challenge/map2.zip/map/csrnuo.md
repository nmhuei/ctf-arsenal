# csrnuo

Coords: 1.610395, 29.223781


[CORRUPTED]
