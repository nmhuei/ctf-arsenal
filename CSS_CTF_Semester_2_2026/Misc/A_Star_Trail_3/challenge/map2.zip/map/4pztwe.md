# 4pztwe

Coords: 2.069857, 77.525071


[CORRUPTED]
