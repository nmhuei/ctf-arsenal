# pPkrcl

Coords: 0.571414, 70.043441


[CORRUPTED]
