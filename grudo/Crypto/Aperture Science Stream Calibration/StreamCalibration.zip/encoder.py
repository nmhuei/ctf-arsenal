#!/usr/bin/env python3

MOD = 1 << 32
A = 1664525
C = 1013904223


def keystream(seed, length):
    state = seed & 0xFFFFF
    out = bytearray()
    for _ in range(length):
        state = (A * state + C) % MOD
        out.append((state >> 24) & 0xFF)
    return bytes(out)


def xor_bytes(left, right):
    return bytes(a ^ b for a, b in zip(left, right))


def encrypt(message: bytes, facility_seed: int) -> bytes:
    return xor_bytes(message, keystream(facility_seed, len(message)))
