t = "frag1 frag 2 ... frag8".split()
g = "0123456789bcdefghjkmnpqrstuvwxyz"
print("".join(g[eval('^'.join(str(ord(c)&31) for c in col))] for col in zip(*t)))