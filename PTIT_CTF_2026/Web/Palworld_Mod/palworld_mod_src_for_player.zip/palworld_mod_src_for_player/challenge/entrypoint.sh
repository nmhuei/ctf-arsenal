#!/bin/bash
set -e
cd /app

export SECRET_KEY="${SECRET_KEY:-$(python -c 'import secrets; print(secrets.token_urlsafe(48))')}"

export FLAG="${GZCTF_FLAG:-$FLAG}"

mkdir -p /data/media

python manage.py migrate --no-input

python manage.py loaddata 00_platforms 01_global_mods 2>/dev/null || true

export DJANGO_SUPERUSER_USERNAME="${ADMIN_USERNAME:-palforge_admin}"
export DJANGO_SUPERUSER_PASSWORD="${ADMIN_PASSWORD:-change-me-admin}"
python manage.py createsuperuser --noinput --username "$DJANGO_SUPERUSER_USERNAME" 2>/dev/null || true

capsh --drop=cap_dac_override -- -c \
    'exec daphne -b 127.0.0.1 -p 5555 config.asgi:application' &

exec nginx -g 'daemon off;'
