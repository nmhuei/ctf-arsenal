from django.db import models
from apps.accounts.models import User


class Platform(models.Model):
    owner = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE, related_name='platforms')
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'platforms'
        ordering = ['code']
        unique_together = ('owner', 'code')

    def __str__(self):
        return self.code


class Mod(models.Model):
    owner = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE, related_name='mods')
    title = models.CharField(max_length=120)
    mod_version = models.CharField(max_length=20)
    release_notes = models.TextField(blank=True)
    is_enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'mods'
        ordering = ['-created_at']
        unique_together = ('owner', 'mod_version')

    def __str__(self):
        return f"{self.title} ({self.mod_version})"


class ModBuild(models.Model):
    mod = models.ForeignKey(Mod, on_delete=models.CASCADE, related_name='builds')
    platform = models.ForeignKey(Platform, on_delete=models.CASCADE, related_name='builds')
    filelist_content = models.TextField(blank=True)
    storage_path = models.CharField(max_length=500, blank=True)
    uploaded_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'mod_builds'
        unique_together = ('mod', 'platform')

    def __str__(self):
        return f"{self.mod.mod_version} / {self.platform.code}"
