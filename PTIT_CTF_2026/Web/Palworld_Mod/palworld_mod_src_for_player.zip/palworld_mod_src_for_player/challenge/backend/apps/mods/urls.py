from django.urls import path
from . import views

urlpatterns = [
    path('platforms/', views.PlatformListCreateView.as_view(), name='platform-list'),
    path('platforms/<int:pk>/', views.PlatformDetailView.as_view(), name='platform-detail'),
    path('mods/', views.ModListCreateView.as_view(), name='mod-list'),
    path('mods/<int:pk>/', views.ModDetailView.as_view(), name='mod-detail'),
    path('mods/<int:mod_pk>/builds/', views.BuildListCreateView.as_view(), name='build-list'),
    path('mods/<int:mod_pk>/builds/<int:pk>/', views.BuildDetailView.as_view(), name='build-detail'),
    path('mods/<int:mod_pk>/builds/<int:pk>/upload/', views.upload_build_files, name='build-upload'),
]
