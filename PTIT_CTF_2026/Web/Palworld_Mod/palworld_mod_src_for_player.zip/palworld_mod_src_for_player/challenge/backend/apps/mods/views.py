import hashlib
import zipfile
from pathlib import Path
from django.conf import settings
from django.db.models import Q
from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.exceptions import PermissionDenied
from rest_framework.parsers import MultiPartParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Mod, ModBuild, Platform
from .serializers import (
    ModSerializer, ModDetailSerializer, ModBuildSerializer, PlatformSerializer,
)


def _visible(qs, user, owner_field='owner'):
    """Chỉ trả về bản ghi chung (owner null) hoặc của chính người dùng; admin thấy tất."""
    if user.is_admin:
        return qs
    return qs.filter(Q(**{f'{owner_field}__isnull': True}) | Q(**{owner_field: user}))


class PlatformListCreateView(generics.ListCreateAPIView):
    serializer_class = PlatformSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return _visible(Platform.objects.all(), self.request.user)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class PlatformDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = PlatformSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if self.request.method in ('GET', 'HEAD', 'OPTIONS') or self.request.user.is_admin:
            return _visible(Platform.objects.all(), self.request.user)
        return Platform.objects.filter(owner=self.request.user)


class ModListCreateView(generics.ListCreateAPIView):
    serializer_class = ModSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return _visible(Mod.objects.all(), self.request.user)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class ModDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if self.request.method in ('GET', 'HEAD', 'OPTIONS') or self.request.user.is_admin:
            return _visible(Mod.objects.all(), self.request.user)
        return Mod.objects.filter(owner=self.request.user)

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return ModDetailSerializer
        return ModSerializer


class BuildListCreateView(generics.ListCreateAPIView):
    serializer_class = ModBuildSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        visible_mods = _visible(Mod.objects.all(), self.request.user)
        return ModBuild.objects.filter(mod_id=self.kwargs['mod_pk'], mod__in=visible_mods)

    def perform_create(self, serializer):
        mod = Mod.objects.filter(pk=self.kwargs['mod_pk']).first()
        if not mod:
            raise PermissionDenied('Không tìm thấy mod.')
        if not self.request.user.is_admin and mod.owner_id != self.request.user.id:
            raise PermissionDenied('Chỉ chủ mod mới thêm được build.')
        serializer.save(mod_id=self.kwargs['mod_pk'])


class BuildDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ModBuildSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if self.request.method in ('GET', 'HEAD', 'OPTIONS') or self.request.user.is_admin:
            visible_mods = _visible(Mod.objects.all(), self.request.user)
        else:
            visible_mods = Mod.objects.filter(owner=self.request.user)
        return ModBuild.objects.filter(mod_id=self.kwargs['mod_pk'], mod__in=visible_mods)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser])
def upload_build_files(request, mod_pk, pk):
    """Đẩy file build (filelist hoặc gói .zip) cho một build của mod."""
    try:
        build = ModBuild.objects.select_related('mod', 'platform').get(
            pk=pk, mod_id=mod_pk
        )
    except ModBuild.DoesNotExist:
        return Response({'detail': 'Không tìm thấy build.'}, status=status.HTTP_404_NOT_FOUND)

    if not request.user.is_admin and build.mod.owner_id != request.user.id:
        return Response(
            {'detail': 'Bạn không có quyền đẩy build cho mod này.'},
            status=status.HTTP_403_FORBIDDEN,
        )

    mod_version = build.mod.mod_version
    platform_code = build.platform.code
    storage_dir = Path(settings.MEDIA_ROOT) / 'builds' / mod_version / platform_code
    storage_dir.mkdir(parents=True, exist_ok=True)

    updated_fields = []

    filelist_file = request.FILES.get('filelist_file')
    if filelist_file:
        build.filelist_content = filelist_file.read().decode('utf-8', errors='replace')
        updated_fields.append('filelist_content')

    zip_file = request.FILES.get('zip_file')
    if zip_file:
        MAX_FILE_SIZE = 5 * 1024 * 1024
        MAX_TOTAL_SIZE = 20 * 1024 * 1024
        MAX_FILES = 256
        try:
            with zipfile.ZipFile(zip_file) as zf:
                names = [n for n in zf.namelist() if not n.endswith('/')]
                if len(names) > MAX_FILES:
                    return Response({'detail': 'Gói build có quá nhiều file.'},
                                    status=status.HTTP_400_BAD_REQUEST)
                filelist_lines = []
                total = 0
                for name in names:
                    with zf.open(name) as fp:
                        data = fp.read(MAX_FILE_SIZE + 1)
                    if len(data) > MAX_FILE_SIZE:
                        return Response({'detail': 'File trong gói build quá lớn.'},
                                        status=status.HTTP_400_BAD_REQUEST)
                    total += len(data)
                    if total > MAX_TOTAL_SIZE:
                        return Response({'detail': 'Gói build quá lớn.'},
                                        status=status.HTTP_400_BAD_REQUEST)
                    filename = Path(name).name
                    if not filename:
                        continue
                    md5 = hashlib.md5(data).hexdigest()
                    (storage_dir / filename).write_bytes(data)
                    filelist_lines.append(f"{filename} {md5}")
            if not filelist_file:
                build.filelist_content = '\n'.join(filelist_lines)
                updated_fields.append('filelist_content')
            build.storage_path = storage_dir.relative_to(settings.MEDIA_ROOT).as_posix()
            updated_fields.append('storage_path')
        except zipfile.BadZipFile:
            return Response({'detail': 'File zip không hợp lệ.'}, status=status.HTTP_400_BAD_REQUEST)

    if not updated_fields:
        return Response({'detail': 'Không có file nào được upload.'}, status=status.HTTP_400_BAD_REQUEST)

    build.save(update_fields=list(set(updated_fields)) + ['updated_at'])

    return Response(ModBuildSerializer(build, context={'request': request}).data)
