from rest_framework import serializers
from .models import Mod, ModBuild, Platform


class PlatformSerializer(serializers.ModelSerializer):
    is_global = serializers.SerializerMethodField()

    class Meta:
        model = Platform
        fields = ['id', 'code', 'name', 'description', 'is_enabled',
                  'owner', 'is_global', 'created_at', 'updated_at']
        read_only_fields = ['id', 'owner', 'created_at', 'updated_at']

    def get_is_global(self, obj):
        return obj.owner_id is None


class ModBuildSerializer(serializers.ModelSerializer):
    platform_detail = PlatformSerializer(source='platform', read_only=True)

    class Meta:
        model = ModBuild
        fields = [
            'id', 'mod', 'platform', 'platform_detail',
            'filelist_content', 'storage_path',
            'uploaded_by', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'mod', 'uploaded_by', 'created_at', 'updated_at']
        extra_kwargs = {
            'filelist_content': {'required': False, 'allow_blank': True},
            'storage_path': {'required': False, 'allow_blank': True},
        }

    def validate(self, attrs):
        request = self.context['request']
        mod_id = self.context['view'].kwargs.get('mod_pk')
        platform = attrs.get('platform')

        if platform and platform.owner_id is not None and platform.owner_id != request.user.id:
            raise serializers.ValidationError({'platform': 'Không dùng được platform này.'})

        if platform and mod_id:
            qs = ModBuild.objects.filter(mod_id=mod_id, platform=platform)
            if self.instance:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise serializers.ValidationError(
                    {'platform': 'Build cho platform này đã tồn tại trong mod.'}
                )
        return attrs

    def create(self, validated_data):
        validated_data['uploaded_by'] = self.context['request'].user
        return super().create(validated_data)

    def update(self, instance, validated_data):
        validated_data['uploaded_by'] = self.context['request'].user
        return super().update(instance, validated_data)


class ModSerializer(serializers.ModelSerializer):
    build_count = serializers.SerializerMethodField()
    is_global = serializers.SerializerMethodField()

    class Meta:
        model = Mod
        fields = [
            'id', 'title', 'mod_version', 'release_notes',
            'is_enabled', 'owner', 'is_global', 'build_count',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'owner', 'created_at', 'updated_at']

    def get_build_count(self, obj):
        return obj.builds.count()

    def get_is_global(self, obj):
        return obj.owner_id is None


class ModDetailSerializer(ModSerializer):
    builds = ModBuildSerializer(many=True, read_only=True)

    class Meta(ModSerializer.Meta):
        fields = ModSerializer.Meta.fields + ['builds']
