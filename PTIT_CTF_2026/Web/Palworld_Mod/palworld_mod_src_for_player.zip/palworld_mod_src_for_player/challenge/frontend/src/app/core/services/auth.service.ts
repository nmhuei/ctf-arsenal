import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface User {
  id: number;
  username: string;
  full_name: string;
  role: 'admin' | 'user';
  is_active: boolean;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY = 'access_token';
  private readonly REFRESH_KEY = 'refresh_token';
  private readonly USER_KEY = 'current_user';

  currentUser = signal<User | null>(null);

  constructor(private http: HttpClient, private router: Router) {
    const token = this.getToken();
    const saved = this._loadUserFromStorage();
    if (token && saved) {
      this.currentUser.set(saved);
      this.fetchMe();
    } else if (token) {
      this.fetchMe();
    }
  }

  register(username: string, password: string, full_name: string) {
    return this.http.post(`${environment.apiUrl}/auth/register/`, { username, password, full_name });
  }

  login(username: string, password: string) {
    return this.http.post<{ access: string; refresh: string; user: User }>(
      `${environment.apiUrl}/auth/login/`,
      { username, password }
    ).pipe(
      tap(res => {
        localStorage.setItem(this.TOKEN_KEY, res.access);
        localStorage.setItem(this.REFRESH_KEY, res.refresh);
        localStorage.setItem(this.USER_KEY, JSON.stringify(res.user));
        this.currentUser.set(res.user);
      })
    );
  }

  logout() {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.REFRESH_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUser.set(null);
    this.router.navigate(['/login']);
  }

  private _loadUserFromStorage(): User | null {
    try {
      const raw = localStorage.getItem(this.USER_KEY);
      return raw ? (JSON.parse(raw) as User) : null;
    } catch {
      return null;
    }
  }

  getToken(): string | null { return localStorage.getItem(this.TOKEN_KEY); }
  getRefreshToken(): string | null { return localStorage.getItem(this.REFRESH_KEY); }
  isAuthenticated(): boolean { return !!this.getToken(); }
  isAdmin(): boolean { return this.currentUser()?.role === 'admin'; }

  refreshToken() {
    return this.http.post<{ access: string }>(
      `${environment.apiUrl}/auth/token/refresh/`,
      { refresh: this.getRefreshToken() }
    ).pipe(
      tap(res => localStorage.setItem(this.TOKEN_KEY, res.access))
    );
  }

  private fetchMe() {
    this.http.get<User>(`${environment.apiUrl}/auth/me/`).subscribe({
      next: user => {
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
        this.currentUser.set(user);
      },
      error: (err: HttpErrorResponse) => {
        if (err.status === 401) this.logout();
      },
    });
  }
}
