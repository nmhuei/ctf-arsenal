import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/services/api.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-header">
      <h1>Dashboard</h1>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-value">{{ stats.totalMods }}</div>
        <div class="stat-label">Tổng bản mod</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">{{ stats.totalBuilds }}</div>
        <div class="stat-label">Tổng build</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">{{ stats.totalPlatforms }}</div>
        <div class="stat-label">Platforms hỗ trợ</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h3>Mod mới nhất</h3>
        <a routerLink="/mods" class="link-all">Xem tất cả →</a>
      </div>
      <table class="table">
        <thead>
          <tr><th>Tên mod</th><th>Version</th><th>Builds</th><th>Ngày tạo</th></tr>
        </thead>
        <tbody>
          @for (m of recentMods; track m.id) {
            <tr [routerLink]="['/mods', m.id]" style="cursor:pointer">
              <td><strong>{{ m.title }}</strong></td>
              <td>{{ m.mod_version }}</td>
              <td><span class="badge badge-info">{{ m.build_count }} build</span></td>
              <td>{{ m.created_at | date:'dd/MM/yyyy' }}</td>
            </tr>
          }
          @if (recentMods.length === 0) {
            <tr><td colspan="4" class="empty">Chưa có mod nào.</td></tr>
          }
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .page-header { margin-bottom: 24px; }
    .page-header h1 { margin: 0; font-size: 24px; color: #1e293b; }
    .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
    .stat-card { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); text-align: center; }
    .stat-value { font-size: 36px; font-weight: 700; color: #1e293b; }
    .stat-label { font-size: 13px; color: #64748b; margin-top: 4px; }
    .card { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
    .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .card-header h3 { margin: 0; font-size: 15px; color: #1e293b; }
    .link-all { font-size: 13px; color: #2563eb; text-decoration: none; }
    .badge { padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
    .badge-info { background: #dbeafe; color: #1d4ed8; }
    .table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .table th { padding: 8px; text-align: left; color: #64748b; font-weight: 500; border-bottom: 1px solid #e2e8f0; }
    .table td { padding: 8px; border-bottom: 1px solid #f1f5f9; color: #374151; }
    .table tr:hover td { background: #f8fafc; }
    .empty { color: #94a3b8; font-size: 13px; text-align: center; padding: 20px 0; }
  `]
})
export class DashboardComponent implements OnInit {
  recentMods: any[] = [];
  stats = { totalMods: 0, totalBuilds: 0, totalPlatforms: 0 };

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.api.getMods().subscribe((res: any) => {
      const mods = res.results ?? res;
      this.recentMods = mods.slice(0, 10);
      this.stats.totalMods = res.count ?? mods.length;
      this.stats.totalBuilds = mods.reduce((s: number, m: any) => s + (m.build_count ?? 0), 0);
    });
    this.api.getPlatforms().subscribe((res: any) => {
      const p = res.results ?? res;
      this.stats.totalPlatforms = res.count ?? p.length;
    });
  }
}
