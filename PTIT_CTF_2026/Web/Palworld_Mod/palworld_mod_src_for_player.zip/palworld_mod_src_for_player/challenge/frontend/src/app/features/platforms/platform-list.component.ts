import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-platform-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-header">
      <div>
        <h1>Platforms</h1>
        <p class="sub">Nền tảng phát hành. Bạn có thể thêm platform riêng cho các bản build của mình.</p>
      </div>
      <button class="btn btn-primary" (click)="openForm()">+ Thêm platform</button>
    </div>

    <div class="card">
      <table class="table">
        <thead>
          <tr><th>Code</th><th>Tên</th><th>Mô tả</th><th>Nguồn</th><th>Hành động</th></tr>
        </thead>
        <tbody>
          @for (p of platforms; track p.id) {
            <tr>
              <td><code class="code-badge">{{ p.code }}</code></td>
              <td>{{ p.name }}</td>
              <td>{{ p.description || '—' }}</td>
              <td>
                @if (p.is_global) { <span class="badge badge-ok">Chính thức</span> }
                @else { <span class="badge badge-mine">Của tôi</span> }
              </td>
              <td class="actions">
                @if (!p.is_global) {
                  <button class="btn btn-sm btn-danger" (click)="confirmDelete(p)">Xóa</button>
                }
              </td>
            </tr>
          }
          @if (platforms.length === 0) {
            <tr><td colspan="5" class="empty">Chưa có platform nào.</td></tr>
          }
        </tbody>
      </table>
    </div>

    @if (showForm) {
      <div class="modal-overlay" (click)="closeForm()">
        <div class="modal" (click)="$event.stopPropagation()">
          <h3>Thêm platform</h3>
          <form (ngSubmit)="save()">
            <div class="field">
              <label>Code * <small>(vd: win64, steamdeck)</small></label>
              <input [(ngModel)]="form.code" name="code" required placeholder="win64" />
            </div>
            <div class="field">
              <label>Tên *</label>
              <input [(ngModel)]="form.name" name="name" required placeholder="Windows 64-bit" />
            </div>
            <div class="field">
              <label>Mô tả</label>
              <input [(ngModel)]="form.description" name="description" placeholder="..." />
            </div>
            @if (formError) { <div class="error-msg">{{ formError }}</div> }
            <div class="modal-actions">
              <button type="button" class="btn" (click)="closeForm()">Huỷ</button>
              <button type="submit" class="btn btn-primary" [disabled]="saving">
                {{ saving ? 'Đang lưu...' : 'Lưu' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    }
  `,
  styles: [`
    .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .page-header h1 { margin: 0; font-size: 22px; color: #1e293b; }
    .sub { margin: 4px 0 0; font-size: 12px; color: #64748b; }
    .card { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
    .table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .table th { padding: 12px 16px; text-align: left; background: #f8fafc; color: #64748b; font-weight: 500; border-bottom: 1px solid #e2e8f0; }
    .table td { padding: 12px 16px; border-bottom: 1px solid #f1f5f9; color: #374151; }
    .code-badge { background: #1e293b; color: #e2e8f0; padding: 3px 8px; border-radius: 4px; font-size: 12px; }
    .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; }
    .badge-ok { background: #dcfce7; color: #15803d; }
    .badge-mine { background: #fef3c7; color: #b45309; }
    .actions { display: flex; gap: 6px; }
    .btn { padding: 7px 14px; border-radius: 6px; border: 1px solid #e2e8f0; background: white; cursor: pointer; font-size: 13px; }
    .btn-primary { background: #2563eb; color: white; border-color: #2563eb; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }
    .btn-danger { background: #fee2e2; color: #dc2626; border-color: #fecaca; }
    .empty { text-align: center; color: #94a3b8; padding: 32px; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; z-index: 100; }
    .modal { background: white; border-radius: 10px; padding: 28px; width: 440px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); }
    .modal h3 { margin: 0 0 20px; }
    .field { margin-bottom: 14px; }
    label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 5px; }
    label small { color: #94a3b8; font-weight: 400; }
    input { width: 100%; padding: 9px 11px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; box-sizing: border-box; }
    .error-msg { background: #fef2f2; color: #dc2626; padding: 9px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 12px; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px; }
  `]
})
export class PlatformListComponent implements OnInit {
  platforms: any[] = [];
  showForm = false;
  form = { code: '', name: '', description: '' };
  formError = '';
  saving = false;

  constructor(public auth: AuthService, private api: ApiService) {}

  ngOnInit() { this.load(); }

  load() {
    this.api.getPlatforms().subscribe((res: any) => { this.platforms = res.results ?? res; });
  }

  openForm() { this.form = { code: '', name: '', description: '' }; this.formError = ''; this.showForm = true; }
  closeForm() { this.showForm = false; }

  save() {
    this.saving = true;
    this.formError = '';
    this.api.createPlatform(this.form).subscribe({
      next: () => { this.saving = false; this.closeForm(); this.load(); },
      error: (err: any) => { this.saving = false; this.formError = JSON.stringify(err.error); }
    });
  }

  confirmDelete(p: any) {
    if (!confirm(`Xóa platform "${p.code}"?`)) return;
    this.api.deletePlatform(p.id).subscribe(() => this.load());
  }
}
