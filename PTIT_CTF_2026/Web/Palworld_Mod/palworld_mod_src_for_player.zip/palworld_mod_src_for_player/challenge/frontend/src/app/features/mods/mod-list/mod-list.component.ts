import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-mod-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-header">
      <div>
        <h1>Mod của tôi</h1>
        <p class="sub">Bản mod bạn tải lên — đang chờ đội ngũ kiểm duyệt để lên kho chính thức.</p>
      </div>
      <button class="btn btn-primary" (click)="openForm()">+ Tải mod lên</button>
    </div>

    <div class="card">
      <table class="table">
        <thead>
          <tr><th>Tên mod</th><th>Version</th><th>Builds</th><th>Trạng thái</th><th>Hành động</th></tr>
        </thead>
        <tbody>
          @for (m of myMods; track m.id) {
            <tr>
              <td><strong>{{ m.title }}</strong></td>
              <td><code class="ver">{{ m.mod_version }}</code></td>
              <td><span class="badge badge-info">{{ m.build_count }} build</span></td>
              <td><span class="badge badge-pending">⏳ Chưa kiểm duyệt</span></td>
              <td class="actions">
                <a [routerLink]="['/mods', m.id]" class="btn btn-sm btn-primary">Đẩy build →</a>
                <button class="btn btn-sm" (click)="openForm(m)">Sửa</button>
                <button class="btn btn-sm btn-danger" (click)="confirmDelete(m)">Xóa</button>
              </td>
            </tr>
          }
          @if (myMods.length === 0) {
            <tr><td colspan="5" class="empty">Bạn chưa tải mod nào. Bấm “+ Tải mod lên”.</td></tr>
          }
        </tbody>
      </table>
    </div>

    <div class="page-header section2">
      <div>
        <h1>Mod chính thức</h1>
        <p class="sub">Đã được đội ngũ PalForge kiểm duyệt — chỉ xem, không chỉnh sửa.</p>
      </div>
    </div>

    <div class="card">
      <table class="table">
        <thead>
          <tr><th>Tên mod</th><th>Version</th><th>Mô tả</th><th>Builds</th><th>Trạng thái</th><th></th></tr>
        </thead>
        <tbody>
          @for (m of globalMods; track m.id) {
            <tr>
              <td><strong>{{ m.title }}</strong></td>
              <td><code class="ver">{{ m.mod_version }}</code></td>
              <td>{{ m.release_notes ? (m.release_notes | slice:0:50) + '…' : '—' }}</td>
              <td><span class="badge badge-info">{{ m.build_count }} build</span></td>
              <td><span class="badge badge-ok">✓ Đã kiểm duyệt</span></td>
              <td class="actions">
                <a [routerLink]="['/mods', m.id]" class="btn btn-sm">Chi tiết</a>
              </td>
            </tr>
          }
          @if (globalMods.length === 0) {
            <tr><td colspan="6" class="empty">Chưa có mod chính thức.</td></tr>
          }
        </tbody>
      </table>
    </div>

    @if (showForm) {
      <div class="modal-overlay" (click)="closeForm()">
        <div class="modal" (click)="$event.stopPropagation()">
          <h3>{{ editing ? 'Sửa bản mod' : 'Tải mod lên' }}</h3>
          @if (!editing) {
            <div class="info-hint">Sau khi tạo, bạn sẽ được chuyển sang trang chi tiết để đẩy build cho từng platform.</div>
          }
          <form (ngSubmit)="save()">
            <div class="field">
              <label>Tên mod *</label>
              <input [(ngModel)]="form.title" name="title" required placeholder="More Pals Per Base" />
            </div>
            <div class="field">
              <label>Version * <small>(vd: 2.4.1-beta)</small></label>
              <input [(ngModel)]="form.mod_version" name="mod_version" required placeholder="2.4.1" [disabled]="!!editing" />
            </div>
            <div class="field">
              <label>Mô tả</label>
              <textarea [(ngModel)]="form.release_notes" name="release_notes" rows="4"
                        placeholder="Thay đổi trong bản mod này..."></textarea>
            </div>
            @if (formError) { <div class="error-msg">{{ formError }}</div> }
            <div class="modal-actions">
              <button type="button" class="btn" (click)="closeForm()">Huỷ</button>
              <button type="submit" class="btn btn-primary" [disabled]="saving">
                {{ saving ? 'Đang lưu...' : 'Lưu' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    }
  `,
  styles: [`
    .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
    .page-header.section2 { margin-top: 32px; }
    .page-header h1 { margin: 0; font-size: 20px; color: #1e293b; }
    .sub { margin: 4px 0 0; font-size: 12px; color: #64748b; }
    .card { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
    .table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .table th { padding: 12px 16px; text-align: left; background: #f8fafc; color: #64748b; font-weight: 500; border-bottom: 1px solid #e2e8f0; }
    .table td { padding: 12px 16px; border-bottom: 1px solid #f1f5f9; color: #374151; }
    .ver { background: #f1f5f9; padding: 2px 7px; border-radius: 4px; font-size: 12px; }
    .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; }
    .badge-info { background: #dbeafe; color: #1d4ed8; }
    .badge-ok { background: #dcfce7; color: #15803d; }
    .badge-pending { background: #fef3c7; color: #b45309; }
    .actions { display: flex; gap: 6px; }
    .btn { padding: 7px 14px; border-radius: 6px; border: 1px solid #e2e8f0; background: white; cursor: pointer; font-size: 13px; text-decoration: none; color: #374151; display: inline-flex; align-items: center; }
    .btn-primary { background: #2563eb; color: white; border-color: #2563eb; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }
    .btn-danger { background: #fee2e2; color: #dc2626; border-color: #fecaca; }
    .empty { text-align: center; color: #94a3b8; padding: 28px; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; z-index: 100; }
    .modal { background: white; border-radius: 10px; padding: 28px; width: 480px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); }
    .modal h3 { margin: 0 0 20px; }
    .field { margin-bottom: 14px; }
    label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 5px; }
    label small { color: #94a3b8; font-weight: 400; }
    input, textarea { width: 100%; padding: 9px 11px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; box-sizing: border-box; }
    .info-hint { background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; padding: 9px 12px; border-radius: 6px; font-size: 12px; margin-bottom: 16px; }
    .error-msg { background: #fef2f2; color: #dc2626; padding: 9px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 12px; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px; }
  `]
})
export class ModListComponent implements OnInit {
  myMods: any[] = [];
  globalMods: any[] = [];
  showForm = false;
  editing: any = null;
  form = { title: '', mod_version: '', release_notes: '' };
  formError = '';
  saving = false;

  constructor(public auth: AuthService, private api: ApiService, private router: Router) {}

  ngOnInit() { this.load(); }

  load() {
    this.api.getMods().subscribe((res: any) => {
      const mods = res.results ?? res;
      this.globalMods = mods.filter((m: any) => m.is_global);
      this.myMods = mods.filter((m: any) => !m.is_global);
    });
  }

  openForm(m?: any) {
    this.editing = m ?? null;
    this.form = {
      title: m?.title ?? '',
      mod_version: m?.mod_version ?? '',
      release_notes: m?.release_notes ?? '',
    };
    this.formError = '';
    this.showForm = true;
  }

  closeForm() { this.showForm = false; this.editing = null; }

  save() {
    this.saving = true;
    this.formError = '';
    const req = this.editing
      ? this.api.updateMod(this.editing.id, { title: this.form.title, release_notes: this.form.release_notes })
      : this.api.createMod(this.form);
    req.subscribe({
      next: (result: any) => {
        this.saving = false;
        const wasEditing = !!this.editing;
        this.closeForm();
        if (wasEditing) { this.load(); }
        else { this.router.navigate(['/mods', result.id]); }
      },
      error: (err: any) => { this.saving = false; this.formError = JSON.stringify(err.error); }
    });
  }

  confirmDelete(m: any) {
    if (!confirm(`Xóa mod "${m.title}"?`)) return;
    this.api.deleteMod(m.id).subscribe(() => this.load());
  }
}
