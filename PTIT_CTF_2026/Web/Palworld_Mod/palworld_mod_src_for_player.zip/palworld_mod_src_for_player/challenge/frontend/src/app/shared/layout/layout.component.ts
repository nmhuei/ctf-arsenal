import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  template: `
    <div class="app-container">
      <aside class="sidebar">
        <div class="sidebar-header">
          <h2>🐾 PalForge</h2>
          <small>Kho mod Palworld</small>
        </div>
        <nav>
          <a routerLink="/dashboard" routerLinkActive="active">
            <span class="icon">📊</span> Dashboard
          </a>
          <a routerLink="/platforms" routerLinkActive="active">
            <span class="icon">🖥️</span> Platforms
          </a>
          <a routerLink="/mods" routerLinkActive="active">
            <span class="icon">📦</span> Mods
          </a>
        </nav>
        <div class="sidebar-footer">
          <span class="user-info">
            <strong>{{ auth.currentUser()?.username }}</strong>
            <small>{{ auth.currentUser()?.role }}</small>
          </span>
          <button class="btn-logout" (click)="auth.logout()">Đăng xuất</button>
        </div>
      </aside>
      <main class="main-content">
        <router-outlet />
      </main>
    </div>
  `,
  styles: [`
    .app-container { display: flex; height: 100vh; overflow: hidden; }
    .sidebar {
      width: 220px; min-width: 220px; background: #1e293b; color: #cbd5e1;
      display: flex; flex-direction: column; padding: 0;
    }
    .sidebar-header { padding: 20px 16px; border-bottom: 1px solid #334155; }
    .sidebar-header h2 { margin: 0; font-size: 16px; color: #f1f5f9; }
    .sidebar-header small { font-size: 11px; color: #64748b; }
    nav { flex: 1; padding: 8px 0; overflow-y: auto; }
    nav a {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 16px; color: #94a3b8; text-decoration: none;
      font-size: 14px; border-left: 3px solid transparent;
      transition: all 0.15s;
    }
    nav a:hover { background: #334155; color: #f1f5f9; }
    nav a.active { background: #1d4ed8; color: #fff; border-left-color: #60a5fa; }
    .icon { font-size: 16px; }
    .sidebar-footer {
      padding: 16px; border-top: 1px solid #334155;
      display: flex; flex-direction: column; gap: 8px;
    }
    .user-info { display: flex; flex-direction: column; }
    .user-info strong { font-size: 13px; color: #f1f5f9; }
    .user-info small { font-size: 11px; color: #64748b; text-transform: uppercase; }
    .btn-logout {
      background: #dc2626; color: white; border: none;
      padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 12px;
    }
    .btn-logout:hover { background: #b91c1c; }
    .main-content { flex: 1; overflow-y: auto; background: #f8fafc; padding: 24px; }
  `]
})
export class LayoutComponent {
  constructor(public auth: AuthService) {}
}
