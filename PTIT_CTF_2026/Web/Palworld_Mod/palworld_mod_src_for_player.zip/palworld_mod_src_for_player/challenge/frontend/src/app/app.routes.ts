import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent) },
  { path: 'register', loadComponent: () => import('./features/auth/register/register.component').then(m => m.RegisterComponent) },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./shared/layout/layout.component').then(m => m.LayoutComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'platforms', loadComponent: () => import('./features/platforms/platform-list.component').then(m => m.PlatformListComponent) },
      { path: 'mods', loadComponent: () => import('./features/mods/mod-list/mod-list.component').then(m => m.ModListComponent) },
      { path: 'mods/:id', loadComponent: () => import('./features/mods/mod-detail/mod-detail.component').then(m => m.ModDetailComponent) },
    ]
  },
  { path: '**', redirectTo: '' },
];
