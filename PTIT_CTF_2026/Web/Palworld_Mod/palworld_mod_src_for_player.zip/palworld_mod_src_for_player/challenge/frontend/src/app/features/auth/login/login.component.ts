import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="login-page">
      <div class="login-card">
        <h1>🐾 PalForge</h1>
        <p class="subtitle">Kho mod cộng đồng Palworld</p>

        <form (ngSubmit)="onSubmit()" #f="ngForm">
          <div class="field">
            <label>Tên đăng nhập</label>
            <input type="text" name="username" [(ngModel)]="username" required
                   placeholder="Nhập username" [disabled]="loading" />
          </div>
          <div class="field">
            <label>Mật khẩu</label>
            <input type="password" name="password" [(ngModel)]="password" required
                   placeholder="Nhập mật khẩu" [disabled]="loading" />
          </div>

          @if (error) { <div class="error-msg">{{ error }}</div> }

          <button type="submit" [disabled]="loading || !f.valid" class="btn-login">
            {{ loading ? 'Đang đăng nhập...' : 'Đăng nhập' }}
          </button>
        </form>
        <p class="alt">Chưa có tài khoản? <a routerLink="/register">Đăng ký</a></p>
      </div>
    </div>
  `,
  styles: [`
    .login-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #0f172a; }
    .login-card { background: white; border-radius: 12px; padding: 40px; width: 360px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
    h1 { margin: 0 0 4px; font-size: 22px; color: #1e293b; }
    .subtitle { color: #64748b; font-size: 13px; margin: 0 0 28px; }
    .field { margin-bottom: 16px; }
    label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 6px; }
    input { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; box-sizing: border-box; transition: border-color 0.15s; }
    input:focus { outline: none; border-color: #2563eb; }
    .error-msg { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; padding: 10px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 16px; }
    .btn-login { width: 100%; padding: 11px; background: #2563eb; color: white; border: none; border-radius: 6px; font-size: 15px; font-weight: 500; cursor: pointer; transition: background 0.15s; }
    .btn-login:hover:not(:disabled) { background: #1d4ed8; }
    .btn-login:disabled { background: #93c5fd; cursor: not-allowed; }
    .alt { text-align: center; font-size: 13px; color: #64748b; margin: 18px 0 0; }
    .alt a { color: #2563eb; text-decoration: none; }
  `]
})
export class LoginComponent {
  username = '';
  password = '';
  loading = false;
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit() {
    this.loading = true;
    this.error = '';
    this.auth.login(this.username, this.password).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: () => {
        this.error = 'Tên đăng nhập hoặc mật khẩu không đúng.';
        this.loading = false;
      }
    });
  }
}
