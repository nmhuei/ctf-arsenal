import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private base = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getPlatforms() { return this.http.get<any>(`${this.base}/platforms/`); }
  createPlatform(data: any) { return this.http.post<any>(`${this.base}/platforms/`, data); }
  updatePlatform(id: number, data: any) { return this.http.patch<any>(`${this.base}/platforms/${id}/`, data); }
  deletePlatform(id: number) { return this.http.delete(`${this.base}/platforms/${id}/`); }

  getMods() { return this.http.get<any>(`${this.base}/mods/`); }
  getMod(id: number) { return this.http.get<any>(`${this.base}/mods/${id}/`); }
  createMod(data: any) { return this.http.post<any>(`${this.base}/mods/`, data); }
  updateMod(id: number, data: any) { return this.http.patch<any>(`${this.base}/mods/${id}/`, data); }
  deleteMod(id: number) { return this.http.delete(`${this.base}/mods/${id}/`); }

  createBuild(modId: number, data: any) { return this.http.post<any>(`${this.base}/mods/${modId}/builds/`, data); }
  deleteBuild(modId: number, id: number) { return this.http.delete(`${this.base}/mods/${modId}/builds/${id}/`); }
  uploadBuildFiles(modId: number, buildId: number, formData: FormData) {
    return this.http.post<any>(`${this.base}/mods/${modId}/builds/${buildId}/upload/`, formData);
  }
}
