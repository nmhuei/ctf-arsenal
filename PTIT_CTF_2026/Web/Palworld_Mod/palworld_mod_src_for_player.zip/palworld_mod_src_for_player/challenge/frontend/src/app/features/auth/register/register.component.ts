import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="login-page">
      <div class="login-card">
        <h1>🐾 PalForge</h1>
        <p class="subtitle">Tạo tài khoản đóng góp mod Palworld</p>

        <form (ngSubmit)="onSubmit()" #f="ngForm">
          <div class="field">
            <label>Tên đăng nhập</label>
            <input type="text" name="username" [(ngModel)]="username" required
                   placeholder="vd: modder_01" [disabled]="loading" />
          </div>
          <div class="field">
            <label>Họ tên</label>
            <input type="text" name="full_name" [(ngModel)]="fullName"
                   placeholder="Tên hiển thị" [disabled]="loading" />
          </div>
          <div class="field">
            <label>Mật khẩu <small>(tối thiểu 6 ký tự)</small></label>
            <input type="password" name="password" [(ngModel)]="password" required minlength="6"
                   placeholder="Nhập mật khẩu" [disabled]="loading" />
          </div>

          @if (error) { <div class="error-msg">{{ error }}</div> }
          @if (ok) { <div class="ok-msg">Đăng ký thành công! Đang chuyển tới đăng nhập...</div> }

          <button type="submit" [disabled]="loading || !f.valid" class="btn-login">
            {{ loading ? 'Đang tạo...' : 'Đăng ký' }}
          </button>
        </form>
        <p class="alt">Đã có tài khoản? <a routerLink="/login">Đăng nhập</a></p>
      </div>
    </div>
  `,
  styles: [`
    .login-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #0f172a; }
    .login-card { background: white; border-radius: 12px; padding: 40px; width: 360px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
    h1 { margin: 0 0 4px; font-size: 22px; color: #1e293b; }
    .subtitle { color: #64748b; font-size: 13px; margin: 0 0 28px; }
    .field { margin-bottom: 16px; }
    label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 6px; }
    label small { color: #94a3b8; font-weight: 400; }
    input { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; box-sizing: border-box; transition: border-color 0.15s; }
    input:focus { outline: none; border-color: #2563eb; }
    .error-msg { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; padding: 10px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 16px; }
    .ok-msg { background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; padding: 10px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 16px; }
    .btn-login { width: 100%; padding: 11px; background: #2563eb; color: white; border: none; border-radius: 6px; font-size: 15px; font-weight: 500; cursor: pointer; transition: background 0.15s; }
    .btn-login:hover:not(:disabled) { background: #1d4ed8; }
    .btn-login:disabled { background: #93c5fd; cursor: not-allowed; }
    .alt { text-align: center; font-size: 13px; color: #64748b; margin: 18px 0 0; }
    .alt a { color: #2563eb; text-decoration: none; }
  `]
})
export class RegisterComponent {
  username = '';
  fullName = '';
  password = '';
  loading = false;
  error = '';
  ok = false;

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit() {
    this.loading = true;
    this.error = '';
    this.auth.register(this.username, this.password, this.fullName).subscribe({
      next: () => {
        this.ok = true;
        setTimeout(() => this.router.navigate(['/login']), 1200);
      },
      error: (err: any) => {
        this.error = err.error ? JSON.stringify(err.error) : 'Đăng ký thất bại.';
        this.loading = false;
      }
    });
  }
}
