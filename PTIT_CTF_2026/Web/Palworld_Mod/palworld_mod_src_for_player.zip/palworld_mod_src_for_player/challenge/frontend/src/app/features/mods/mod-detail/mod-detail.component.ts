import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-mod-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-header">
      <div>
        <a routerLink="/mods" class="back-link">← Mods</a>
        <h1>
          {{ mod?.title }} <span class="ver">{{ mod?.mod_version }}</span>
          @if (mod?.is_global) { <span class="badge badge-ok">✓ Đã kiểm duyệt</span> }
          @else { <span class="badge badge-pending">⏳ Chưa kiểm duyệt</span> }
        </h1>
        @if (mod?.release_notes) { <p class="release-notes">{{ mod.release_notes }}</p> }
        @if (mod && !mod.is_global) {
          <p class="hint">Đây là mod của bạn. Đẩy build cho từng platform bên dưới; đội ngũ sẽ kiểm duyệt trước khi lên kho chính thức.</p>
        }
      </div>
    </div>

    <h3 class="section-title">Build theo Platform</h3>

    <div class="builds-grid">
      @for (p of platforms; track p.id) {
        <div class="build-card" [class.has-build]="getBuild(p.id)">
          <div class="build-header">
            <code class="code-badge">{{ p.code }}</code>
            @if (getBuild(p.id)) { <span class="badge badge-ok">✓ Đã có build</span> }
            @else { <span class="badge badge-missing">✗ Chưa có</span> }
          </div>
          <p class="p-name">{{ p.name }}</p>
          @if (getBuild(p.id); as build) {
            <div class="build-meta"><small>Cập nhật: {{ build.updated_at | date:'dd/MM/yy HH:mm' }}</small></div>
            @if (build.filelist_content) {
              <pre class="filelist">{{ build.filelist_content }}</pre>
            }
            @if (canEdit()) {
              <div class="build-actions">
                <button class="btn btn-sm btn-primary" (click)="openForm(p, build)">Đẩy lại</button>
                <button class="btn btn-sm btn-danger" (click)="confirmDelete(build)">Xóa</button>
              </div>
            }
          } @else if (canEdit()) {
            <button class="btn btn-sm btn-primary" (click)="openForm(p, null)">+ Đẩy build</button>
          }
        </div>
      }
    </div>

    @if (showForm) {
      <div class="modal-overlay" (click)="closeForm()">
        <div class="modal modal-lg" (click)="$event.stopPropagation()">
          <h3>Đẩy build — {{ selectedPlatform?.code }}</h3>
          <form (ngSubmit)="save()">
            <div class="field">
              <label>File filelist <small>(text: danh sách file + MD5)</small></label>
              <div class="drop-zone" (click)="filelistInput.click()"
                   (dragover)="$event.preventDefault()" (drop)="onDropFilelist($event)">
                <input #filelistInput type="file" hidden (change)="onFilelistSelected($event)" />
                @if (filelistFile) {
                  <div class="file-chosen">
                    <span class="file-name">{{ filelistFile.name }}</span>
                    <span class="file-size">{{ formatSize(filelistFile.size) }}</span>
                    <button type="button" class="clear-btn" (click)="$event.stopPropagation(); filelistFile = null">✕</button>
                  </div>
                } @else {
                  <div class="drop-hint"><span>Kéo thả hoặc click để chọn file filelist</span></div>
                }
              </div>
            </div>

            <div class="field">
              <label>Bộ file build <small>(ZIP — server giải nén & tính MD5)</small></label>
              <div class="drop-zone" (click)="zipInput.click()"
                   (dragover)="$event.preventDefault()" (drop)="onDropZip($event)">
                <input #zipInput type="file" accept=".zip" hidden (change)="onZipSelected($event)" />
                @if (zipFile) {
                  <div class="file-chosen">
                    <span class="file-name">{{ zipFile.name }}</span>
                    <span class="file-size">{{ formatSize(zipFile.size) }}</span>
                    <button type="button" class="clear-btn" (click)="$event.stopPropagation(); zipFile = null">✕</button>
                  </div>
                } @else {
                  <div class="drop-hint"><span>Kéo thả hoặc click để chọn file ZIP</span></div>
                }
              </div>
            </div>

            @if (formError) { <div class="error-msg">{{ formError }}</div> }
            <div class="modal-actions">
              <button type="button" class="btn" (click)="closeForm()">Huỷ</button>
              <button type="submit" class="btn btn-primary" [disabled]="saving">
                {{ saving ? 'Đang đẩy...' : 'Đẩy build' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    }
  `,
  styles: [`
    .page-header { margin-bottom: 24px; }
    .back-link { color: #2563eb; text-decoration: none; font-size: 13px; }
    .page-header h1 { margin: 4px 0 8px; font-size: 24px; color: #1e293b; }
    .page-header .ver { font-size: 14px; background: #f1f5f9; padding: 3px 8px; border-radius: 4px; vertical-align: middle; }
    .page-header h1 .badge { font-size: 11px; vertical-align: middle; margin-left: 6px; }
    .badge-ok { background: #dcfce7; color: #15803d; }
    .badge-pending { background: #fef3c7; color: #b45309; }
    .release-notes { color: #64748b; font-size: 13px; margin: 0; }
    .hint { color: #1d4ed8; font-size: 12px; margin: 8px 0 0; }
    .section-title { font-size: 15px; color: #374151; margin: 0 0 16px; }
    .builds-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }
    .build-card { background: white; border-radius: 10px; padding: 18px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); border: 2px solid #f1f5f9; }
    .build-card.has-build { border-color: #bbf7d0; }
    .build-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .code-badge { background: #1e293b; color: #e2e8f0; padding: 3px 8px; border-radius: 4px; font-size: 13px; }
    .badge { padding: 3px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
    .badge-ok { background: #dcfce7; color: #15803d; }
    .badge-missing { background: #f1f5f9; color: #94a3b8; }
    .p-name { font-size: 12px; color: #64748b; margin: 0 0 12px; }
    .build-meta small { font-size: 11px; color: #94a3b8; }
    .filelist { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px; font-size: 11px; color: #374151; max-height: 80px; overflow: auto; margin: 8px 0 0; }
    .build-actions { display: flex; gap: 6px; margin-top: 10px; }
    .btn { padding: 7px 14px; border-radius: 6px; border: 1px solid #e2e8f0; background: white; cursor: pointer; font-size: 13px; }
    .btn-primary { background: #2563eb; color: white; border-color: #2563eb; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }
    .btn-danger { background: #fee2e2; color: #dc2626; border-color: #fecaca; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; z-index: 100; }
    .modal { background: white; border-radius: 10px; padding: 28px; width: 520px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); }
    .modal-lg { width: 600px; }
    .modal h3 { margin: 0 0 20px; }
    .field { margin-bottom: 14px; }
    label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 5px; }
    label small { color: #94a3b8; font-weight: 400; }
    .error-msg { background: #fef2f2; color: #dc2626; padding: 9px 12px; border-radius: 6px; font-size: 13px; margin-bottom: 12px; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px; }
    .drop-zone { border: 2px dashed #cbd5e1; border-radius: 8px; padding: 16px 20px; cursor: pointer; transition: all 0.15s; }
    .drop-zone:hover { border-color: #2563eb; background: #f8faff; }
    .drop-hint span { display: block; font-size: 13px; color: #374151; }
    .file-chosen { display: flex; align-items: center; gap: 10px; }
    .file-name { color: #1e293b; font-family: monospace; font-size: 13px; flex: 1; word-break: break-all; }
    .file-size { color: #94a3b8; font-size: 12px; flex-shrink: 0; }
    .clear-btn { background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 14px; padding: 0 4px; }
    .clear-btn:hover { color: #dc2626; }
  `]
})
export class ModDetailComponent implements OnInit {
  mod: any = null;
  platforms: any[] = [];
  builds: any[] = [];
  showForm = false;
  editingBuild: any = null;
  selectedPlatform: any = null;
  formError = '';
  saving = false;
  filelistFile: File | null = null;
  zipFile: File | null = null;

  constructor(public auth: AuthService, private api: ApiService, private route: ActivatedRoute) {}

  ngOnInit() {
    const id = +this.route.snapshot.params['id'];
    this.api.getMod(id).subscribe(m => { this.mod = m; this.builds = m.builds ?? []; });
    this.api.getPlatforms().subscribe((res: any) => {
      this.platforms = (res.results ?? res).filter((p: any) => p.is_enabled);
    });
  }

  getBuild(platformId: number) {
    return this.builds.find(b => b.platform === platformId) ?? null;
  }

  canEdit(): boolean {
    if (!this.mod) return false;
    return !this.mod.is_global || this.auth.isAdmin();
  }

  openForm(platform: any, build: any) {
    this.selectedPlatform = platform;
    this.editingBuild = build;
    this.formError = '';
    this.filelistFile = null;
    this.zipFile = null;
    this.showForm = true;
  }

  closeForm() { this.showForm = false; }

  onFilelistSelected(e: Event) { const i = e.target as HTMLInputElement; if (i.files?.[0]) this.filelistFile = i.files[0]; }
  onDropFilelist(e: DragEvent) { e.preventDefault(); if (e.dataTransfer?.files?.[0]) this.filelistFile = e.dataTransfer.files[0]; }
  onZipSelected(e: Event) { const i = e.target as HTMLInputElement; if (i.files?.[0]) this.zipFile = i.files[0]; }
  onDropZip(e: DragEvent) { e.preventDefault(); if (e.dataTransfer?.files?.[0]) this.zipFile = e.dataTransfer.files[0]; }

  formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }

  save() {
    if (!this.filelistFile && !this.zipFile) { this.formError = 'Chọn ít nhất một file.'; return; }
    this.saving = true;
    this.formError = '';

    const doUpload = (buildId: number) => {
      const fd = new FormData();
      if (this.filelistFile) fd.append('filelist_file', this.filelistFile);
      if (this.zipFile) fd.append('zip_file', this.zipFile);
      this.api.uploadBuildFiles(this.mod.id, buildId, fd).subscribe({
        next: () => { this.saving = false; this.closeForm(); this.reload(); },
        error: (err: any) => { this.saving = false; this.formError = JSON.stringify(err.error); }
      });
    };

    if (this.editingBuild) {
      doUpload(this.editingBuild.id);
    } else {
      this.api.createBuild(this.mod.id, { platform: this.selectedPlatform.id }).subscribe({
        next: (b: any) => doUpload(b.id),
        error: (err: any) => { this.saving = false; this.formError = JSON.stringify(err.error); }
      });
    }
  }

  private reload() {
    this.api.getMod(this.mod.id).subscribe(m => { this.mod = m; this.builds = m.builds ?? []; });
  }

  confirmDelete(build: any) {
    if (!confirm('Xóa build này?')) return;
    this.api.deleteBuild(this.mod.id, build.id).subscribe(() => {
      this.builds = this.builds.filter((b: any) => b.id !== build.id);
    });
  }
}
