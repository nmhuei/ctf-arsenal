#define _GNU_SOURCE

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static void fail(const char *message) {
  perror(message);
  exit(EXIT_FAILURE);
}

int main(void) {
  char buffer[4096];
  ssize_t count;
  int fd;

  if (setresgid(0, 0, 0) != 0) fail("setresgid");
  if (setresuid(0, 0, 0) != 0) fail("setresuid");

  fd = open("/flag", O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
  if (fd < 0) fail("open /flag");

  while ((count = read(fd, buffer, sizeof(buffer))) > 0) {
    ssize_t written = 0;
    while (written < count) {
      ssize_t result = write(STDOUT_FILENO, buffer + written,
                             (size_t)(count - written));
      if (result < 0) {
        if (errno == EINTR) continue;
        fail("write");
      }
      written += result;
    }
  }

  if (count < 0) fail("read /flag");
  if (close(fd) != 0) fail("close /flag");
  return EXIT_SUCCESS;
}

