#!/bin/sh
set -eu
ulimit -c 0

work_dir="$(mktemp -d /tmp/v8-challenge.XXXXXX)"
exp_file="${work_dir}/exp.js"
trap 'rm -rf "${work_dir}"' EXIT HUP INT TERM

# First line = exact payload length in bytes.
IFS= read -r payload_len

case "${payload_len}" in
  ''|*[!0-9]*)
    echo "invalid payload length" >&2
    exit 1
    ;;
esac

# Optional size limit.
if [ "${payload_len}" -gt 1048576 ]; then
  echo "payload too large" >&2
  exit 1
fi

# Read EXACTLY payload_len bytes.
# No newline or other byte gets added to exp.js.
head -c "${payload_len}" > "${exp_file}"

# Reject truncated payloads.
actual_len="$(wc -c < "${exp_file}")"
if [ "${actual_len}" -ne "${payload_len}" ]; then
  echo "short payload" >&2
  exit 1
fi

timeout 90s /challenge/d8 \
  --log-code \
  --logfile=+ \
  "${exp_file}"