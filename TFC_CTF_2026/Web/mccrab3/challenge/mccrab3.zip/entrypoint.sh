#!/bin/bash

nohup ./proxoxy config.json >/proxoxy.log 2>&1 &
gunicorn -w 1 -k gthread --threads 4 --keep-alive 30 -b 0.0.0.0:8900 server:app
