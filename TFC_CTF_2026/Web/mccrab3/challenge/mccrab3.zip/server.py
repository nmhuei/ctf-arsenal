from flask import Flask, Response, request
import random
from threading import Lock
import os

app = Flask(__name__)

FLAG = os.getenv("FLAG", "TFCCTF{fake_flag}")

GAME_STATS = None
CASH = 0
GAME_LOCK = Lock()

@app.route("/health", methods=["GET"])
def health():
    return Response("OK", mimetype="text/plain")

# to get the flag you need to win this game
@app.route("/random_ahh_game", methods=["GET", "PLAY", "RESET", "STOP", "CHEAT", "FLAG"])
def random_ahh_game():
    global CASH
    global GAME_STATS

    if request.method == "GET":
        return Response("ts ah random ahh game if you get bored. draw numbers, if you draw the same number you lose", mimetype="text/plain")

    if request.method == "PLAY":
        with GAME_LOCK:
            if GAME_STATS is None:
                GAME_STATS = {
                    "drawn_numbers": [],
                    "draw_count": 0,
                    "used_cheat": False
                }

            pick = None
            for _ in range(random.randint(1, 10000)):
                pick = random.randint(1, 69)

            if pick in GAME_STATS["drawn_numbers"]:
                CASH = max(0, CASH - 1337)
                GAME_STATS = None
                return Response(f"You lose! You now have ${CASH}", mimetype="text/plain")

            GAME_STATS["drawn_numbers"].append(pick)
            GAME_STATS["draw_count"] += 1
            return Response(f"You have drawn {GAME_STATS['draw_count']} numbers so far. You can stop any timeski brevski", mimetype="text/plain")

    if request.method == "STOP":
        with GAME_LOCK:
            if GAME_STATS is None:
                return Response("You haven't started a game yet!", mimetype="text/plain")
            elif GAME_STATS["draw_count"] < 10:
                return Response(f"You need to draw at least 10 numbers before stopping the game! You have drawn {GAME_STATS['draw_count']} numbers so far.", mimetype="text/plain")
            else:
                drawn_numbers = GAME_STATS["drawn_numbers"]
                draw_count = GAME_STATS["draw_count"]
                CASH += draw_count ** 2
                bruh = ""
                if draw_count == 60:
                    bruh = "here is the flagski: " + FLAG
                GAME_STATS = None
                return Response(f"You stopped the game! You drew {draw_count} numbers: {drawn_numbers[:random.randint(1, len(drawn_numbers))]}). You now have ${CASH}. {bruh}", mimetype="text/plain")

    if request.method == "CHEAT":
        with GAME_LOCK:
            if GAME_STATS is None:
                return Response("You haven't started a game yet!", mimetype="text/plain")
            elif GAME_STATS["used_cheat"]:
                return Response("You have already used the cheat option in this game!", mimetype="text/plain")
            else:
                GAME_STATS["used_cheat"] = True
                cheat_number = request.get_json().get("cheat_number")
                print(f"Cheat number received: {cheat_number}")
                if not isinstance(cheat_number, int) or not (1 <= cheat_number <= 69):
                    return Response("Invalid cheat number! Please provide a number between 1 and 69.", mimetype="text/plain")
                while cheat_number in GAME_STATS["drawn_numbers"]:
                    cheat_number = random.randint(1, 69)
                GAME_STATS["drawn_numbers"].append(cheat_number)
                GAME_STATS["draw_count"] += 1
                return Response(f"You used the cheat option! The number {cheat_number} has been added to your drawn numbers.", mimetype="text/plain")

    if request.method == "RESET":
        with GAME_LOCK:
            GAME_STATS = None
            return Response("Game has been reset.", mimetype="text/plain")


@app.route("/flag", methods=["POST"])
def flag():
    if request.headers.get("brevski") == "george":
        return Response(FLAG, mimetype="text/plain")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8900, threaded=True, debug=False)
