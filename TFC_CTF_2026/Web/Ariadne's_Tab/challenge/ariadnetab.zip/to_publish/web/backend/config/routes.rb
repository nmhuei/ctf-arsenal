Rails.application.routes.draw do
  constraints(host: ENV.fetch("APP_DOMAIN", "documents.example.com")) do
    post "/api/documents/list", to: "api/documents#index"
    post "/api/documents/create", to: "api/documents#create"
    post "/api/documents/open", to: "api/documents#open"
    post "/api/key/get", to: "api/keys#show"
    post "/api/key/register", to: "api/keys#create"
    post "/api/render", to: "content#show"

    get "/.well-known/assetlinks.json", to: "asset_links#show"
  end
end
