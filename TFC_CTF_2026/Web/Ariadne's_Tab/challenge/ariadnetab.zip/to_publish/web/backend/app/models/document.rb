class Document < ApplicationRecord
  MAX_CIPHERTEXT_BYTES = 1.megabyte + 16

  before_create { self.id ||= SecureRandom.uuid }

  validates :owner_sub, presence: true, length: { maximum: 255 }
  validates :name, presence: true, length: { maximum: 255 }
  validates :mime_type,
    presence: true,
    length: { maximum: 255 },
    format: { with: /\A[\w.+-]+\/[\w.+-]+\z/ }
  validates :ciphertext, presence: true, length: { maximum: MAX_CIPHERTEXT_BYTES }
  validates :iv, length: { is: 12 }
  validates :wrapped_key, length: { is: 384 }
end
