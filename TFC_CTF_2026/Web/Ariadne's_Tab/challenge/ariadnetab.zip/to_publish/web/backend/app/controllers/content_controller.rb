require "base64"

class ContentController < ActionController::API
  def show
    payload = Capability.verify(params.require(:cap), "render")
    document = Document.find_by(id: payload.fetch("document_id"))
    return head :not_found unless document

    render json: {
      ciphertext: Base64.strict_encode64(document.ciphertext),
      iv: Base64.strict_encode64(document.iv),
      mime_type: document.mime_type
    }
  rescue Capability::Invalid, KeyError, ActionController::ParameterMissing
    head :not_found
  end
end
