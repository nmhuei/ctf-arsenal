require "openssl"

class UserKey < ApplicationRecord
  self.primary_key = :owner_sub

  validates :owner_sub, presence: true, length: { maximum: 255 }
  validate :rsa_3072_spki

  private

  def rsa_3072_spki
    key = OpenSSL::PKey.read(public_key)

    valid = key.is_a?(OpenSSL::PKey::RSA)
    valid &&= key.n.num_bits == 3072
    valid &&= key.e.to_i == 65_537
    valid &&= key.public_to_der == public_key

    errors.add(:public_key, "must be a 3072-bit RSA SPKI key") unless valid
  rescue OpenSSL::PKey::PKeyError, TypeError
    errors.add(:public_key, "must be a 3072-bit RSA SPKI key")
  end
end
