require "base64"

module Api
  class KeysController < BaseController
    def show
      key = UserKey.find_by(owner_sub: current_sub)
      return head :not_found unless key

      render json: { public_key: Base64.strict_encode64(key.public_key) }
    end

    def create
      public_key = Base64.strict_decode64(params.require(:public_key).to_s)
      key = UserKey.find_by(owner_sub: current_sub)
      created = key.nil?
      key ||= UserKey.new(owner_sub: current_sub)
      key.public_key = public_key

      if key.save
        status = created ? :created : :ok
        render json: { public_key: Base64.strict_encode64(key.public_key) }, status: status
      else
        render json: { errors: key.errors.full_messages }, status: :unprocessable_content
      end
    rescue ActionController::ParameterMissing, ArgumentError
      render json: { error: "invalid public key" }, status: :unprocessable_content
    end
  end
end
