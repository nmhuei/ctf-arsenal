class CorsMiddleware
  HEADERS = {
    "access-control-allow-origin" => "https://#{ENV.fetch("CONTENT_DOMAIN")}",
    "access-control-allow-headers" => "*",
    "access-control-allow-methods" => "GET, POST, OPTIONS"
  }.freeze

  def initialize(app)
    @app = app
  end

  def call(env)
    return [204, HEADERS.dup, []] if env["REQUEST_METHOD"] == "OPTIONS"

    status, headers, body = @app.call(env)
    [status, headers.merge(HEADERS), body]
  end
end

Rails.application.config.middleware.insert_before 0, CorsMiddleware
