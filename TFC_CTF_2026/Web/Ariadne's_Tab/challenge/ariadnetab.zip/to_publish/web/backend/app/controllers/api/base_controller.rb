module Api
  class BaseController < ActionController::API
    before_action :authenticate!

    attr_reader :current_sub

    private

    def authenticate!
      scheme, token = request.authorization.to_s.split(" ", 2)
      raise JwtAuthenticator::InvalidToken unless scheme&.casecmp?("Bearer")

      @current_sub = JwtAuthenticator.authenticate(token).fetch("sub")
    rescue JwtAuthenticator::InvalidToken
      render json: { error: "unauthorized" }, status: :unauthorized
    end

    def owned_document
      @owned_document ||= Document.where(owner_sub: current_sub).find_by(id: params[:id])
      head :not_found unless @owned_document
      @owned_document
    end
  end
end
