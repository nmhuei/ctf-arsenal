require "json"
require "net/http"
require "jwt"

class JwtAuthenticator
  class InvalidToken < StandardError; end

  CACHE_TTL = 5.minutes

  def self.authenticate(token)
    raise InvalidToken, "missing bearer token" if token.blank?

    payload, = JWT.decode(
      token,
      nil,
      true,
      algorithms: ["RS256"],
      iss: issuer,
      verify_iss: true,
      aud: audience,
      verify_aud: true,
      jwks: jwks
    )
    raise InvalidToken, "missing subject" unless payload["sub"].is_a?(String) && payload["sub"].present?

    payload
  rescue JWT::DecodeError, JSON::ParserError, KeyError, URI::InvalidURIError => error
    raise InvalidToken, error.message
  end

  def self.issuer
    "https://#{ENV.fetch("AUTH0_DOMAIN")}/"
  end

  def self.audience
    ENV.fetch("API_AUDIENCE")
  end

  def self.jwks
    inline = ENV["AUTH0_JWKS_JSON"]
    return JSON.parse(inline, symbolize_names: true) if inline.present?

    now = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    return @jwks if @jwks && now - @jwks_loaded_at < CACHE_TTL

    uri = URI.join(issuer, ".well-known/jwks.json")
    response = Net::HTTP.get_response(uri)
    raise InvalidToken, "JWKS fetch failed" unless response.is_a?(Net::HTTPSuccess)

    @jwks = JSON.parse(response.body, symbolize_names: true)
    @jwks_loaded_at = now
    @jwks
  end
  private_class_method :jwks
end
