# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_08_25_000000) do
  create_table "documents", id: :string, force: :cascade do |t|
    t.binary "ciphertext", null: false
    t.binary "iv", null: false
    t.string "mime_type", null: false
    t.string "name", null: false
    t.string "owner_sub", null: false
    t.binary "wrapped_key", null: false
    t.index ["owner_sub"], name: "index_documents_on_owner_sub"
  end

  create_table "user_keys", id: false, force: :cascade do |t|
    t.string "owner_sub", null: false, primary_key: true
    t.binary "public_key", null: false
  end
end
