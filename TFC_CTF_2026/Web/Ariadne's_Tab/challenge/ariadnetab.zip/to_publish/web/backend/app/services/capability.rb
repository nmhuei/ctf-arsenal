require "securerandom"

class Capability
  class Invalid < StandardError; end

  LIFETIMES = {
    "render" => 60.minutes
  }.freeze

  def self.issue(document_id, purpose)
    verifier.generate(
      { "document_id" => document_id, "nonce" => SecureRandom.hex(16) },
      expires_in: LIFETIMES.fetch(purpose),
      purpose: purpose
    )
  end

  def self.verify(token, purpose)
    verifier.verified(token, purpose: purpose) || raise(Invalid)
  rescue ActiveSupport::MessageVerifier::InvalidSignature
    raise Invalid
  end

  def self.verifier
    Rails.application.message_verifier("document-capabilities")
  end
  private_class_method :verifier
end
