class CreateDocuments < ActiveRecord::Migration[8.1]
  def change
    create_table :documents, id: false do |t|
      t.string :id, null: false, primary_key: true
      t.string :owner_sub, null: false
      t.string :name, null: false
      t.string :mime_type, null: false
      t.binary :ciphertext, null: false
      t.binary :iv, null: false
      t.binary :wrapped_key, null: false
    end

    add_index :documents, :owner_sub

    create_table :user_keys, id: false do |t|
      t.string :owner_sub, null: false, primary_key: true
      t.binary :public_key, null: false
    end
  end
end
