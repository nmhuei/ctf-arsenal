class AssetLinksController < ApplicationController
  def show
    render json: [{
      relation: [
        "delegate_permission/common.use_as_origin",
        "delegate_permission/common.handle_all_urls"
      ],
      target: {
        namespace: "android_app",
        package_name: ENV.fetch("ANDROID_APPLICATION_ID", "com.tfcctf.ariadnetab"),
        sha256_cert_fingerprints: [ENV.fetch("ANDROID_CERTIFICATE_SHA256")]
      }
    }]
  end
end
