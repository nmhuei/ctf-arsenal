require "base64"

module Api
  class DocumentsController < BaseController
    before_action :owned_document, only: :open

    def index
      documents = Document.where(owner_sub: current_sub).order(:name)
      render json: documents.map { |document| summary(document) }
    end

    def create
      document = Document.new(
        owner_sub: current_sub,
        name: params.require(:name),
        mime_type: params.require(:mime_type),
        ciphertext: decode(params.require(:ciphertext)),
        iv: decode(params.require(:iv)),
        wrapped_key: decode(params.require(:wrapped_key))
      )
      if document.save
        render json: summary(document), status: :created
      else
        render json: { errors: document.errors.full_messages }, status: :unprocessable_content
      end
    rescue ActionController::ParameterMissing, ArgumentError
      render json: { error: "invalid document" }, status: :unprocessable_content
    end

    def open
      return unless @owned_document

      render json: {
        cap: Capability.issue(@owned_document.id, "render"),
        wrapped_key: Base64.strict_encode64(@owned_document.wrapped_key)
      }
    end

    private

    def decode(value)
      Base64.strict_decode64(value.to_s)
    end

    def summary(document)
      document.as_json(only: %i[id name mime_type])
    end
  end
end
