const RSA_OAEP = { name: "RSA-OAEP", hash: "SHA-256" };
const AES_GCM = { name: "AES-GCM", length: 256 };

export function decodeBase64(value) {
  return Uint8Array.from(
    atob(value),
    (character) => character.charCodeAt(0)
  );
}

export function encodeBase64(value) {
  const bytes = new Uint8Array(value);
  let binary = "";

  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }

  return btoa(binary);
}

export function encodeBase64Url(value) {
  return encodeBase64(value)
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replace(/=+$/, "");
}

export async function importDeviceKeyPair(encoded) {
  const privateKey = await crypto.subtle.importKey(
    "pkcs8",
    decodeBase64(encoded.privateKey),
    RSA_OAEP,
    false,
    ["decrypt"]
  );
  const publicKey = await crypto.subtle.importKey(
    "spki",
    decodeBase64(encoded.publicKey),
    RSA_OAEP,
    false,
    ["encrypt"]
  );

  return { privateKey, publicKey };
}

export async function encryptFile(file, publicKey) {
  const key = await crypto.subtle.generateKey(AES_GCM, true, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, tagLength: 128 },
    key,
    await file.arrayBuffer()
  );
  const rawKey = await crypto.subtle.exportKey("raw", key);
  const wrappedKey = await crypto.subtle.encrypt(
    { name: "RSA-OAEP" },
    publicKey,
    rawKey
  );

  return { ciphertext, iv, wrappedKey };
}

export async function unwrapDocumentKey(encodedWrappedKey, privateKey) {
  const key = await crypto.subtle.decrypt(
    { name: "RSA-OAEP" },
    privateKey,
    decodeBase64(encodedWrappedKey)
  );

  if (key.byteLength !== 32) throw new Error("Invalid document key");
  return key;
}
