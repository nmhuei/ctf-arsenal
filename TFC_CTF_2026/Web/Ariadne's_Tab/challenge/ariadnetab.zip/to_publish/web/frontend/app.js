import {
  encodeBase64,
  encodeBase64Url,
  encryptFile,
  importDeviceKeyPair,
  unwrapDocumentKey
} from "/document-crypto.js";
import { getDeviceKeyPair, waitForNativeChannel } from "/native-rpc.js";

const config = window.DOCUMENTS_CONFIG;
const elements = {
  documents: document.getElementById("documents"),
  file: document.getElementById("file"),
  login: document.getElementById("login"),
  status: document.getElementById("status"),
  upload: document.getElementById("upload")
};
const storageKeys = {
  privateKey: "rsaPrivateKeyPkcs8",
  publicKey: "rsaPublicKeySpki"
};
const openRoute = /^#\/open\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/;

let auth;
let api;
let encodedKeysPromise;
let deviceKeysPromise;

class Api {
  constructor(token) {
    this.token = token;
  }

  async post(path, body = {}) {
    const response = await fetch(`/api/${path}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });
    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message = response.status === 404
        ? "Document not found."
        : result.error || result.errors?.join(", ") || "Request failed";
      throw new Error(message);
    }

    return result;
  }
}

function setStatus(message = "") {
  elements.status.textContent = message;
}

async function run(action) {
  try {
    setStatus();
    await action();
  } catch (error) {
    setStatus(error.message);
  }
}

function externalDocumentId() {
  return location.hash.match(openRoute)?.[1];
}

function storedKeyPair() {
  const privateKey = localStorage.getItem(storageKeys.privateKey);
  const publicKey = localStorage.getItem(storageKeys.publicKey);
  return privateKey && publicKey ? { privateKey, publicKey } : null;
}

function saveKeyPair(keys) {
  localStorage.setItem(storageKeys.privateKey, keys.privateKey);
  localStorage.setItem(storageKeys.publicKey, keys.publicKey);
}

function isAuthCallback() {
  return location.search.includes("code=") && location.search.includes("state=");
}

async function loadEncodedKeys() {
  let encoded = storedKeyPair();
  let port;
  const skipChannel = isAuthCallback() && Boolean(encoded);

  if (!skipChannel) {
    try {
      port = await waitForNativeChannel();
    } catch (error) {
      if (!encoded) throw error;
    }
  }

  if (!encoded) {
    encoded = await getDeviceKeyPair(port);
    saveKeyPair(encoded);
  }

  return encoded;
}

function encodedDeviceKeys() {
  encodedKeysPromise ||= loadEncodedKeys();
  return encodedKeysPromise;
}

async function loadDeviceKeys() {
  const encoded = await encodedDeviceKeys();

  const keys = await importDeviceKeyPair(encoded);
  await api.post("key/register", { public_key: encoded.publicKey });
  return keys;
}

function deviceKeys() {
  deviceKeysPromise ||= loadDeviceKeys();
  return deviceKeysPromise;
}

function documentRow(item) {
  const row = document.createElement("div");
  const name = document.createElement("span");
  const open = document.createElement("button");

  row.className = "document";
  name.className = "name";
  name.textContent = item.name;
  open.type = "button";
  open.textContent = "Open";
  open.addEventListener("click", () => run(() => openDocument(item.id)));
  row.append(name, open);
  return row;
}

async function refreshDocuments() {
  const documents = await api.post("documents/list");
  elements.documents.replaceChildren(...documents.map(documentRow));
}

async function viewerUrl(documentId) {
  const envelope = await api.post("documents/open", { id: documentId });
  const { privateKey } = await deviceKeys();
  const key = await unwrapDocumentKey(envelope.wrapped_key, privateKey);
  const fragment = new URLSearchParams({
    cap: envelope.cap,
    key: encodeBase64Url(key)
  });

  return `https://${config.contentDomain}/viewer.html#${fragment}`;
}

async function openDocument(documentId) {
  location.assign(await viewerUrl(documentId));
}

async function openExternalDocument(documentId) {
  location.replace(await viewerUrl(documentId));
}

async function uploadDocument(file) {
  const { publicKey } = await deviceKeys();
  const encrypted = await encryptFile(file, publicKey);

  await api.post("documents/create", {
    name: file.name,
    mime_type: file.type || "text/plain",
    ciphertext: encodeBase64(encrypted.ciphertext),
    iv: encodeBase64(encrypted.iv),
    wrapped_key: encodeBase64(encrypted.wrappedKey)
  });

  elements.file.value = "";
  await refreshDocuments();
}

async function createAuthClient() {
  return window.auth0.createAuth0Client({
    domain: config.auth0Domain,
    clientId: config.auth0ClientId,
    authorizationParams: {
      audience: config.auth0Audience,
      redirect_uri: `${location.origin}/`
    },
    cacheLocation: "localstorage",
    useRefreshTokens: false
  });
}

async function finishAuthCallback() {
  if (!isAuthCallback()) return;

  const result = await auth.handleRedirectCallback();
  const requestedRoute = result.appState?.returnTo || "";
  const returnTo = openRoute.test(requestedRoute) ? requestedRoute : "";
  history.replaceState({}, "", `/${returnTo}`);
}

async function signIn() {
  await auth.loginWithRedirect({ appState: { returnTo: location.hash } });
}

async function accessToken() {
  try {
    return await auth.getTokenSilently();
  } catch {
    if (externalDocumentId()) {
      await signIn();
    } else {
      elements.login.hidden = false;
      setStatus("Sign in to view documents.");
    }
    return null;
  }
}

async function start() {
  await encodedDeviceKeys();

  auth = await createAuthClient();
  await finishAuthCallback();

  const token = await accessToken();
  if (!token) return;

  api = new Api(token);
  elements.upload.disabled = false;
  await deviceKeys();

  const documentId = externalDocumentId();
  if (documentId) {
    await openExternalDocument(documentId);
    return;
  }

  await refreshDocuments();
}

elements.login.addEventListener("click", () => run(signIn));
elements.upload.addEventListener("click", () => elements.file.click());
elements.file.addEventListener("change", () => {
  const selected = elements.file.files[0];
  if (selected) run(() => uploadDocument(selected));
});

run(start);
