const CHANNEL_TIMEOUT_MS = 8_000;
const RPC_TIMEOUT_MS = 4_000;

function withTimeout(promise, delay, message) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = window.setTimeout(() => reject(new Error(message)), delay);
  });

  return Promise.race([promise, timeout]).finally(() => window.clearTimeout(timer));
}

export function waitForNativeChannel() {
  return withTimeout(
    window.DOCUMENTS_NATIVE_PORT,
    CHANNEL_TIMEOUT_MS,
    "Native channel unavailable"
  );
}

export async function getDeviceKeyPair(port) {
  const id = 1;
  const response = new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      port.removeEventListener("message", receive);
      reject(new Error("Native RPC response unavailable"));
    }, RPC_TIMEOUT_MS);

    function receive(event) {
      let message;

      try {
        message = JSON.parse(event.data);
      } catch {
        return;
      }

      if (message.id !== id) return;

      window.clearTimeout(timer);
      port.removeEventListener("message", receive);
      if (message.error) {
        reject(new Error(message.error.message || "Native RPC failed"));
      } else {
        resolve(message.result);
      }
    }

    port.addEventListener("message", receive);
    port.postMessage(JSON.stringify({ id, method: "key.get", params: {} }));
  });

  return response;
}
