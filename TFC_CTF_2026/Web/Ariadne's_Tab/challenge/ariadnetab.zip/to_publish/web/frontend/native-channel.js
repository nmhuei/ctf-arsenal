"use strict";

window.DOCUMENTS_NATIVE_PORT = new Promise((resolve) => {
  const expectedOrigin = `android-app://${location.hostname}`;

  function capturePort(event) {
    const port = event.ports[0];
    if (event.origin !== expectedOrigin || !port) return;

    window.removeEventListener("message", capturePort);
    port.start();
    resolve(port);
  }

  window.addEventListener("message", capturePort);
});
