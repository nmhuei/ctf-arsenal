"use strict";

const config = window.DOCUMENTS_CONTENT_CONFIG;

function decodeBase64(value) {
  const base64 = value
    .replaceAll("-", "+")
    .replaceAll("_", "/")
    .padEnd(Math.ceil(value.length / 4) * 4, "=");

  return Uint8Array.from(
    atob(base64),
    (character) => character.charCodeAt(0)
  );
}

function documentUrl() {
  const fragment = new URLSearchParams(location.hash.slice(1));
  const cap = fragment.get("cap");
  const key = fragment.get("key");

  if (!cap || !key) throw new Error("Invalid document URL");
  return { cap, key: decodeBase64(key) };
}

async function fetchEnvelope(cap) {
  const response = await fetch(`${config.appOrigin}/api/render`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cap })
  });

  if (!response.ok) throw new Error("Document unavailable");
  return response.json();
}

async function decryptDocument(envelope, rawKey) {
  if (rawKey.length !== 32) throw new Error("Invalid document key");

  const key = await crypto.subtle.importKey(
    "raw",
    rawKey,
    "AES-GCM",
    false,
    ["decrypt"]
  );

  return crypto.subtle.decrypt(
    { name: "AES-GCM", iv: decodeBase64(envelope.iv), tagLength: 128 },
    key,
    decodeBase64(envelope.ciphertext)
  );
}

function renderDocument(plaintext, mimeType) {
  const text = new TextDecoder().decode(plaintext);

  if (mimeType === "text/html") {
    document.open();
    document.write(text);
    document.close();
    return;
  }

  const output = document.createElement("pre");
  output.textContent = text;
  document.body.replaceChildren(output);
}

async function start() {
  const { cap, key } = documentUrl();
  const envelope = await fetchEnvelope(cap);
  const plaintext = await decryptDocument(envelope, key);
  renderDocument(plaintext, envelope.mime_type);
}

start().catch((error) => {
  document.getElementById("status").textContent = error.message;
});
