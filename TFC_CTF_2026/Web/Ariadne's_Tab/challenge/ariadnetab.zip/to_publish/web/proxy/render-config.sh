#!/bin/sh
set -eu

: "${APP_DOMAIN:?APP_DOMAIN is required}"
: "${CONTENT_DOMAIN:?CONTENT_DOMAIN is required}"
: "${AUTH0_DOMAIN:?AUTH0_DOMAIN is required}"
: "${AUTH0_WEB_CLIENT_ID:?AUTH0_WEB_CLIENT_ID is required}"
: "${API_AUDIENCE:?API_AUDIENCE is required}"

envsubst '${APP_DOMAIN} ${CONTENT_DOMAIN}' \
  < /opt/documents-templates/nginx.conf.template \
  > /etc/nginx/nginx.conf

envsubst '${AUTH0_DOMAIN} ${AUTH0_WEB_CLIENT_ID} ${API_AUDIENCE} ${CONTENT_DOMAIN}' \
  < /opt/documents-templates/config.js.template \
  > /usr/share/nginx/html/config.js

envsubst '${APP_DOMAIN}' \
  < /opt/documents-templates/content-config.js.template \
  > /usr/share/nginx/content/config.js
