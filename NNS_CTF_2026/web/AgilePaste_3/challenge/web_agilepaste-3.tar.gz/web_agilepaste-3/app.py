import base64
import html
import secrets
from pathlib import Path

import erlang
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

DIST = Path(__file__).parent / "dist"
INDEX = (DIST / "index.html").read_text()

CSP = "; ".join(
    [
        "default-src 'none'",
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
        "style-src 'self'",
        "connect-src 'self'",
        "frame-src 'self'",
        "base-uri 'none'",
        "object-src 'none'",
        "frame-ancestors 'none'",
        "form-action 'none'",
    ]
)

MAX_PASTES = 5000
MAX_PASTE_BYTES = 64 * 1024
MAX_CARD_FIELDS = 32
MAX_CARD_BYTES = 8 * 1024

pastes: dict[str, bytes] = {}
cards: dict[str, dict[str, str]] = {}


class Rejected(Exception):
    pass


def card(blob: bytes) -> dict[str, str]:
    try:
        raw = base64.b64decode(blob, validate=True)
    except Exception:
        raise Rejected("paste is not a valid term")

    if not raw.startswith(b"\x83") or raw[1:2] == b"\x50":
        raise Rejected("paste is not a valid term")

    try:
        note = erlang.binary_to_term(raw)
    except Exception:
        raise Rejected("paste is not a valid term")

    if not isinstance(note, dict) or len(note) > MAX_CARD_FIELDS:
        raise Rejected("paste is not a note")

    fields: dict[str, str] = {}
    size = 0

    for key, value in note.items():
        if not isinstance(key, erlang.OtpErlangBinary):
            raise Rejected("note fields must be text")
        if not isinstance(value, erlang.OtpErlangBinary):
            raise Rejected("note fields must be text")

        size += len(key.value) + len(value.value)
        if size > MAX_CARD_BYTES:
            raise Rejected("note is too long to preview")

        try:
            fields[key.value.decode()] = value.value.decode()
        except UnicodeDecodeError:
            raise Rejected("note fields must be text")

    if "title" not in fields or "body" not in fields:
        raise Rejected("note must have a title and a body")

    return {"title": fields["title"][:120], "excerpt": fields["body"][:200]}


app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["content-security-policy"] = CSP
    resp.headers["cross-origin-opener-policy"] = "same-origin"
    resp.headers["cross-origin-embedder-policy"] = "require-corp"
    resp.headers["cross-origin-resource-policy"] = "same-origin"
    resp.headers["x-content-type-options"] = "nosniff"
    resp.headers["referrer-policy"] = "no-referrer"
    return resp


@app.get("/", response_class=HTMLResponse)
def index():
    return INDEX


@app.get("/p/{paste_id}", response_class=HTMLResponse)
def view(paste_id: str):
    preview = cards.get(paste_id)
    if preview is None:
        return INDEX

    meta = (
        f'<meta property="og:title" content="{html.escape(preview["title"], quote=True)}" />'
        f'<meta property="og:description" content="{html.escape(preview["excerpt"], quote=True)}" />'
    )
    return INDEX.replace("</head>", meta + "</head>")


@app.post("/api/paste")
async def create_paste(request: Request):
    blob = (await request.body()).strip()
    if len(blob) > MAX_PASTE_BYTES:
        return JSONResponse({"error": "too large"}, status_code=413)

    try:
        preview = card(blob)
    except Rejected as rejected:
        return JSONResponse({"error": str(rejected)}, status_code=400)

    if len(pastes) >= MAX_PASTES:
        pastes.clear()
        cards.clear()

    paste_id = secrets.token_hex(9)
    pastes[paste_id] = blob
    cards[paste_id] = preview
    return JSONResponse({"id": paste_id}, status_code=201)


@app.get("/api/paste/{paste_id}")
def read_card(paste_id: str):
    preview = cards.get(paste_id)
    if preview is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse(preview)


@app.get("/raw/{paste_id}/{filename}")
def read_paste(paste_id: str, filename: str):
    blob = pastes.get(paste_id)
    if blob is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    return Response(blob, media_type="application/octet-stream")


@app.get("/bundle.avm")
def bundle(request: Request):
    if "gzip" in request.headers.get("accept-encoding", ""):
        return FileResponse(
            DIST / "bundle.avm.gz",
            media_type="application/octet-stream",
            headers={"content-encoding": "gzip"},
        )
    return FileResponse(DIST / "bundle.avm", media_type="application/octet-stream")


app.mount("/", StaticFiles(directory=DIST), name="dist")
