use ark_ff::{BigInteger, PrimeField, Zero};
use base64::{engine::general_purpose::STANDARD, Engine};
use groupmap::GroupMap;
use kimchi::{circuits::polynomial::COLUMNS, proof::ProverProof, verifier::verify};
use mina_curves::pasta::{Fp, Vesta, VestaParameters};
use mina_poseidon::{
    constants::PlonkSpongeConstantsKimchi as SC,
    pasta::FULL_ROUNDS,
    sponge::{DefaultFqSponge, DefaultFrSponge},
};
use poly_commitment::{commitment::CommitmentCurve, ipa::OpeningProof};
use std::{
    io::{Read, Write},
    net::TcpStream,
    time::Duration,
};

mod challenge;

/// url
const BANK: &str = "localhost:1337";

/// amount to withdraw
const AMOUNT: u128 = 10;

type BaseSponge = DefaultFqSponge<VestaParameters, SC, FULL_ROUNDS>;
type ScalarSponge = DefaultFrSponge<Fp, SC, FULL_ROUNDS>;
type Opening = OpeningProof<Vesta, FULL_ROUNDS>;

fn settlement_row(amount: u128) -> [Fp; COLUMNS] {
    let mut row = [Fp::zero(); COLUMNS];

    row[0] = Fp::from(amount);
    row[1] = Fp::zero();
    row[2] = Fp::zero();

    for (i, shift) in [52, 40, 28, 16].iter().enumerate() {
        row[3 + i] = Fp::from(((amount >> shift) & 0xfff) as u64);
    }
    for i in 0..8 {
        row[7 + i] = Fp::from(((amount >> (14 - 2 * i)) & 0x3) as u64);
    }

    row
}

fn to_big(f: Fp) -> num_bigint::BigUint {
    num_bigint::BigUint::from_bytes_le(&f.into_bigint().to_bytes_le())
}

fn submit(line: &str) -> std::io::Result<String> {
    let mut sock = TcpStream::connect(BANK)?;
    sock.set_read_timeout(Some(Duration::from_secs(120)))?;
    write!(sock, "{line}\nquit\n")?;
    sock.flush()?;
    let mut reply = String::new();
    sock.read_to_string(&mut reply)?;
    Ok(reply)
}

fn main() {
    let row = settlement_row(AMOUNT);
    let amount = row[0];
    let public = vec![amount, Fp::zero()];
    let witness: [Vec<Fp>; COLUMNS] = core::array::from_fn(|c| {
        vec![if c == 0 { amount } else { Fp::zero() }, Fp::zero(), row[c]]
    });

    let index = challenge::prover_index();
    let group_map = <Vesta as CommitmentCurve>::Map::setup();

    println!("proving {} ...", to_big(amount));
    let hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(|_| {}));
    let attempt = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        ProverProof::create::<BaseSponge, ScalarSponge, _>(
            &group_map,
            witness,
            &[],
            &index,
            &mut rand::rngs::OsRng,
        )
    }));
    std::panic::set_hook(hook);

    let Ok(Ok(proof)) = attempt else {
        eprintln!("the settlement circuit rejected this witness");
        std::process::exit(1);
    };

    if verify::<FULL_ROUNDS, Vesta, BaseSponge, ScalarSponge, Opening>(
        &group_map,
        &index.verifier_index(),
        &proof,
        &public,
    )
    .is_err()
    {
        eprintln!("the proof did not verify locally");
        std::process::exit(1);
    }

    println!("submitting to {BANK} ...\n");
    let bytes = rmp_serde::to_vec(&proof).expect("serialize proof");
    let line = format!("settle {} {}", to_big(amount), STANDARD.encode(&bytes));

    match submit(&line) {
        Ok(reply) => reply
            .lines()
            .skip_while(|l| !l.contains("requested"))
            .map(|l| l.trim_start_matches("nns>").trim_end())
            .filter(|l| !l.contains("goodbye"))
            .for_each(|l| println!("{l}")),
        Err(e) => {
            eprintln!("could not reach {BANK}: {e}");
            std::process::exit(1);
        }
    }
}
