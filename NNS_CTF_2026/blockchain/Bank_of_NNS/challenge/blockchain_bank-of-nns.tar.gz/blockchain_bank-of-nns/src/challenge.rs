use ark_poly::EvaluationDomain;
use kimchi::circuits::{
    constraints::ConstraintSystem,
    gate::{CircuitGate, Connect},
    polynomials::generic::GenericGateSpec,
    wires::Wire,
};
use kimchi::prover_index::ProverIndex;
use mina_curves::pasta::{Fp, Vesta};
use mina_poseidon::pasta::FULL_ROUNDS;
use poly_commitment::{
    ipa::{endos, SRS},
    SRS as _,
};
use std::sync::Arc;

pub const PUBLIC_INPUTS: usize = 2;

pub fn gates() -> Vec<CircuitGate<Fp>> {
    let mut gates = vec![
        CircuitGate::<Fp>::create_generic_gadget(Wire::for_row(0), GenericGateSpec::Pub, None),
        CircuitGate::<Fp>::create_generic_gadget(Wire::for_row(1), GenericGateSpec::Pub, None),
    ];
    let mut row = 2;
    CircuitGate::<Fp>::extend_range_check(&mut gates, &mut row);
    gates.connect_64bit(1, 2);
    gates.connect_cell_pair((0, 0), (2, 0));
    gates
}

pub fn prover_index() -> ProverIndex<FULL_ROUNDS, Vesta, SRS<Vesta>> {
    let cs = ConstraintSystem::<Fp>::create(gates())
        .public(PUBLIC_INPUTS)
        .build()
        .expect("constraint system");
    let srs = {
        let srs = SRS::<Vesta>::create(cs.domain.d1.size());
        srs.get_lagrange_basis(cs.domain.d1);
        Arc::new(srs)
    };
    let (endo_q, _) = endos::<mina_curves::pasta::Pallas>();
    ProverIndex::create(cs, endo_q, srs, false)
}
