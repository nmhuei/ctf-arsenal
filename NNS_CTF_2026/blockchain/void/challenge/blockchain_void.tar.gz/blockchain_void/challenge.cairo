use core::circuit::{
    AddInputResultTrait, CircuitElement, CircuitInput, CircuitInputs, CircuitModulus,
    EvalCircuitTrait, circuit_inverse, u96,
};

#[executable]
fn main(input: u96, modulus_limb: u96) -> (u96, u96) {
    let value = CircuitElement::<CircuitInput<0>> {};
    let inverse = circuit_inverse(value);
    let modulus = TryInto::<_, CircuitModulus>::try_into([modulus_limb, 0, 0, 0]).unwrap();

    match (inverse,).new_inputs().next([input, 0, 0, 0]).done().eval(modulus) {
        Ok(_) => { panic!("input is invertible") },
        Err(_) => {},
    }

    (input, modulus_limb)
}
