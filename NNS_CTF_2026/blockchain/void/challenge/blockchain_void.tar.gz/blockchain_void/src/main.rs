use std::env;
use std::io::Write;
use std::path::Path;
use std::process::Stdio;
use std::sync::Arc;

use base64::engine::general_purpose::STANDARD as BASE64;
use base64::Engine;
use blake2::{Blake2s256, Digest};
use num_bigint::{BigInt, Sign};
use num_integer::Integer;
use serde_json::Value;
use tempfile::NamedTempFile;
use tokio::io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};
use tokio::process::Command;

const MAX_NUMBER: usize = 128;
const MAX_PROOF_B64: usize = 16 * 1024 * 1024;
const MAX_PROOF: usize = 12 * 1024 * 1024;
const CAIRO_PRIME: &str =
    "3618502788666131213697322783095070105623107215331596699973092056135872020481";
const WELCOME: &[u8] = b"welcome to the void\n";
const VERIFIER: &str = "/usr/local/bin/verify";
const CHALLENGE_EXECUTABLE: &str = "/app/challenge/challenge.executable.json";

#[derive(Clone)]
struct AppState {
    flag: String,
    program_digest: [u8; 32],
}

impl AppState {
    fn from_env() -> Result<Self, String> {
        Ok(Self {
            flag: env::var("FLAG").map_err(|_| "FLAG is not set".to_string())?,
            program_digest: executable_program_digest(Path::new(CHALLENGE_EXECUTABLE))?,
        })
    }
}

struct Request {
    input: u128,
    modulus: u128,
    proof_b64: String,
}

enum Response {
    Success(String),
    Failure,
}

impl Response {
    fn success(flag: String) -> Self {
        Self::Success(flag)
    }

    fn failure(_error: &'static str) -> Self {
        Self::Failure
    }

    fn into_wire_message(self) -> String {
        match self {
            Self::Success(flag) => flag,
            Self::Failure => "wrong".to_string(),
        }
    }
}

fn parse_cairo_felt(value: &str) -> Result<[u8; 32], String> {
    let (negative, digits) = value
        .strip_prefix("-0x")
        .map(|digits| (true, digits))
        .or_else(|| value.strip_prefix("0x").map(|digits| (false, digits)))
        .ok_or_else(|| "invalid executable felt".to_string())?;
    let magnitude = BigInt::parse_bytes(digits.as_bytes(), 16)
        .ok_or_else(|| "invalid executable felt".to_string())?;
    let signed = if negative { -magnitude } else { magnitude };
    let prime = BigInt::parse_bytes(CAIRO_PRIME.as_bytes(), 10).unwrap();
    let normalized = signed.mod_floor(&prime);
    let (sign, bytes) = normalized.to_bytes_le();
    if sign == Sign::Minus || bytes.len() > 32 {
        return Err("executable felt is outside the Cairo field".to_string());
    }
    let mut encoded = [0_u8; 32];
    encoded[..bytes.len()].copy_from_slice(&bytes);
    Ok(encoded)
}

fn executable_program_digest(path: &Path) -> Result<[u8; 32], String> {
    let executable: Value = serde_json::from_slice(
        &std::fs::read(path).map_err(|error| format!("cannot read executable: {error}"))?,
    )
    .map_err(|error| format!("invalid executable JSON: {error}"))?;
    let bytecode = executable
        .pointer("/program/bytecode")
        .and_then(Value::as_array)
        .ok_or_else(|| "executable has no bytecode".to_string())?;

    let mut hasher = Blake2s256::new();
    for value in bytecode {
        let value = value
            .as_str()
            .ok_or_else(|| "invalid executable bytecode".to_string())?;
        hasher.update(parse_cairo_felt(value)?);
    }
    Ok(hasher.finalize().into())
}

fn memory_words(entry: &Value, description: &str) -> Result<[u32; 8], String> {
    let entry = entry
        .as_array()
        .filter(|entry| entry.len() == 2)
        .ok_or_else(|| format!("invalid public {description} entry"))?;
    let words = entry[1]
        .as_array()
        .filter(|words| words.len() == 8)
        .ok_or_else(|| format!("invalid public {description} value"))?;

    words
        .iter()
        .map(|word| {
            word.as_u64()
                .and_then(|word| u32::try_from(word).ok())
                .ok_or_else(|| format!("invalid public {description} word"))
        })
        .collect::<Result<Vec<_>, _>>()?
        .try_into()
        .map_err(|_| format!("invalid public {description} value"))
}

fn proof_program_digest(program: &Value) -> Result<[u8; 32], String> {
    let entries = program
        .as_array()
        .ok_or_else(|| "invalid public program".to_string())?;
    let mut hasher = Blake2s256::new();

    for entry in entries {
        for word in memory_words(entry, "program")? {
            hasher.update(word.to_le_bytes());
        }
    }

    Ok(hasher.finalize().into())
}

fn decode_output(output: &Value) -> Result<Vec<u128>, String> {
    output
        .as_array()
        .ok_or_else(|| "invalid public output".to_string())?
        .iter()
        .map(|entry| {
            let mut value = 0_u128;

            for (index, word) in memory_words(entry, "output")?.into_iter().enumerate() {
                if index < 4 {
                    value |= u128::from(word) << (32 * index);
                } else if word != 0 {
                    return Err("public output does not fit u128".to_string());
                }
            }
            Ok(value)
        })
        .collect()
}

fn validate_false_claim(request: &Request) -> Result<(), &'static str> {
    if request.modulus < 2
        || request.input == 0
        || request.input >= request.modulus
        || request.input >= (1_u128 << 96)
        || request.modulus >= (1_u128 << 96)
    {
        return Err("require modulus >= 2 and 0 < input < modulus < 2^96");
    }
    if request.input.gcd(&request.modulus) != 1 {
        return Err("the claim is true: input is not invertible modulo modulus");
    }
    Ok(())
}

fn decode_proof(encoded: &str) -> Result<(Vec<u8>, Value), &'static str> {
    let bytes = BASE64
        .decode(encoded)
        .map_err(|_| "invalid base64 or proof JSON")?;
    if bytes.len() > MAX_PROOF {
        return Err("proof is too large");
    }

    let proof = serde_json::from_slice(&bytes).map_err(|_| "invalid base64 or proof JSON")?;
    Ok((bytes, proof))
}

fn validate_public_claim(
    proof: &Value,
    request: &Request,
    expected_program: &[u8; 32],
) -> Result<(), &'static str> {
    let memory = proof
        .pointer("/claim/public_data/public_memory")
        .ok_or("proof verification failed")?;
    let program_digest =
        proof_program_digest(&memory["program"]).map_err(|_| "proof verification failed")?;

    if &program_digest != expected_program {
        return Err("proof is for a different program");
    }

    let output = decode_output(&memory["output"]).map_err(|_| "proof verification failed")?;
    if output != [request.input, request.modulus] {
        return Err("wrong public claim output");
    }
    Ok(())
}

async fn run_verifier(proof_bytes: &[u8], verifier: &Path) -> Result<(), ()> {
    let mut proof_file = NamedTempFile::new().map_err(|_| ())?;
    proof_file.write_all(proof_bytes).map_err(|_| ())?;
    proof_file.flush().map_err(|_| ())?;

    let status = Command::new(verifier)
        .arg("--proof_path")
        .arg(proof_file.path())
        .arg("--channel_hash")
        .arg("blake2s")
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .await
        .map_err(|_| ())?;

    status.success().then_some(()).ok_or(())
}

async fn verify_request(request: Request, state: &AppState) -> Response {
    if let Err(error) = validate_false_claim(&request) {
        return Response::failure(error);
    }

    let (proof_bytes, proof) = match decode_proof(&request.proof_b64) {
        Ok(proof) => proof,
        Err(error) => return Response::failure(error),
    };
    if let Err(error) = validate_public_claim(&proof, &request, &state.program_digest) {
        return Response::failure(error);
    }
    if run_verifier(&proof_bytes, Path::new(VERIFIER))
        .await
        .is_err()
    {
        return Response::failure("proof verification failed");
    }

    Response::success(state.flag.clone())
}

async fn read_field(
    reader: &mut (impl tokio::io::AsyncBufRead + Unpin),
    writer: &mut (impl tokio::io::AsyncWrite + Unpin),
    prompt: &[u8],
    limit: usize,
) -> Result<String, Response> {
    writer
        .write_all(prompt)
        .await
        .map_err(|_| Response::failure("connection closed"))?;

    let mut line = Vec::new();
    match (&mut *reader)
        .take((limit + 1) as u64)
        .read_until(b'\n', &mut line)
        .await
    {
        Ok(_) if line.len() > limit => Err(Response::failure("input too large")),
        Ok(0) | Err(_) => Err(Response::failure("connection closed")),
        Ok(_) => String::from_utf8(line)
            .map(|line| line.trim().to_string())
            .map_err(|_| Response::failure("invalid input")),
    }
}

async fn handle_connection(stream: TcpStream, state: Arc<AppState>) {
    let (reader, mut writer) = stream.into_split();
    if writer.write_all(WELCOME).await.is_err() {
        return;
    }
    let mut reader = BufReader::new(reader);

    let response = async {
        let input = read_field(&mut reader, &mut writer, b"input > ", MAX_NUMBER)
            .await?
            .parse()
            .map_err(|_| Response::failure("invalid input"))?;
        let modulus = read_field(&mut reader, &mut writer, b"modulus > ", MAX_NUMBER)
            .await?
            .parse()
            .map_err(|_| Response::failure("invalid modulus"))?;

        let mut request = Request {
            input,
            modulus,
            proof_b64: String::new(),
        };
        validate_false_claim(&request).map_err(Response::failure)?;

        let proof_b64 =
            read_field(&mut reader, &mut writer, b"proof_b64 > ", MAX_PROOF_B64).await?;
        request.proof_b64 = proof_b64;

        Ok::<Request, Response>(request)
    }
    .await;

    let response = match response {
        Ok(request) => verify_request(request, &state).await,
        Err(error) => error,
    };

    let message = response.into_wire_message();
    let _ = writer.write_all(format!("{message}\n").as_bytes()).await;
}

#[tokio::main]
async fn main() {
    let state = Arc::new(AppState::from_env().expect("failed to load challenge configuration"));
    let listener = TcpListener::bind("0.0.0.0:31337")
        .await
        .expect("failed to bind");

    loop {
        let (stream, _) = listener
            .accept()
            .await
            .expect("failed to accept connection");
        let state = Arc::clone(&state);
        tokio::spawn(async move { handle_connection(stream, state).await });
    }
}
