// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

import {HyperCore} from "./HyperCore.sol";

contract L1Read {
    fallback(bytes calldata input) external returns (bytes memory) {
        HyperCore core = HyperCore(0x3333333333333333333333333333333333333333);
        return abi.encode(core.oraclePx(abi.decode(input, (uint32))));
    }
}
