// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

import {HyperCore} from "./HyperCore.sol";

contract Setup {
    HyperCore public constant CORE = HyperCore(0x3333333333333333333333333333333333333333);
    address public immutable player;

    constructor(address player_) {
        player = player_;
    }

    function isSolved() external view returns (bool) {
        return CORE.player() == player && CORE.vaultEquity() <= 100_000e6 && CORE.collateral() >= 4_900_000e6;
    }
}
