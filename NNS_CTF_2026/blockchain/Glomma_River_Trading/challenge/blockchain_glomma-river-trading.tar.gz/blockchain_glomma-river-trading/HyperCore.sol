// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

contract HyperCore {
    uint256 constant PRICE_SCALE = 1e6;
    uint256 constant CORE_SCALE = 1e8;
    uint256 constant MAX_LEVERAGE = 20;

    address public player;
    uint256 public collateral;
    uint256 public vaultEquity;
    uint256 public spotBaseReserve;
    uint256 public spotQuoteReserve;
    uint64 public perpSize;
    uint256 public perpEntryPx;

    function initialize(address player_) external {
        require(player == address(0), "initialized");
        player = player_;
        collateral = 10_000e6;
        vaultEquity = 5_000_000e6;
        spotBaseReserve = 1_000e6;
        spotQuoteReserve = 1_000e6;
    }

    function sendRawAction(bytes calldata data) external {
        require(msg.sender == player, "only player");
        require(data.length == 228 && bytes4(data[:4]) == hex"01000001", "bad action");
        (uint32 asset, bool isBuy,, uint64 size, bool reduceOnly, uint8 tif,) =
            abi.decode(data[4:], (uint32, bool, uint64, uint64, bool, uint8, uint128));
        require(tif == 3, "IOC only");

        if (asset == 1 && isBuy && !reduceOnly) {
            _openPerp(size);
        } else if (asset == 1 && !isBuy && reduceOnly) {
            _closePerp(size);
        } else if (asset == 10_001 && isBuy && !reduceOnly) {
            _buySpot(size);
        } else {
            revert("unsupported order");
        }
    }

    function oraclePx(uint32 asset) public view returns (uint64) {
        require(asset == 1, "unknown asset");
        return uint64(spotQuoteReserve * PRICE_SCALE / spotBaseReserve);
    }

    function _openPerp(uint64 size) private {
        require(size != 0 && perpSize == 0, "one long position");
        uint256 px = oraclePx(1);
        require(uint256(size) * px / CORE_SCALE <= collateral * MAX_LEVERAGE, "initial margin");
        perpSize = size;
        perpEntryPx = px;
    }

    function _buySpot(uint64 size) private {
        require(size != 0 && size % 100 == 0, "spot size");
        uint256 baseOut = size / 100;
        require(baseOut < spotBaseReserve, "spot liquidity");
        uint256 newBase = spotBaseReserve - baseOut;
        uint256 newQuote = (spotBaseReserve * spotQuoteReserve + newBase - 1) / newBase;
        uint256 quoteIn = newQuote - spotQuoteReserve;
        require(quoteIn <= collateral, "spot collateral");

        collateral -= quoteIn;
        spotBaseReserve = newBase;
        spotQuoteReserve = newQuote;
    }

    function _closePerp(uint64 size) private {
        require(size != 0 && size == perpSize, "position size");
        uint256 profit = uint256(size) * (oraclePx(1) - perpEntryPx) / CORE_SCALE;
        require(profit <= vaultEquity, "HLP insolvent");
        vaultEquity -= profit;
        collateral += profit;
        perpSize = 0;
    }
}
