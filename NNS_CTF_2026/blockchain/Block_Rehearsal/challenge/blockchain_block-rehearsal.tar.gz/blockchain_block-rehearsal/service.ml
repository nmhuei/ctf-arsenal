open Core_kernel

let port = 1337

let flag =
  Caml.Sys.getenv_opt "FLAG"
  |> Option.value_exn ~message:"FLAG environment variable is required"

let max_wire_hex = 128 * 1024
let send oc text = Caml.output_string oc text ; Caml.flush oc

let banner =
  {|block rehearsal
ever wondered how mina handles block proposals? no? well, there is a time for everything!

submit a staged_ledger_diff.stable.latest.t 
encode it with jane street bin_prot and send it as lowercase hex
> |}

let nibble = function
  | '0' .. '9' as c ->
      Char.to_int c - Char.to_int '0'
  | 'a' .. 'f' as c ->
      Char.to_int c - Char.to_int 'a' + 10
  | _ ->
      invalid_arg "payload must be lowercase hexadecimal"

let decode_hex text =
  let text = String.strip text in
  if String.is_empty text || String.length text mod 2 <> 0 then
    invalid_arg "payload must contain an even number of hex digits" ;
  Bytes.init (String.length text / 2) ~f:(fun index ->
      let high = nibble text.[index * 2] in
      let low = nibble text.[(index * 2) + 1] in
      Char.of_int_exn ((high lsl 4) lor low) )
  |> Bytes.to_string

let decode_diff text =
  let buffer = Bigstring.of_string (decode_hex text) in
  let pos_ref = ref 0 in
  let diff = Staged_ledger_diff.Stable.Latest.bin_read_t buffer ~pos_ref in
  if !pos_ref <> Bigstring.length buffer then invalid_arg "trailing bytes" ;
  diff

let constraint_constants =
  Genesis_constants.For_unit_tests.Constraint_constants.t

let logger = Logger.null ()

let proof_level = Genesis_constants.Proof_level.Check

let state_and_body_hash =
  ( Quickcheck.random_value ~seed:(`Deterministic "block-rehearsal-state")
      Mina_base.State_hash.gen
  , Quickcheck.random_value ~seed:(`Deterministic "block-rehearsal-body")
      Mina_base.State_body_hash.gen )

let create_verifier () =
  Async.Thread_safe.block_on_async_exn (fun () ->
      let dummy_key = Lazy.force Pickles.Verification_key.dummy in
      Verifier.create ~logger ~proof_level
        ~pids:(Child_processes.Termination.create_pid_table ()) ~conf_dir:None
        ~commit_id:"block-rehearsal" ~blockchain_verification_key:dummy_key
        ~transaction_verification_key:dummy_key
        ~signature_kind:Mina_signature_kind.Testnet () )

type validation_result =
  | Accepted
  | Rejected
  | Intended_panic
  | Validator_error of exn

let is_completed_work_pairing_panic = function
  | Invalid_argument message ->
      String.is_prefix message ~prefix:"length mismatch in zip_exn:"
  | _ ->
      false

let run_mina_validator ~verifier stable_diff =
  let has_extra_completed_work =
    not
      (List.is_empty
         (Staged_ledger_diff.Stable.Latest.completed_works stable_diff) )
  in
  try
    let diff =
      Staged_ledger_diff.write_all_proofs_to_disk
        ~signature_kind:Mina_signature_kind.Testnet
        ~proof_cache_db:(Proof_cache_tag.create_identity_db ()) stable_diff
    in
    Mina_ledger.Ledger.with_ephemeral_ledger
      ~depth:constraint_constants.ledger_depth ~f:(fun ledger ->
        let staged_ledger =
          Staged_ledger.create_exn ~constraint_constants ~ledger
        in
        let global_slot = Mina_numbers.Global_slot_since_genesis.zero in
        let current_state_view =
          Staged_ledger.Test_helpers.dummy_state_view ~global_slot ()
        in
        let result =
          Async.Thread_safe.block_on_async_exn (fun () ->
              Async.Monitor.try_with ~extract_exn:true
                ~rest:(`Call (fun _ -> ())) (fun () ->
                  Staged_ledger.apply ~constraint_constants ~global_slot
                    ~get_completed_work:(fun _ -> None) ~logger ~verifier
                    ~current_state_view ~state_and_body_hash
                    ~coinbase_receiver:
                      Signature_lib.Public_key.Compressed.empty
                    ~supercharge_coinbase:false ~zkapp_cmd_limit_hardcap:0
                    ~signature_kind:Mina_signature_kind.Testnet staged_ledger
                    diff ) )
        in
        match result with
        | Ok (Ok _) ->
            Accepted
        | Ok (Error _) ->
            Rejected
        | Error exn
          when has_extra_completed_work
               && is_completed_work_pairing_panic exn ->
            Intended_panic
        | Error exn ->
            Validator_error exn )
  with exn -> Validator_error exn

let read_payload ic =
  let buffer = Buffer.create 65_536 in
  let rec loop length =
    match Caml.input_char ic with
    | '\n' ->
        Buffer.contents buffer
    | byte when length < max_wire_hex ->
        Buffer.add_char buffer byte ;
        loop (length + 1)
    | _ ->
        invalid_arg "payload too large"
    | exception End_of_file ->
        Buffer.contents buffer
  in
  loop 0

let handle ~verifier fd =
  let ic = Caml_unix.in_channel_of_descr fd in
  let oc = Caml_unix.out_channel_of_descr fd in
  send oc banner ;
  try
    let diff = decode_diff (read_payload ic) in
    match run_mina_validator ~verifier diff with
    | Accepted ->
        send oc "\nproposal accepted\n"
    | Rejected ->
        send oc "\nproposal rejected\n"
    | Intended_panic ->
        send oc (sprintf "\nvalidator panicked\n%s\n" flag)
    | Validator_error exn ->
        eprintf "validator error: %s\n%!" (Exn.to_string exn) ;
        send oc "\nvalidator error\n"
  with _ -> send oc "\nmalformed proposal\n"

let serve () =
  Caml.Sys.set_signal Caml.Sys.sigpipe Caml.Sys.Signal_ignore ;
  let verifier = create_verifier () in
  Printf.printf "verifier ready\n%!" ;
  let socket = Caml_unix.socket Caml_unix.PF_INET Caml_unix.SOCK_STREAM 0 in
  Caml_unix.setsockopt socket Caml_unix.SO_REUSEADDR true ;
  Caml_unix.bind socket (Caml_unix.ADDR_INET (Caml_unix.inet_addr_any, port)) ;
  Caml_unix.listen socket 32 ;
  Printf.printf "listening on %d\n%!" port ;
  while true do
    let fd, _ = Caml_unix.accept socket in
    Exn.protect ~f:(fun () -> try handle ~verifier fd with _ -> ())
      ~finally:(fun () -> try Caml_unix.close fd with _ -> ())
  done

let command =
  Command.basic ~summary:"run the block rehearsal service"
    (Command.Param.return serve)

let () = Rpc_parallel_unauthenticated.start_app command
