import { createRequire } from "node:module";
import { defineConfig } from "vitest/config";

const require = createRequire(import.meta.url);

export default defineConfig({
  resolve: {
    alias: { "@noble/hashes/utils": require.resolve("@noble/hashes/utils") },
    conditions: ["import", "module", "browser", "default"],
  },
  test: {
    hookTimeout: 300_000,
    testTimeout: 300_000,
    fileParallelism: false,
    pool: "forks",
    maxWorkers: 1,
    execArgv: ["--experimental-vm-modules"],
    server: {
      deps: { inline: [/@aztec/, /@noble\/(hashes|curves|ciphers)/, /viem/, /@scure/] },
    },
  },
});
