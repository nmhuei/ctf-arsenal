import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { AztecAddress } from "@aztec/aztec.js/addresses";
import { Fr } from "@aztec/aztec.js/fields";
import { createAztecNodeClient, waitForNode } from "@aztec/aztec.js/node";
import { EmbeddedWallet } from "@aztec/wallets/embedded";
import { registerInitialLocalNetworkAccountsInWallet } from "@aztec/wallets/testing";

import { AtlasTriggerContract } from "../artifacts/AtlasTrigger.js";
import { DetectorInterfaceContract } from "../artifacts/DetectorInterface.js";
import { FlagEmitterContract } from "../artifacts/FlagEmitter.js";

function compressedString(value: string) {
  const bytes = Buffer.alloc(32);
  Buffer.from(value, "ascii").copy(bytes, 1);
  return { value: Fr.fromBuffer(bytes) };
}

describe("CERN", () => {
  let wallet: EmbeddedWallet;
  let player: AztecAddress;
  let atlas: AtlasTriggerContract;
  let detector: DetectorInterfaceContract;
  let emitter: FlagEmitterContract;

  beforeAll(async () => {
    const node = createAztecNodeClient("http://localhost:8080");
    await waitForNode(node);
    wallet = await EmbeddedWallet.create(node, {
      pxeConfig: { dataDirectory: "pxe-cern", proverEnabled: false },
    });

    const [deployer, solver] = await registerInitialLocalNetworkAccountsInWallet(wallet);
    player = solver;

    ({ contract: emitter } = await FlagEmitterContract.deploy(wallet, deployer).send({
      from: deployer,
    }));
    ({ contract: atlas } = await AtlasTriggerContract.deploy(wallet, emitter.address).send({
      from: deployer,
    }));
    ({ contract: detector } = await DetectorInterfaceContract.deploy(wallet).send({
      from: deployer,
    }));
    await emitter.methods
      .set_challenge(atlas.address, compressedString("atlas-trigger"))
      .send({ from: deployer });

    console.log("AtlasTrigger:", atlas.address.toString());
    console.log("DetectorInterface:", detector.address.toString());
  });

  afterAll(async () => {
    await wallet.stop();
  });

  it("captures the flag", async () => {
    // write under this

    const { result } = await emitter.methods
      .is_captured(atlas.address, player)
      .simulate({ from: player });
    expect(result).toBe(true);
  });
});
