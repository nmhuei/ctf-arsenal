// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

contract BoardingPass {
    string public constant name = "Boarding Pass";
    string public constant symbol = "PASS";
    address public immutable issuer;
    uint256 public totalSupply;
    mapping(uint256 => string) public flightOf;
    mapping(uint256 => address) private holders;

    event Transfer(address indexed from, address indexed to, uint256 indexed passId);

    constructor() {
        issuer = msg.sender;
    }

    function issue(address to, string calldata flight) external returns (uint256 passId) {
        require(msg.sender == issuer, "only the airline issues passes");
        require(to != address(0), "cannot issue to the zero address");

        passId = totalSupply++;
        holders[passId] = to;
        flightOf[passId] = flight;

        emit Transfer(address(0), to, passId);
    }

    function transferFrom(address from, address to, uint256 passId) external {
        require(holders[passId] == from, "not the holder");
        require(msg.sender == from, "only the holder may transfer");
        require(to != address(0), "cannot transfer to the zero address");

        holders[passId] = to;

        emit Transfer(from, to, passId);
    }

    function ownerOf(uint256 passId) external view returns (address) {
        address holder = holders[passId];
        require(holder != address(0), "no such pass");
        return holder;
    }
}
