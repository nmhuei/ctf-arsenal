// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

import "src/BoardingPass.sol";

contract CompensationFund {
    struct Fund {
        string flight;
        uint256 compensation;
        uint256 balance;
    }

    uint256 private constant EUR = 0.01 ether;
    uint256 public constant BAND_A = 250 * EUR;
    uint256 public constant BAND_B = 400 * EUR;
    uint256 public constant BAND_C = 600 * EUR;
    uint256 public constant DELAY_THRESHOLD_HOURS = 3;

    BoardingPass public immutable boardingPass;
    address public immutable operator;
    Fund[] private funds;
    mapping(uint256 => mapping(uint256 => bool)) private redeemed;

    event FundOpened(uint256 indexed fundId, string flight, uint256 compensation, uint256 balance);
    event Collected(uint256 indexed fundId, uint256 indexed passId, address indexed claimant, uint256 amount);

    constructor(BoardingPass passes) {
        boardingPass = passes;
        operator = msg.sender;
    }

    function openFund(string calldata flight, uint256 distanceKm, bool intraCommunity, uint256 delayHours)
        external
        payable
        returns (uint256 fundId)
    {
        require(msg.sender == operator, "only the airline opens funds");

        uint256 share = compensationFor(distanceKm, intraCommunity, delayHours);
        require(share > 0, "no compensation is due");
        require(msg.value >= share, "fund it with at least one share");

        fundId = funds.length;
        funds.push(Fund({flight: flight, compensation: share, balance: msg.value}));

        emit FundOpened(fundId, flight, share, msg.value);
    }

    function collect(uint256 fundId, uint256 passId) external {
        Fund storage fund = funds[fundId];

        require(boardingPass.ownerOf(passId) == msg.sender, "not your boarding pass");
        require(
            keccak256(bytes(boardingPass.flightOf(passId))) == keccak256(bytes(fund.flight)),
            "boarding pass is for another flight"
        );
        require(!redeemed[fundId][passId], "already collected");
        require(fund.balance >= fund.compensation, "fund is empty");

        (bool ok,) = msg.sender.call{value: fund.compensation}("");
        require(ok, "payout failed");

        redeemed[fundId][passId] = true;
        fund.balance -= fund.compensation;

        emit Collected(fundId, passId, msg.sender, fund.compensation);
    }

    function compensationFor(uint256 distanceKm, bool intraCommunity, uint256 delayHours)
        public
        pure
        returns (uint256 amount)
    {
        if (delayHours < DELAY_THRESHOLD_HOURS) {
            return 0;
        }

        uint256 thresholdHours;

        if (distanceKm <= 1500) {
            amount = BAND_A;
            thresholdHours = 2;
        } else if (intraCommunity || distanceKm <= 3500) {
            amount = BAND_B;
            thresholdHours = 3;
        } else {
            amount = BAND_C;
            thresholdHours = 4;
        }

        // Article 7(2) permits half payment within the band's threshold.
        if (delayHours <= thresholdHours) {
            amount /= 2;
        }
    }

    function fundOf(uint256 fundId)
        external
        view
        returns (string memory flight, uint256 compensation, uint256 balance)
    {
        Fund storage fund = funds[fundId];
        return (fund.flight, fund.compensation, fund.balance);
    }

    function compensationOf(uint256 fundId) external view returns (uint256) {
        return funds[fundId].compensation;
    }

    function hasCollected(uint256 fundId, uint256 passId) external view returns (bool) {
        return redeemed[fundId][passId];
    }

    function fundCount() external view returns (uint256) {
        return funds.length;
    }

    function reserve() external view returns (uint256) {
        return address(this).balance;
    }

    function isSolved() external view returns (bool) {
        return address(this).balance == 0;
    }
}
