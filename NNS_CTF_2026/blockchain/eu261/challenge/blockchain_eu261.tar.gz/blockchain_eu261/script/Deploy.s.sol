// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.36;

import "forge-ctf/CTFDeployer.sol";
import "forge-ctf/CTFChallenge.sol";

import "src/BoardingPass.sol";
import "src/eu261.sol";

contract Deploy is CTFDeployer {
    string constant FLIGHT = "SK4045";
    uint256 constant DISTANCE_KM = 341;
    bool constant INTRA_COMMUNITY = true;
    uint256 constant DELAY_HOURS = 3;
    uint256 constant REFUND_POOL = 40 ether;

    function deploy(address system, address player) internal override returns (CTFChallenge[] memory challenges) {
        vm.startBroadcast(system);

        BoardingPass passes = new BoardingPass();
        CompensationFund fund = new CompensationFund(passes);

        passes.issue(player, FLIGHT);

        fund.openFund{value: REFUND_POOL}(FLIGHT, DISTANCE_KM, INTRA_COMMUNITY, DELAY_HOURS);

        vm.stopBroadcast();

        challenges = new CTFChallenge[](1);
        challenges[0] = CTFChallenge("CompensationFund", address(fund));
    }
}
