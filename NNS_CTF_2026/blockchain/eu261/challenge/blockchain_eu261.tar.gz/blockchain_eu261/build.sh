#!/bin/sh

forge install --no-git --shallow foundry-rs/forge-std@v1.11.0

forge build
