// node --disallow-code-generation-from-strings --frozen-intrinsics chal.js
import { createInterface } from "node:readline/promises";
import { Browser } from "happy-dom";

const rl = createInterface(process.stdin, process.stdout)

const url = await rl.question("schlink?: ");

const browser = new Browser({settings: {enableJavaScriptEvaluation: true}, console: global.console});
const page = browser.newPage();
await page.goto(url);

rl.close()
