import ast

wl = "),dw.r_[silent]g=c:f("

data = input("> ")
print(data)
tree = ast.parse(data, mode="eval")

assert isinstance(tree.body, ast.List), "input must be a list"

elements = [ast.get_source_segment(data, e) for e in tree.body.elts]

assert all(len(e)<=13 for e in elements), "shh, dont speak so much"
assert all(all(e in wl for e in element) for element in elements)

eval(data, {"__builtins__":{}})   