#!/bin/sh
set -eu

HASH=$(od -An -N12 -tx1 /dev/urandom | tr -d ' \n')
printf '%s\n' "$FLAG" > "/flag-$HASH.txt"

exec socat TCP-LISTEN:3000,fork,reuseaddr EXEC:"python3 main.py"