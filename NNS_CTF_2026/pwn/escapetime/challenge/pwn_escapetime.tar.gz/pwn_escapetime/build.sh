#!/bin/sh
set -eu

cd "$(dirname "$0")"

builder_image=${BUILDER_IMAGE:-nns-escapetime-builder:latest}
artifact_dir=$(mktemp -d)

docker build \
    --file Dockerfile.builder \
    --target export \
    --tag "$builder_image" \
    .
docker run --rm \
    --mount "type=bind,source=$artifact_dir,target=/out" \
    "$builder_image" \
    sh -c 'cp /bundle/wasmtime /out/wasmtime && cp /bundle/WASMTIME_COMMIT /out/WASMTIME_COMMIT'

mkdir -p dist
install -m 0755 "$artifact_dir/wasmtime" dist/wasmtime
install -m 0644 "$artifact_dir/WASMTIME_COMMIT" dist/WASMTIME_COMMIT
