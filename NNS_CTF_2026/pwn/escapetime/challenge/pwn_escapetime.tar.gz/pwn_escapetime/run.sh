#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
    echo "usage: $0 module.wat" >&2
    exit 1
fi

payload=$1
if [ ! -s "$payload" ]; then
    echo "missing or empty payload file: $payload" >&2
    exit 1
fi

cd /challenge
exec ./wasmtime run \
    -S cli=n \
    -W stack-switching=y \
    "$payload"
