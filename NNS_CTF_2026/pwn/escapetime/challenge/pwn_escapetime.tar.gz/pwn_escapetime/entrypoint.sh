#!/bin/sh
set -eu

: "${FLAG:?FLAG must be set}"

python3 -c '
import json
import os
from pathlib import Path

source = Path("/src/readflag.c").read_text()
flag = json.dumps(os.environ["FLAG"])[1:-1]
Path("/tmp/readflag.c").write_text(
    source.replace("NNS{REPLACE_ME}", flag)
)
'
gcc /tmp/readflag.c -static -O2 -s -o /tmp/readflag
cat /tmp/readflag > /readflag
chmod 0111 /readflag
rm -f /tmp/readflag /tmp/readflag.c

unset FLAG
exec socat TCP-LISTEN:5000,reuseaddr,fork EXEC:/app/run,stderr
