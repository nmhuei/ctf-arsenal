ARG UBUNTU_REF=ubuntu:26.04@sha256:2260313b31c8c011cd2eebe728008efac1b3982be73eb71348ea2648d2c0e09b

FROM ${UBUNTU_REF} AS builder

ARG WASMTIME_REF=3c767c06dcec4f0290e8e68c7bd8a49a0d720ce4
ENV DEBIAN_FRONTEND=noninteractive \
    RUSTUP_HOME=/opt/rustup \
    CARGO_HOME=/opt/cargo \
    PATH=/opt/cargo/bin:${PATH}

RUN apt-get update && apt-get install -y --no-install-recommends \
        build-essential \
        ca-certificates \
        curl \
        git \
        pkg-config \
        python3 \
    && rm -rf /var/lib/apt/lists/*

RUN curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs -o /tmp/rustup-init \
    && chmod 0755 /tmp/rustup-init \
    && /tmp/rustup-init -y --no-modify-path --profile minimal --default-toolchain 1.96.1 \
    && rm /tmp/rustup-init

WORKDIR /src/wasmtime
RUN git init \
    && git remote add origin https://github.com/bytecodealliance/wasmtime.git \
    && git fetch --depth 1 origin "${WASMTIME_REF}" \
    && git checkout --detach FETCH_HEAD \
    && test "$(git rev-parse HEAD)" = "${WASMTIME_REF}"

COPY patches/wasmtime-pr14140-port.patch /tmp/wasmtime-pr14140-port.patch
COPY patches/wasmtime-review-fixes.patch /tmp/wasmtime-review-fixes.patch
RUN git apply --check /tmp/wasmtime-pr14140-port.patch \
    && git apply /tmp/wasmtime-pr14140-port.patch \
    && git apply --check /tmp/wasmtime-review-fixes.patch \
    && git apply /tmp/wasmtime-review-fixes.patch

RUN cargo build --release --locked --bin wasmtime \
        --no-default-features \
        --features run,wat,cranelift,gc,gc-copying,stack-switching,disable-logging \
    && install -D -m 0755 target/release/wasmtime /bundle/wasmtime \
    && strip --strip-unneeded /bundle/wasmtime \
    && printf '%s\n' "${WASMTIME_REF}" > /bundle/WASMTIME_COMMIT

FROM ${UBUNTU_REF} AS export
COPY --from=builder /bundle/ /bundle/
