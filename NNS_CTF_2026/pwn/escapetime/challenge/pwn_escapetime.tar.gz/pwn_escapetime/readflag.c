#include <stdio.h>
#include <string.h>

#ifndef FLAG
#define FLAG "NNS{REPLACE_ME}"
#endif

int main(int argc, char **argv)
{
    if (argc != 3 || strcmp(argv[1], "nns") != 0 || strcmp(argv[2], "escapetime") != 0) {
        fprintf(stderr, "usage: %s nns escapetime\n", argv[0]);
        return 1;
    }

    puts(FLAG);
    return 0;
}
