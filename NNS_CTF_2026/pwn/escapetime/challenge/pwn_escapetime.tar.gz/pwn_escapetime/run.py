#!/usr/bin/env python3
import base64
import binascii
import os
import signal
import subprocess
import sys
import tempfile


TIMEOUT = int(os.environ.get("TIMEOUT", "120"))
MAX_PAYLOAD = int(os.environ.get("MAX_PAYLOAD", str(2 * 1024 * 1024)))


def main() -> int:
    signal.alarm(TIMEOUT + 5)

    sys.stdout.write("Give me the b64 for your WAT or Wasm: ")
    sys.stdout.flush()
    encoded = sys.stdin.buffer.readline().strip()
    if not encoded:
        print("empty input")
        return 1

    try:
        payload = base64.b64decode(encoded, validate=True)
    except binascii.Error:
        print("invalid base64")
        return 1

    if not payload:
        print("empty payload")
        return 1
    if len(payload) > MAX_PAYLOAD:
        print("payload too large")
        return 1

    fd, path = tempfile.mkstemp(prefix="challenge-", suffix=".wat")
    try:
        with os.fdopen(fd, "wb") as payload_file:
            payload_file.write(payload)
        os.chmod(path, 0o644)

        try:
            return subprocess.run(
                ["/challenge/run.sh", path],
                timeout=TIMEOUT,
                check=False,
            ).returncode
        except subprocess.TimeoutExpired:
            print("timeout")
            return 124
    finally:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
