Title: Quadratic Residues
Category: Mathematics
Stage: Modular Math
Challenge ID: root0
Points: 25
