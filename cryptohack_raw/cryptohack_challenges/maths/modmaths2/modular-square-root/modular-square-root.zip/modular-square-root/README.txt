Title: Modular Square Root
Category: Mathematics
Stage: Modular Math
Challenge ID: tonelli-shanks
Points: 35
