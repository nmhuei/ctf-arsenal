Title: Chinese Remainder Theorem
Category: Mathematics
Stage: Modular Math
Challenge ID: crt1
Points: 40
