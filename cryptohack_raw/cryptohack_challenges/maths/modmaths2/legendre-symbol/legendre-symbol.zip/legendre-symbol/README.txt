Title: Legendre Symbol
Category: Mathematics
Stage: Modular Math
Challenge ID: root1
Points: 35
