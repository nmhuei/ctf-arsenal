Title: Cofactor Cofantasy
Category: Mathematics
Stage: Brainteasers Part 2
Challenge ID: cofactor
Points: 150
