Title: Real Eisenstein
Category: Mathematics
Stage: Brainteasers Part 2
Challenge ID: eisenstein
Points: 150
