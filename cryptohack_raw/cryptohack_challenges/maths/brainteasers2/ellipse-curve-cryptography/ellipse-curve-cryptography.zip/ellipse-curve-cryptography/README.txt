Title: Ellipse Curve Cryptography
Category: Mathematics
Stage: Brainteasers Part 2
Challenge ID: ellipse
Points: 125
