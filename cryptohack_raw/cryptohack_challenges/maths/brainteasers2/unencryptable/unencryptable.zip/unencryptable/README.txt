Title: Unencryptable
Category: Mathematics
Stage: Brainteasers Part 2
Challenge ID: unencryptable
Points: 125
