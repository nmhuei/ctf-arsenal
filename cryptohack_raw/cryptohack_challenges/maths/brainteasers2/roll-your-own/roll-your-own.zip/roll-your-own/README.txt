Title: Roll your Own
Category: Mathematics
Stage: Brainteasers Part 2
Challenge ID: roll_your_own
Points: 125
