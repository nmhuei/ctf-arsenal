Title: No Way Back Home
Category: Mathematics
Stage: Brainteasers Part 1
Challenge ID: no-way-back-home
Points: 100
