Title: Successive Powers
Category: Mathematics
Stage: Brainteasers Part 1
Challenge ID: powers
Points: 60
