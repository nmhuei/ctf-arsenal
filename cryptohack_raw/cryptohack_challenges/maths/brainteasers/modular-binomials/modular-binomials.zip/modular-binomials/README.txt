Title: Modular Binomials
Category: Mathematics
Stage: Brainteasers Part 1
Challenge ID: bionomials
Points: 80
