Title: Adrien's Signs
Category: Mathematics
Stage: Brainteasers Part 1
Challenge ID: adrien
Points: 80
