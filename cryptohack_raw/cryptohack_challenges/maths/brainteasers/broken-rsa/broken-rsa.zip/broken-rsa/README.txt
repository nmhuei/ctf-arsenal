Title: Broken RSA
Category: Mathematics
Stage: Brainteasers Part 1
Challenge ID: broken-rsa
Points: 100
