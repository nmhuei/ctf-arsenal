Title: LWE Intro
Category: Lattices
Stage: Learning With Errors 1
Challenge ID: lwe-intro
Points: 10
