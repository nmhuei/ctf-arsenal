Title: LWE Background
Category: Lattices
Stage: Learning With Errors 1
Challenge ID: lwe-background
Points: 5
