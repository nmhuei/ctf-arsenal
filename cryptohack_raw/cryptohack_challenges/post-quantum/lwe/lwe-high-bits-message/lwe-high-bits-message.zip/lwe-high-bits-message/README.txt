Title: LWE High Bits Message
Category: Lattices
Stage: Learning With Errors 1
Challenge ID: lwe-high-bits
Points: 15
