Title: LWE Low Bits Message
Category: Lattices
Stage: Learning With Errors 1
Challenge ID: lwe-low-bits
Points: 20
