Title: Backpack Cryptography
Category: Lattices
Stage: Lattices
Challenge ID: backpack
Points: 120
