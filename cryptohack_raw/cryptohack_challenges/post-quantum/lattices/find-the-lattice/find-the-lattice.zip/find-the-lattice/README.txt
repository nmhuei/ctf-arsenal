Title: Find the Lattice
Category: Lattices
Stage: Lattices
Challenge ID: find
Points: 100
