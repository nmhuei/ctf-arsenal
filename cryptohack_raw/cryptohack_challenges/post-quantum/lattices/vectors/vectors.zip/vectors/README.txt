Title: Vectors
Category: Lattices
Stage: Lattices
Challenge ID: vectors
Points: 10
