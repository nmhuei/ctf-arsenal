Title: What's a Lattice?
Category: Lattices
Stage: Lattices
Challenge ID: lattices
Points: 40
