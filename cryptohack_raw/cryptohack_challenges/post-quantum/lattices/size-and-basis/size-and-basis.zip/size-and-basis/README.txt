Title: Size and Basis
Category: Lattices
Stage: Lattices
Challenge ID: basis
Points: 15
