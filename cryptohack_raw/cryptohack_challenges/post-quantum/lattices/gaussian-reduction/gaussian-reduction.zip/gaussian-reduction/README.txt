Title: Gaussian Reduction
Category: Lattices
Stage: Lattices
Challenge ID: gauss
Points: 50
