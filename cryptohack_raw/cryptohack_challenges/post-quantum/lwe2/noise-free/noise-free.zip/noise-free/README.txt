Title: Noise Free
Category: Lattices
Stage: Learning With Errors 2
Challenge ID: lwe-lsb-regev
Points: 40
