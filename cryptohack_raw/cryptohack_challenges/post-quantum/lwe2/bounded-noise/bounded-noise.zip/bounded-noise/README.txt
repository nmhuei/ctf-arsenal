Title: Bounded Noise
Category: Lattices
Stage: Learning With Errors 2
Challenge ID: lwe-bounded_noise
Points: 50
