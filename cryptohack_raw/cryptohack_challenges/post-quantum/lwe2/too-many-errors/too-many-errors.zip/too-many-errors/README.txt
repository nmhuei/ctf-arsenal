Title: Too Many Errors
Category: Lattices
Stage: Learning With Errors 2
Challenge ID: toomany
Points: 100
