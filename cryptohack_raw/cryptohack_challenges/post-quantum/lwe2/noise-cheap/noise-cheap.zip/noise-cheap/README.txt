Title: Noise Cheap
Category: Lattices
Stage: Learning With Errors 2
Challenge ID: lwe-noise-cheap
Points: 90
