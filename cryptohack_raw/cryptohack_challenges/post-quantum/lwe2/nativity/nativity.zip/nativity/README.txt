Title: Nativity
Category: Lattices
Stage: Learning With Errors 2
Challenge ID: lwe-nativity
Points: 60
