Title: Missing Modulus
Category: Lattices
Stage: Learning With Errors 2
Challenge ID: lwe-missing-modulus
Points: 80
