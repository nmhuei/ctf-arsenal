Title: Let's Decrypt
Category: RSA
Stage: Signatures Part 1
Challenge ID: lets_decrypt
Points: 80
