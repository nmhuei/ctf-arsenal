Title: Signing Server
Category: RSA
Stage: Signatures Part 1
Challenge ID: signing_server
Points: 60
