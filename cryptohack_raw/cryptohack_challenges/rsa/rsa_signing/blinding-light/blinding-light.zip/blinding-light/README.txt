Title: Blinding Light
Category: RSA
Stage: Signatures Part 1
Challenge ID: rsa_blinding
Points: 120
