Title: Square Eyes
Category: RSA
Stage: Primes Part 1
Challenge ID: square
Points: 35
