Title: Inferius Prime
Category: RSA
Stage: Primes Part 1
Challenge ID: inferius
Points: 30
