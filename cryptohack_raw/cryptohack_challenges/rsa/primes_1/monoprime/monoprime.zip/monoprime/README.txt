Title: Monoprime
Category: RSA
Stage: Primes Part 1
Challenge ID: monoprime
Points: 30
