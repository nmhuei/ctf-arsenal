Title: Manyprime
Category: RSA
Stage: Primes Part 1
Challenge ID: manyprime
Points: 40
