Title: Factoring
Category: RSA
Stage: Primes Part 1
Challenge ID: rsa_factoring
Points: 15
