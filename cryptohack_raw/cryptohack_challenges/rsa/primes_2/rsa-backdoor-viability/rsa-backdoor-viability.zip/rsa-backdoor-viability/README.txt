Title: RSA Backdoor Viability
Category: RSA
Stage: Primes Part 2
Challenge ID: rsa_backdoor
Points: 175
