Title: Infinite Descent
Category: RSA
Stage: Primes Part 2
Challenge ID: infinite_descent
Points: 50
