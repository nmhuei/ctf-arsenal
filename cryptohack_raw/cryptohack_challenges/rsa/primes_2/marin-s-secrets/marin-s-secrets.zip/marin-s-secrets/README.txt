Title: Marin's Secrets
Category: RSA
Stage: Primes Part 2
Challenge ID: marin
Points: 50
