Title: Fast Primes
Category: RSA
Stage: Primes Part 2
Challenge ID: fast_primes
Points: 75
