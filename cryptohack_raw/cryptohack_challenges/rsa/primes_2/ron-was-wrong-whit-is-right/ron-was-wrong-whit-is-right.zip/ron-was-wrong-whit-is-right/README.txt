Title: Ron was Wrong, Whit is Right
Category: RSA
Stage: Primes Part 2
Challenge ID: ron_was_wrong
Points: 90
