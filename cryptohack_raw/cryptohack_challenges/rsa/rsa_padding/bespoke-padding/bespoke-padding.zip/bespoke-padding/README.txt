Title: Bespoke Padding
Category: RSA
Stage: Padding
Challenge ID: bespoke
Points: 100
