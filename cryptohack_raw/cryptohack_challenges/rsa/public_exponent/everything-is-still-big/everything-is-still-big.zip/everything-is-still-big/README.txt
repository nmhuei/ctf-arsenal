Title: Everything is Still Big
Category: RSA
Stage: Public exponent
Challenge ID: big2
Points: 100
