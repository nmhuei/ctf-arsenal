Title: Salty
Category: RSA
Stage: Public exponent
Challenge ID: salty
Points: 20
