Title: Crossed Wires
Category: RSA
Stage: Public exponent
Challenge ID: wires
Points: 100
