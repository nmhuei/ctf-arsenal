Title: Everything is Big
Category: RSA
Stage: Public exponent
Challenge ID: big
Points: 70
