Title: Modulus Inutilis
Category: RSA
Stage: Public exponent
Challenge ID: modulus_inutilis
Points: 50
