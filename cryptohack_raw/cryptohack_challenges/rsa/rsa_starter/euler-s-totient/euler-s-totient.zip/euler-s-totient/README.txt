Title: Euler's Totient
Category: RSA
Stage: Starter
Challenge ID: rsa_starter_3
Points: 20
