Title: Modular Exponentiation
Category: RSA
Stage: Starter
Challenge ID: rsa_starter_1
Points: 10
