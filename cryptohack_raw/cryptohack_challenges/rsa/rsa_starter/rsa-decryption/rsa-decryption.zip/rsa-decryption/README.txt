Title: RSA Decryption
Category: RSA
Stage: Starter
Challenge ID: rsa_starter_5
Points: 20
