Title: Nothing Up My Sleeve
Category: Misc
Stage: PRNGs
Challenge ID: roulette
Points: 150
