Title: RSA vs RNG
Category: Misc
Stage: PRNGs
Challenge ID: rsa-vs-rng
Points: 150
