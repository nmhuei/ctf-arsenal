Title: Trust Games
Category: Misc
Stage: PRNGs
Challenge ID: lcg2
Points: 150
