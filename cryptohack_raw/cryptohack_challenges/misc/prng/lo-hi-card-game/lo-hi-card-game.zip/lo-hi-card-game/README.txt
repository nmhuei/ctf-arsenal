Title: Lo-Hi Card Game
Category: Misc
Stage: PRNGs
Challenge ID: lcg1
Points: 120
