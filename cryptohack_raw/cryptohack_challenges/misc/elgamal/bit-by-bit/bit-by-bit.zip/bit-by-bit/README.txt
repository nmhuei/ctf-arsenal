Title: Bit by Bit
Category: Misc
Stage: ElGamal
Challenge ID: bit
Points: 100
