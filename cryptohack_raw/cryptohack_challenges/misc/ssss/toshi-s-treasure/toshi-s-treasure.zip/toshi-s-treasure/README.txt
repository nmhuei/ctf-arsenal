Title: Toshi's Treasure
Category: Misc
Stage: Secret Sharing Schemes
Challenge ID: toshitreasure
Points: 150
