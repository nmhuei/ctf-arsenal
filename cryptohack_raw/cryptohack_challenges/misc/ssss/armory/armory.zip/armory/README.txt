Title: Armory
Category: Misc
Stage: Secret Sharing Schemes
Challenge ID: armory
Points: 100
