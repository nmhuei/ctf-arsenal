Title: Bruce Schneier's Password: Part 2
Category: Misc
Stage: Password Complexity
Challenge ID: schneierfact842_2
Points: 250
