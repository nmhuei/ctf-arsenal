Title: Bruce Schneier's Password
Category: Misc
Stage: Password Complexity
Challenge ID: schneierfact842
Points: 100
