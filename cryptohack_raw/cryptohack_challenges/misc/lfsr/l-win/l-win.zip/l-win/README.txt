Title: L-Win
Category: Misc
Stage: LFSR
Challenge ID: lwin
Points: 120
