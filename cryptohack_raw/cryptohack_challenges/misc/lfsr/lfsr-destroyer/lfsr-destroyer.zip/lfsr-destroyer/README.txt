Title: LFSR Destroyer
Category: Misc
Stage: LFSR
Challenge ID: lfsr-destroyer
Points: 250
