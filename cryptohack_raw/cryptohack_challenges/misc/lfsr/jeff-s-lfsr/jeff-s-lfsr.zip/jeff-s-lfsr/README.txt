Title: Jeff's LFSR
Category: Misc
Stage: LFSR
Challenge ID: jeff
Points: 150
