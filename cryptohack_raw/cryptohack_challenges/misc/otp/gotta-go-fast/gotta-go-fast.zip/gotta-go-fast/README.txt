Title: Gotta Go Fast
Category: Misc
Stage: One Time Pad
Challenge ID: gofast
Points: 40
