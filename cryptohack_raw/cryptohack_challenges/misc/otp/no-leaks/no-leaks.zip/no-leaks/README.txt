Title: No Leaks
Category: Misc
Stage: One Time Pad
Challenge ID: noleaks
Points: 100
