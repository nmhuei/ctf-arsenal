Title: Paper Plane
Category: Symmetric Ciphers
Stage: Authenticated Encryption
Challenge ID: paper_plane
Points: 120
