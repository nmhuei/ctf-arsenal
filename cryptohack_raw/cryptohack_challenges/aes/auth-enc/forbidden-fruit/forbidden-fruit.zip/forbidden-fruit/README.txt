Title: Forbidden Fruit
Category: Symmetric Ciphers
Stage: Authenticated Encryption
Challenge ID: forbidden_fruit
Points: 150
