Title: Modes of Operation Starter
Category: Symmetric Ciphers
Stage: Symmetric Starter
Challenge ID: block_cipher_starter
Points: 15
