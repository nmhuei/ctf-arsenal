Title: Passwords as Keys
Category: Symmetric Ciphers
Stage: Symmetric Starter
Challenge ID: passwords_as_keys
Points: 50
