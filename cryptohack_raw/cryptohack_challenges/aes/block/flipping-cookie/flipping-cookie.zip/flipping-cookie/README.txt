Title: Flipping Cookie
Category: Symmetric Ciphers
Stage: Block Ciphers 1
Challenge ID: flipping_cookie
Points: 60
