Title: Lazy CBC
Category: Symmetric Ciphers
Stage: Block Ciphers 1
Challenge ID: lazy_cbc
Points: 60
