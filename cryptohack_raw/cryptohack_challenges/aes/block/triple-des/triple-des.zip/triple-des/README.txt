Title: Triple DES
Category: Symmetric Ciphers
Stage: Block Ciphers 1
Challenge ID: triple_des
Points: 60
