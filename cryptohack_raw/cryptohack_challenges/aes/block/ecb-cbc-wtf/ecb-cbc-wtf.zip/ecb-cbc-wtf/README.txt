Title: ECB CBC WTF
Category: Symmetric Ciphers
Stage: Block Ciphers 1
Challenge ID: ecbcbcwtf
Points: 55
