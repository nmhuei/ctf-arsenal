Title: ECB Oracle
Category: Symmetric Ciphers
Stage: Block Ciphers 1
Challenge ID: ecb_oracle
Points: 60
