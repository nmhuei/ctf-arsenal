Title: Dancing Queen
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: dancing-queen
Points: 120
