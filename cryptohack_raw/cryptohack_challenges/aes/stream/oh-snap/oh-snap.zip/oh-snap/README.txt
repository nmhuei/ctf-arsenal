Title: Oh SNAP
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: oh_snap
Points: 120
