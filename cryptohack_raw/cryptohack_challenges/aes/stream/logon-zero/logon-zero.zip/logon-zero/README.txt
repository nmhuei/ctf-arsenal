Title: Logon Zero
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: logon-zero
Points: 80
