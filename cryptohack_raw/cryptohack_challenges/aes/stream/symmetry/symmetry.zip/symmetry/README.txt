Title: Symmetry
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: symmetry
Points: 50
