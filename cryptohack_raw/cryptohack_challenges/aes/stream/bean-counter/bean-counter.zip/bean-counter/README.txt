Title: Bean Counter
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: bean_counter
Points: 60
