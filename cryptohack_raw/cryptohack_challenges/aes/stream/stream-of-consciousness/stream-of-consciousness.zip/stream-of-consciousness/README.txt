Title: Stream of Consciousness
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: stream_consciousness
Points: 80
