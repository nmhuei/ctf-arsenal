Title: CTRIME
Category: Symmetric Ciphers
Stage: Stream Ciphers
Challenge ID: ctrime
Points: 70
