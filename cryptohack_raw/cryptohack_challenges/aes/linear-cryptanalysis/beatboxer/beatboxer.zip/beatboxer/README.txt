Title: Beatboxer
Category: Symmetric Ciphers
Stage: Linear Cryptanalysis
Challenge ID: beatboxer
Points: 150
