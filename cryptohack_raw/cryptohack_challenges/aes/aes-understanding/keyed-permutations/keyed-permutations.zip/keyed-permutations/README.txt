Title: Keyed Permutations
Category: Symmetric Ciphers
Stage: How AES Works
Challenge ID: aes0
Points: 5
