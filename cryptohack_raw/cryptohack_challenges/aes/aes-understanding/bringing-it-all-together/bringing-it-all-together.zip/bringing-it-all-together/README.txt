Title: Bringing It All Together
Category: Symmetric Ciphers
Stage: How AES Works
Challenge ID: aes6
Points: 50
