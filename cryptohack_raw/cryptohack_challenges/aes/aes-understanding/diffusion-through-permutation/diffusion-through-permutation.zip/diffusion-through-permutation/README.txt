Title: Diffusion through Permutation
Category: Symmetric Ciphers
Stage: How AES Works
Challenge ID: aes5
Points: 30
