Title: Structure of AES
Category: Symmetric Ciphers
Stage: How AES Works
Challenge ID: aes2
Points: 15
