Title: Resisting Bruteforce
Category: Symmetric Ciphers
Stage: How AES Works
Challenge ID: aes1
Points: 10
