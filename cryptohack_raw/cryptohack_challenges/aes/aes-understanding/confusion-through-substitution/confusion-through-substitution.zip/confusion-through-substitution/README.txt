Title: Confusion through Substitution
Category: Symmetric Ciphers
Stage: How AES Works
Challenge ID: aes4
Points: 25
