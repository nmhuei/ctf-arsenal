Title: The Good, The Pad, The Ugly
Category: Symmetric Ciphers
Stage: Padding Attacks
Challenge ID: good_pad_ugly
Points: 100
