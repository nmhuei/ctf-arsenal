Title: Oracular Spectacular
Category: Symmetric Ciphers
Stage: Padding Attacks
Challenge ID: oracular_spectacular
Points: 150
