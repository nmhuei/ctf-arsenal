Title: Pad Thai
Category: Symmetric Ciphers
Stage: Padding Attacks
Challenge ID: pad_thai
Points: 80
