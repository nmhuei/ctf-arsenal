Title: Key Backup Service 1 (HKCERT CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: key_backup_service_1-hkcert_c
Points: None
