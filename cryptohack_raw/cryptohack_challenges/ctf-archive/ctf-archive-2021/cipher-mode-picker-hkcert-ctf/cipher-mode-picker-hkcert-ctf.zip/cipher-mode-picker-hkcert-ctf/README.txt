Title: Cipher Mode Picker (HKCERT CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: cipher_mode_picker-hkcert_ctf
Points: None
