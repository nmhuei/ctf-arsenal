Title: Chaos (Zh3r0 CTF V2)
Category: CTF Archive
Stage: 2021
Challenge ID: chaos-zh3r0_ctf_v22021
Points: None
