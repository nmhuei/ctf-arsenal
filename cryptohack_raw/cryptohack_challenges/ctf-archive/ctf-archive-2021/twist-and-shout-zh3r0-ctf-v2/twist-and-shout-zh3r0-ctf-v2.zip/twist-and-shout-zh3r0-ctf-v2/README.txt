Title: Twist and Shout (Zh3r0 CTF V2)
Category: CTF Archive
Stage: 2021
Challenge ID: twist_and_shout-zh3r0_ctf_v22
Points: None
