Title: Real Mersenne (Zh3r0 CTF V2)
Category: CTF Archive
Stage: 2021
Challenge ID: real_mersenne-zh3r0_ctf_v2202
Points: None
