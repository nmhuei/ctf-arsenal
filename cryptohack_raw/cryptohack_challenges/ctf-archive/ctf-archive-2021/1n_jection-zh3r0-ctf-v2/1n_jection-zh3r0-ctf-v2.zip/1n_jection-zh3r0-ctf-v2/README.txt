Title: 1n_jection (Zh3r0 CTF V2)
Category: CTF Archive
Stage: 2021
Challenge ID: 1n_jection-zh3r0_ctf_v22021
Points: None
