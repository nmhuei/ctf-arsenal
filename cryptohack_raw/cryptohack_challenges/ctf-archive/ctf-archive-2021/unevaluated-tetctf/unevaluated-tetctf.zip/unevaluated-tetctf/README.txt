Title: Unevaluated (TETCTF)
Category: CTF Archive
Stage: 2021
Challenge ID: unevaluated-tetctf2021
Points: None
