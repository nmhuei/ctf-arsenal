Title: SpongeBob SquarePants / Battle for Bikini Bottom - Rehydrated (HTB Cyber Apocalypse)
Category: CTF Archive
Stage: 2021
Challenge ID: spongebob_squarepants__battle
Points: None
