Title: Sign In Please, Again (HKCERT CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: sign_in_please_again-hkcert_c
Points: None
