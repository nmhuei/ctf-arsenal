Title: Tenet: The Plagarism (HKCERT CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: tenet_the_plagarism-hkcert_ct
Points: None
