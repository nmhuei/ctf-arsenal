Title: import numpy as MT (Zh3r0 CTF V2)
Category: CTF Archive
Stage: 2021
Challenge ID: import_numpy_as_mt-zh3r0_ctf
Points: None
