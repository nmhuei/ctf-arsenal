Title: Substitution Cipher III (DownUnderCTF)
Category: CTF Archive
Stage: 2021
Challenge ID: substitution_cipher_iii-downu
Points: None
