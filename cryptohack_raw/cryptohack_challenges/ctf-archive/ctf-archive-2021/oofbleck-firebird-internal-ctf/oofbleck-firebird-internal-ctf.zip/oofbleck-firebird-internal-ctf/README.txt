Title: Oofbleck (Firebird Internal CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: oofbleck-firebird_internal_ct
Points: None
