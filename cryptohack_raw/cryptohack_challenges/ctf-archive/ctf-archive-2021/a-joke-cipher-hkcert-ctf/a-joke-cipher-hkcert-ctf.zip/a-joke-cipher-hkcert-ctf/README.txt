Title: A Joke Cipher (HKCERT CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: a_joke_cipher-hkcert_ctf2021
Points: None
