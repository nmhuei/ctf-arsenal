Title: Key Backup Service 2 (HKCERT CTF)
Category: CTF Archive
Stage: 2021
Challenge ID: key_backup_service_2-hkcert_c
Points: None
