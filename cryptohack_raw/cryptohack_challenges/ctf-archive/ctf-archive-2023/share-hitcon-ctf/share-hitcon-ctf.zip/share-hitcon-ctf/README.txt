Title: Share (HITCON CTF)
Category: CTF Archive
Stage: 2023
Challenge ID: share-hitcon_ctf2023
Points: None
