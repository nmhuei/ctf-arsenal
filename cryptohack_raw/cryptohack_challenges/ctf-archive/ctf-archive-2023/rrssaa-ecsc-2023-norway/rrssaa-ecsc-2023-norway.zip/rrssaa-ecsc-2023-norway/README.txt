Title: RRSSAA (ECSC 2023 (Norway))
Category: CTF Archive
Stage: 2023
Challenge ID: rrssaa-ecsc_2023_norway2023
Points: None
