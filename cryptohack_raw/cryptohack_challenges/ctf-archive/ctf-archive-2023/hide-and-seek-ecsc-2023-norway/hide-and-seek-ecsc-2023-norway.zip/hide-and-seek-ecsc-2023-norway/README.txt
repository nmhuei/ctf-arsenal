Title: Hide and seek (ECSC 2023 (Norway))
Category: CTF Archive
Stage: 2023
Challenge ID: hide_and_seek-ecsc_2023_norwa
Points: None
