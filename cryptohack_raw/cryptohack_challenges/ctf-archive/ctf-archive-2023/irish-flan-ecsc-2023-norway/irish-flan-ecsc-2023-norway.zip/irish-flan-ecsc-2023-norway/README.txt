Title: Irish flan (ECSC 2023 (Norway))
Category: CTF Archive
Stage: 2023
Challenge ID: irish_flan-ecsc_2023_norway20
Points: None
