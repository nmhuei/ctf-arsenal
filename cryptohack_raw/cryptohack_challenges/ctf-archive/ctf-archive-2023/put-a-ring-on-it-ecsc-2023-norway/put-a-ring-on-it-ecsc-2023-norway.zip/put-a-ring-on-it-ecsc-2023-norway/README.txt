Title: Put a ring on it (ECSC 2023 (Norway))
Category: CTF Archive
Stage: 2023
Challenge ID: put_a_ring_on_it-ecsc_2023_no
Points: None
