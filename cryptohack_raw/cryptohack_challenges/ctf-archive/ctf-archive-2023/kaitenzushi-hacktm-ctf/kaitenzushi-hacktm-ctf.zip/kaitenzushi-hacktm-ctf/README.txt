Title: kaitenzushi (HackTM CTF)
Category: CTF Archive
Stage: 2023
Challenge ID: kaitenzushi-hacktm_ctf2023
Points: None
