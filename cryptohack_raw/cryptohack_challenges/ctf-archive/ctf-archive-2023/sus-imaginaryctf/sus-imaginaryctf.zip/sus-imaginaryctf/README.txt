Title: Sus (ImaginaryCTF)
Category: CTF Archive
Stage: 2023
Challenge ID: sus-imaginaryctf2023
Points: None
