Title: Tough decisions (ECSC 2023 (Norway))
Category: CTF Archive
Stage: 2023
Challenge ID: tough_decisions-ecsc_2023_nor
Points: None
