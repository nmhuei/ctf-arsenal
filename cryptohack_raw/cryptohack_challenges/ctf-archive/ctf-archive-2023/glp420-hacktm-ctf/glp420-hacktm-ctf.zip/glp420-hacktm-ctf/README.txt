Title: GLP420 (HackTM CTF)
Category: CTF Archive
Stage: 2023
Challenge ID: glp420-hacktm_ctf2023
Points: None
