Title: What a Curve! (Breizh CTF)
Category: CTF Archive
Stage: 2023
Challenge ID: what_a_curve-breizh_ctf2023
Points: None
