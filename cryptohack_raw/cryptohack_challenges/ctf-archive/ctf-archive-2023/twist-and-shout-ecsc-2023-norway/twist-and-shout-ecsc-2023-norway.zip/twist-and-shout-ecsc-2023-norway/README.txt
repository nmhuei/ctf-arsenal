Title: Twist and shout (ECSC 2023 (Norway))
Category: CTF Archive
Stage: 2023
Challenge ID: twist_and_shout-ecsc_2023_nor
Points: None
