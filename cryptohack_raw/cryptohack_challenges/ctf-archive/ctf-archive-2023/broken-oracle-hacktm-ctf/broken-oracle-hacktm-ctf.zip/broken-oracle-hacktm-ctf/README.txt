Title: broken oracle (HackTM CTF)
Category: CTF Archive
Stage: 2023
Challenge ID: broken_oracle-hacktm_ctf2023
Points: None
