Title: Authentification 2 (Breizh CTF)
Category: CTF Archive
Stage: 2025
Challenge ID: authentification_2-breizh_ctf
Points: None
