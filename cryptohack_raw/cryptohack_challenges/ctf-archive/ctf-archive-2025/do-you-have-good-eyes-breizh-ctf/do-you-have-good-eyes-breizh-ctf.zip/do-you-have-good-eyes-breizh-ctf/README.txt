Title: Do you have good eyes? (Breizh CTF)
Category: CTF Archive
Stage: 2025
Challenge ID: do_you_have_good_eyes-breizh
Points: None
