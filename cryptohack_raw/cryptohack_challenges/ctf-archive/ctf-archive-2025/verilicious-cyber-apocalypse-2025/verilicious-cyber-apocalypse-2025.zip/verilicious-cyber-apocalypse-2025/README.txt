Title: Verilicious (Cyber Apocalypse 2025)
Category: CTF Archive
Stage: 2025
Challenge ID: verilicious-cyber_apocalypse
Points: None
