Title: Authentification 1 (Breizh CTF)
Category: CTF Archive
Stage: 2025
Challenge ID: authentification_1-breizh_ctf
Points: None
