Title: U-turn (Breizh CTF)
Category: CTF Archive
Stage: 2025
Challenge ID: u-turn-breizh_ctf2025
Points: None
