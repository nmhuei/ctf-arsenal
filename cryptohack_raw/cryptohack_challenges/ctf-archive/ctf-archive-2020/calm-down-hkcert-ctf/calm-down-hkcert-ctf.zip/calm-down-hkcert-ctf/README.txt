Title: Calm Down (HKCERT CTF)
Category: CTF Archive
Stage: 2020
Challenge ID: calm_down-hkcert_ctf2020
Points: None
