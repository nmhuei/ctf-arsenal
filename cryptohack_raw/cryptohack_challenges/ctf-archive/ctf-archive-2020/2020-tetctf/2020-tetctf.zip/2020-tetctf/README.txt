Title: 2020 (TETCTF)
Category: CTF Archive
Stage: 2020
Challenge ID: 2020-tetctf2020
Points: None
