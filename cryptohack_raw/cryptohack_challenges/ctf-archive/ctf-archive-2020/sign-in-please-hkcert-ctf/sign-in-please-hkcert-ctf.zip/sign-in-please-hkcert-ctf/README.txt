Title: Sign in Please (HKCERT CTF)
Category: CTF Archive
Stage: 2020
Challenge ID: sign_in_please-hkcert_ctf2020
Points: None
