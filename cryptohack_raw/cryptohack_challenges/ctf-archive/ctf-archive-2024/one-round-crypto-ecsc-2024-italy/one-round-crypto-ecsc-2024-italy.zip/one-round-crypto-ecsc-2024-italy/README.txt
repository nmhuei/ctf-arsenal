Title: One Round Crypto (ECSC 2024 (Italy))
Category: CTF Archive
Stage: 2024
Challenge ID: one_round_crypto-ecsc_2024_it
Points: None
