Title: Fischlin's Transformation (CryptoHack)
Category: CTF Archive
Stage: 2024
Challenge ID: fischlins_transformation-cryp
Points: None
