Title: Smithing contest (ECSC 2024 (Italy))
Category: CTF Archive
Stage: 2024
Challenge ID: smithing_contest-ecsc_2024_it
Points: None
