Title: Quo vadis? (ECSC 2024 (Italy))
Category: CTF Archive
Stage: 2024
Challenge ID: quo_vadis-ecsc_2024_italy2024
Points: None
