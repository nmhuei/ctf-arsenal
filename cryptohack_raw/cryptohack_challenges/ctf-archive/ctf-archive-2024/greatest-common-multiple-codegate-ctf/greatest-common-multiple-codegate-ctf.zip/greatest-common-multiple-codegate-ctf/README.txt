Title: Greatest Common Multiple (CODEGATE CTF)
Category: CTF Archive
Stage: 2024
Challenge ID: greatest_common_multiple-code
Points: None
