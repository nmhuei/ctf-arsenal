Title: Authenticator (Firebird Internal CTF)
Category: CTF Archive
Stage: 2022
Challenge ID: authenticator-firebird_intern
Points: None
