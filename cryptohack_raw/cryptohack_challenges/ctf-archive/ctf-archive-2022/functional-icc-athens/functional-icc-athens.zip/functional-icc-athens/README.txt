Title: Functional (ICC Athens)
Category: CTF Archive
Stage: 2022
Challenge ID: functional-icc_athens2022
Points: None
