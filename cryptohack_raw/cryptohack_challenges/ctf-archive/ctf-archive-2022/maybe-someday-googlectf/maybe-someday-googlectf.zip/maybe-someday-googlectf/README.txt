Title: Maybe Someday (GoogleCTF)
Category: CTF Archive
Stage: 2022
Challenge ID: maybe_someday-googlectf2022
Points: None
