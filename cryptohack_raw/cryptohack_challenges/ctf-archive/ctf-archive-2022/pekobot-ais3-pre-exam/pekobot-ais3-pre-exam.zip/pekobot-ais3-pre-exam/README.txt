Title: pekobot (AIS3 Pre-Exam)
Category: CTF Archive
Stage: 2022
Challenge ID: pekobot-ais3_pre-exam2022
Points: None
