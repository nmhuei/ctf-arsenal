Title: diffecient (SekaiCTF)
Category: CTF Archive
Stage: 2022
Challenge ID: diffecient-sekaictf2022
Points: None
