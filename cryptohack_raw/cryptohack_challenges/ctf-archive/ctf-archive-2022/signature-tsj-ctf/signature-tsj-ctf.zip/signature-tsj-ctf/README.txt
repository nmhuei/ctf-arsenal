Title: Signature (TSJ CTF)
Category: CTF Archive
Stage: 2022
Challenge ID: signature-tsj_ctf2022
Points: None
