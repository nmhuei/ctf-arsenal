Title: ed25519 magic (ICC Athens)
Category: CTF Archive
Stage: 2022
Challenge ID: ed25519_magic-icc_athens2022
Points: None
