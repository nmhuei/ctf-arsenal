Title: FaILProof Revenge (SekaiCTF)
Category: CTF Archive
Stage: 2022
Challenge ID: failproof_revenge-sekaictf202
Points: None
