Title: Maybe Someday (Maybe Someday CTF)
Category: CTF Archive
Stage: 2022
Challenge ID: maybe_someday-maybe_someday_c
Points: None
