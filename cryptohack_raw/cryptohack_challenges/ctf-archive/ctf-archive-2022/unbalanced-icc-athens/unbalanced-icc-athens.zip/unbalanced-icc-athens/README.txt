Title: Unbalanced (ICC Athens)
Category: CTF Archive
Stage: 2022
Challenge ID: unbalanced-icc_athens2022
Points: None
