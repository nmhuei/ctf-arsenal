Title: Dark Arts (CODEGATE CTF)
Category: CTF Archive
Stage: 2022
Challenge ID: dark_arts-codegate_ctf2022
Points: None
