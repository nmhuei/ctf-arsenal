import os, sys, numpy as np, hashlib, time
sys.path.append('/mnt/data/key_recovery_work')
from kr_common import *
Sinvnp=np.array(Sinv,dtype=np.uint8); G=np.arange(256,dtype=np.uint8)
MAIN=[i for i in range(16) if i not in (3,15)]
def cand(vals):
    vals=np.array(vals,dtype=np.uint8)
    mat=Sinvnp[np.bitwise_xor(vals[:,None],G[None,:])]
    x=np.bitwise_xor.reduce(mat,axis=0)
    return set(np.nonzero(x==0)[0].tolist())
def upd(cands, states, mask):
    for pos in MAIN:
        if mask>>pos & 1:
            cands[pos] &= cand([s[pos] for s in states])
def peel_b2(cts,k3): return [per_inv(sub_inv(xor(c,k3))) for c in cts]
def peel_b1(cts,k3,k2): return [per_inv(sub_inv(xor(y,k2))) for y in peel_b2(cts,k3)]
def peel_per0(cts,k3,k2,k1): return [sub_inv(xor(y,k1)) for y in peel_b1(cts,k3,k2)]
def compute_masks(st,trials=100):
    masks=[(1<<16)-1]*3
    for _ in range(trials):
        keys=ks(os.urandom(16)); base=os.urandom(16)
        acc=[[0]*16 for _ in range(3)]
        for p in make_pts(base,st):
            states=internal_states(keys,p)
            for r in range(3):
                for pos,b in enumerate(states[r]): acc[r][pos]^=b
        for r in range(3):
            m=sum((1<<pos) for pos,x in enumerate(acc[r]) if x==0)
            masks[r]&=m
    return tuple(masks)
def recover_main(data,masks, keys=None, verbose=False):
    # recover k3,k2,k1 main bytes
    k3=bytearray(16); k2=bytearray(16); k1=bytearray(16)
    c=[set(range(256)) if i in MAIN else {0} for i in range(16)]
    for (_,cts),ms in zip(data,masks): upd(c,cts,ms[2])
    if verbose: print('k3 sizes', [len(c[i]) for i in range(16)])
    if keys and any(keys[3][i] not in c[i] for i in MAIN): return None,'k3 lost'
    if any(len(c[i])!=1 for i in MAIN): return None,('k3 nonunique',[len(c[i]) for i in range(16)])
    for i in MAIN: k3[i]=next(iter(c[i]))
    c=[set(range(256)) if i in MAIN else {0} for i in range(16)]
    for (_,cts),ms in zip(data,masks): upd(c,peel_b2(cts,bytes(k3)),ms[1])
    if verbose: print('k2 sizes', [len(c[i]) for i in range(16)])
    if keys and any(keys[2][i] not in c[i] for i in MAIN): return None,'k2 lost'
    if any(len(c[i])!=1 for i in MAIN): return None,('k2 nonunique',[len(c[i]) for i in range(16)])
    for i in MAIN: k2[i]=next(iter(c[i]))
    c=[set(range(256)) if i in MAIN else {0} for i in range(16)]
    for (_,cts),ms in zip(data,masks): upd(c,peel_b1(cts,bytes(k3),bytes(k2)),ms[0])
    if verbose: print('k1 sizes', [len(c[i]) for i in range(16)])
    if keys and any(keys[1][i] not in c[i] for i in MAIN): return None,'k1 lost'
    if any(len(c[i])!=1 for i in MAIN): return None,('k1 nonunique',[len(c[i]) for i in range(16)])
    for i in MAIN: k1[i]=next(iter(c[i]))
    # derive k0 main from first sample
    p0=data[0][0][0]; c0=data[0][1][0]
    # peel to per0 with known main bytes; component separation enough
    per0=peel_per0([c0],bytes(k3),bytes(k2),bytes(k1))[0]
    b0=per_inv(per0) # sub(pt)^k0
    k0=bytearray(16)
    sp=sub(p0)
    for i in MAIN: k0[i]=b0[i]^sp[i]
    return (bytes(k0),bytes(k1),bytes(k2),bytes(k3)), 'ok'
def brute_missing(k0,k1,k2,k3):
    known=[k1,k2,k3]
    kb=bytearray(k0)
    for a in range(256):
      kb[3]=a
      for b in range(256):
        kb[15]=b
        h=hashlib.sha512(bytes(kb)).digest()
        ok=True
        for r,kk in enumerate(known):
          chunk=h[16*r:16*(r+1)]
          for i in MAIN:
            if chunk[i]!=kk[i]: ok=False; break
          if not ok: break
        if ok: return bytes(kb)
    return None
if __name__=='__main__':
    selected=[('nibs',(16,24)),('nibs',(8,21)),('nibs',(10,12)),('nibs',(16,26)),('nibs',(4,8)),('nibs',(8,24)),('nibs',(5,12)),('byte',10)]
    masks=[]
    for st in selected:
        ms=compute_masks(st, trials=100); masks.append(ms); print(st, [hex(x) for x in ms])
    for t in range(50):
        key=os.urandom(16); keys=ks(key); base=os.urandom(16)
        data=[]
        for st in selected:
            pts=make_pts(base,st); cts=[enc_keys(keys,p) for p in pts]; data.append((pts,cts))
        rec,msg=recover_main(data,masks,keys,verbose=(t==0))
        if msg!='ok': print('fail rec',t,msg); break
        k0,k1,k2,k3=rec
        full=brute_missing(k0,k1,k2,k3)
        if full!=key:
            print('brute fail',t, full, key.hex()); break
    else: print('50 ok')
