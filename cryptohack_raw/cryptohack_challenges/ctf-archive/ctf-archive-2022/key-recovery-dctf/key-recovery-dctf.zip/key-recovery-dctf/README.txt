Title: Key recovery (DCTF)
Category: CTF Archive
Stage: 2022
Challenge ID: key_recovery-dctf2022
Points: None
