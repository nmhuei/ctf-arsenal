Title: C0ll1d3r (Firebird Internal CTF)
Category: CTF Archive
Stage: 2022
Challenge ID: c0ll1d3r-firebird_internal_ct
Points: None
