Title: RSA Permutation (WACON)
Category: CTF Archive
Stage: 2022
Challenge ID: rsa_permutation-wacon2022
Points: None
