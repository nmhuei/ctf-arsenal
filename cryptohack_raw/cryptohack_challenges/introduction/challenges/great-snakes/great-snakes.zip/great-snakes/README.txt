Title: Great Snakes
Category: Introduction
Stage: Challenges
Challenge ID: nc-intro
Points: 3
