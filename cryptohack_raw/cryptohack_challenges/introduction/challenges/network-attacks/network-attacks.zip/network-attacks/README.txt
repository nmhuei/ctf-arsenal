Title: Network Attacks
Category: Introduction
Stage: Challenges
Challenge ID: nc-intro-2
Points: 5
