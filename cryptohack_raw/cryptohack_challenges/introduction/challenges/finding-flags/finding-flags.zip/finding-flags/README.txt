Title: Finding Flags
Category: Introduction
Stage: Challenges
Challenge ID: fflags
Points: 2
