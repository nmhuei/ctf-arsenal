Title: Parameter Injection
Category: Diffie-Hellman
Stage: Man In The Middle
Challenge ID: parameter_injection
Points: 60
