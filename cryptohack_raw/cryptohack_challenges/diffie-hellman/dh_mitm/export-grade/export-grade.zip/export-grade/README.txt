Title: Export-grade
Category: Diffie-Hellman
Stage: Man In The Middle
Challenge ID: export_grade
Points: 100
