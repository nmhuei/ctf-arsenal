Title: Static Client
Category: Diffie-Hellman
Stage: Man In The Middle
Challenge ID: dh_static
Points: 100
