Title: The Matrix Revolutions
Category: Diffie-Hellman
Stage: Misc
Challenge ID: matrix_revolutions
Points: 125
