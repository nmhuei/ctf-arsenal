Title: Script Kiddie
Category: Diffie-Hellman
Stage: Misc
Challenge ID: scriptkiddie
Points: 70
