Title: The Matrix Reloaded
Category: Diffie-Hellman
Stage: Misc
Challenge ID: matrix_reloaded
Points: 100
