Title: The Matrix
Category: Diffie-Hellman
Stage: Misc
Challenge ID: matrix
Points: 75
