Title: Additive
Category: Diffie-Hellman
Stage: Group Theory
Challenge ID: dh_additive
Points: 70
