Title: Static Client 2
Category: Diffie-Hellman
Stage: Group Theory
Challenge ID: dh_static2
Points: 120
