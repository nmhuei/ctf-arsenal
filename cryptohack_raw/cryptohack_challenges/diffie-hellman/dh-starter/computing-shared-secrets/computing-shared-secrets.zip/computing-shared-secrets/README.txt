Title: Computing Shared Secrets
Category: Diffie-Hellman
Stage: Starter
Challenge ID: dh-starter-4
Points: 30
