Title: Deriving Symmetric Keys
Category: Diffie-Hellman
Stage: Starter
Challenge ID: dh-starter-5
Points: 40
