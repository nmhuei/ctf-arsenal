Title: Working with Fields
Category: Diffie-Hellman
Stage: Starter
Challenge ID: dh-starter-1
Points: 10
