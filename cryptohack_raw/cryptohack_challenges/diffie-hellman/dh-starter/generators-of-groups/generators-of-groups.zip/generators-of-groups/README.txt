Title: Generators of Groups
Category: Diffie-Hellman
Stage: Starter
Challenge ID: dh-starter-2
Points: 20
