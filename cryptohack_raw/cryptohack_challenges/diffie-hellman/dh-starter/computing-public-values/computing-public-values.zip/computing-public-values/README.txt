Title: Computing Public Values
Category: Diffie-Hellman
Stage: Starter
Challenge ID: dh-starter-3
Points: 25
