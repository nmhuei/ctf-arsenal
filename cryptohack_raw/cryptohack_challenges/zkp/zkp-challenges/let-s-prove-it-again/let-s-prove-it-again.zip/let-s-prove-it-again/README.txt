Title: Let's Prove It Again
Category: ZKPs
Stage: ZKP Challenges
Challenge ID: letsproveitagain
Points: 175
