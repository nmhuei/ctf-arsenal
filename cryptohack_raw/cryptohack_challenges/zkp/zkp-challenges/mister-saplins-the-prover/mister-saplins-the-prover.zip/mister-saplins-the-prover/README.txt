Title: Mister Saplins The Prover
Category: ZKPs
Stage: ZKP Challenges
Challenge ID: mistersaplinstheprover
Points: 125
