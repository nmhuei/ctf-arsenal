Title: Let's Prove It
Category: ZKPs
Stage: ZKP Challenges
Challenge ID: letsproveit
Points: 120
