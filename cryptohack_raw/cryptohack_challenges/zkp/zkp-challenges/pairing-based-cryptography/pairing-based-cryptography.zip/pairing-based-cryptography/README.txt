Title: Pairing-Based Cryptography
Category: ZKPs
Stage: ZKP Challenges
Challenge ID: pairingbased
Points: 50
