Title: Mister Saplin's Preview
Category: ZKPs
Stage: ZKP Challenges
Challenge ID: mistersaplinspreview
Points: 80
