Title: Too Honest
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-too-honest
Points: 50
