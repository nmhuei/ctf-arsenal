Title: Proofs of Knowledge
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-intro
Points: 20
