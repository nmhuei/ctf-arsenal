Title: ZKP Introduction
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: zkpintro
Points: 5
