Title: Special Soundness
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-special-soundness
Points: 25
