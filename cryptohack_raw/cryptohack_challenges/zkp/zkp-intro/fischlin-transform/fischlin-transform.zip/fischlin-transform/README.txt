Title: Fischlin Transform
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-fischlin
Points: 180
