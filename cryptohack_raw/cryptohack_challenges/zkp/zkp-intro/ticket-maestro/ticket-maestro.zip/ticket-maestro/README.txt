Title: Ticket Maestro
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: snark-maestro
Points: 200
