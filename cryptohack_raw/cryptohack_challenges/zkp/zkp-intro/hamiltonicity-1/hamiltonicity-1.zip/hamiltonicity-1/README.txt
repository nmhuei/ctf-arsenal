Title: Hamiltonicity 1
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-hamiltonicity
Points: 100
