Title: OR Proof
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-or-proof
Points: 75
