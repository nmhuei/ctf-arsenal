Title: Hamiltonicity 2
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-hamiltonicity2
Points: 175
