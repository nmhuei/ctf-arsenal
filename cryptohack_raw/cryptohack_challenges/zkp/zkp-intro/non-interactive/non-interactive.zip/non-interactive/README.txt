Title: Non-Interactive
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-nizk
Points: 35
