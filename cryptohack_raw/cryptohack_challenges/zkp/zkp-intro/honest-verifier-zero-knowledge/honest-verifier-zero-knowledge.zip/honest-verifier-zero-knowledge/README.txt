Title: Honest Verifier Zero Knowledge
Category: ZKPs
Stage: Sigma Protocol
Challenge ID: sigma-shvzk
Points: 30
