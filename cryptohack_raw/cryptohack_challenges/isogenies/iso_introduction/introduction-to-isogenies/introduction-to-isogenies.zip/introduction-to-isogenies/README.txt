Title: Introduction to Isogenies
Category: Isogenies
Stage: Introduction
Challenge ID: iso_introduction_chall
Points: 10
