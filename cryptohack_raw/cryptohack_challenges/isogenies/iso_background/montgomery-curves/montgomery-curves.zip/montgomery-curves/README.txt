Title: Montgomery Curves
Category: Isogenies
Stage: Starter
Challenge ID: b_compute_montgomery
Points: 30
