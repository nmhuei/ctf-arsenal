Title: The j-invariant
Category: Isogenies
Stage: Starter
Challenge ID: j_invariant
Points: 20
