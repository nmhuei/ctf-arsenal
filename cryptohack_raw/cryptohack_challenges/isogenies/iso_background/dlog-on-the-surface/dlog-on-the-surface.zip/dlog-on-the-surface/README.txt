Title: DLOG on the Surface
Category: Isogenies
Stage: Starter
Challenge ID: 2d_dlog
Points: 40
