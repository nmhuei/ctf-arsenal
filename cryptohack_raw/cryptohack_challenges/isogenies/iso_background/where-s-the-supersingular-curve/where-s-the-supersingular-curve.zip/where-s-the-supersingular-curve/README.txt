Title: Where's the Supersingular Curve
Category: Isogenies
Stage: Starter
Challenge ID: a_spot_super
Points: 25
