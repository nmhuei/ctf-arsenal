Title: Image Point Arithmetic
Category: Isogenies
Stage: Starter
Challenge ID: c_group_homomorphism
Points: 30
