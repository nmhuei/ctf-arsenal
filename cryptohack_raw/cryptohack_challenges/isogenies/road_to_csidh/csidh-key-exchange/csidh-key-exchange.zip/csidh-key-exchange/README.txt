Title: CSIDH Key Exchange
Category: Isogenies
Stage: Road to CSIDH
Challenge ID: csidh_key_exchange
Points: 90
