Title: Special Isogenies
Category: Isogenies
Stage: Road to CSIDH
Challenge ID: special_isogenies
Points: 30
