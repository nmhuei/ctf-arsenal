Title: Secret Exponents
Category: Isogenies
Stage: Road to CSIDH
Challenge ID: csidh_secret_exponents
Points: 60
