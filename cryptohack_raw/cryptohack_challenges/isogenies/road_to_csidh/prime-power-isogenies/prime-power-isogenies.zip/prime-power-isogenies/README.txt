Title: Prime Power Isogenies
Category: Isogenies
Stage: Road to CSIDH
Challenge ID: prime_power
Points: 50
