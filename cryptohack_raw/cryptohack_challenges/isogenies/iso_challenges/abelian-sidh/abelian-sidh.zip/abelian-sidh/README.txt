Title: Abelian SIDH
Category: Isogenies
Stage: Isogeny Challenges
Challenge ID: abelian_sidh
Points: 90
