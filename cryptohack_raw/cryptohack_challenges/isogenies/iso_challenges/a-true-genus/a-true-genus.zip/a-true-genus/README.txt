Title: A True Genus
Category: Isogenies
Stage: Isogeny Challenges
Challenge ID: true_genus
Points: 175
