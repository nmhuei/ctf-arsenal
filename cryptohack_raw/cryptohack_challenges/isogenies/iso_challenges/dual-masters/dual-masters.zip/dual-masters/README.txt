Title: Dual Masters
Category: Isogenies
Stage: Isogeny Challenges
Challenge ID: dual_masters
Points: 90
