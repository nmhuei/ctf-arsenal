Title: What's My Kernel
Category: Isogenies
Stage: Isogeny Challenges
Challenge ID: whats_my_kernel
Points: 70
