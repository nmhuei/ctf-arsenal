Title: Meet me in the Claw
Category: Isogenies
Stage: Isogeny Challenges
Challenge ID: meet_me_claw
Points: 120
