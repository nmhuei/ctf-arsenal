Title: Better than Linear
Category: Isogenies
Stage: Isogeny Challenges
Challenge ID: better_than_linear
Points: 85
