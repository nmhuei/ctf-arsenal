Title: Composite Isogenies
Category: Isogenies
Stage: Road to SIDH
Challenge ID: comp_isogenies
Points: 60
