Title: Breaking SIDH
Category: Isogenies
Stage: Road to SIDH
Challenge ID: breaking_sidh
Points: 250
