Title: SIDH Key Exchange
Category: Isogenies
Stage: Road to SIDH
Challenge ID: sidh_key_exchange
Points: 80
