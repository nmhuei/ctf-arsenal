Title: Two Isogenies
Category: Isogenies
Stage: Road to SIDH
Challenge ID: two_isogenies
Points: 30
