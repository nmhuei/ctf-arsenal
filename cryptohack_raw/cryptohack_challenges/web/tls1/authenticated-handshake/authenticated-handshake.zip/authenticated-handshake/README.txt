Title: Authenticated Handshake
Category: Crypto on the Web
Stage: TLS Part 1: The Protocol
Challenge ID: authenticated-handshake
Points: 40
