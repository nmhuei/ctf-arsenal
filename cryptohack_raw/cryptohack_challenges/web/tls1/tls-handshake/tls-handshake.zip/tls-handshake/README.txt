Title: TLS Handshake
Category: Crypto on the Web
Stage: TLS Part 1: The Protocol
Challenge ID: tls-handshake
Points: 15
