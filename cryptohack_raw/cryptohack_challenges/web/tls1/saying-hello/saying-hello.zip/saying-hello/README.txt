Title: Saying Hello
Category: Crypto on the Web
Stage: TLS Part 1: The Protocol
Challenge ID: saying-hello
Points: 20
