Title: Sharks on the Wire
Category: Crypto on the Web
Stage: TLS Part 1: The Protocol
Challenge ID: sharks-wire
Points: 10
