The best way to understand a network protocol is to watch real traffic. For this challenge you'll use the incredible
[Wireshark](https://www.wireshark.org/download.html)
tool to investigate a TLS connection.
  
  
Wireshark is an open-source networking tool which can be used to easily record and analyse network traffic. It's widely used for troubleshooting so it's useful to know the basics of how to use it. Installation should be straightforward on Linux and macOS, on Windows it can be a little trickier, please
[check the docs](https://www.wireshark.org/docs/wsug_html_chunked/ChBuildInstallWinInstall.html)
.
  
  
Once you have Wireshark installed, open the file "cryptohack.org.pcapng" linked below. This is a packet capture showing the first 50 packets when we visited
*https://cryptohack.org*
in the Firefox browser. A packet is a formatted unit of data transmitted over a network. In the upper pane you can see a list of these packets and Wireshark is smart enough to figure out the network protocols used in each one based on the data inside. When you click on a packet, you get a "dissection" of each field in the data and what it means in the middle pane. In the bottom pane is a view of the raw packet bytes.
  
  
In the next challenges we'll look at what is happening in these packets. For now let's just get the hang of the Wireshark interface.
  
  


By default Wireshark only shows IP addresses in the source and destination columns. Click
`View > Resolution > Resolve Network Addresses`
to see some helpful names we added to the source and destination IPs to make the communication clearer. While Wireshark can resolve some public IPs by itself (like
`178.62.74.206`
becomes "cryptohack.org" using the DNS request in the packet capture), Wireshark could not resolve the private IPs in the capture so we annotated those ourselves in the provided file by right-clicking the IPs then
`Edit Resolve Name`
.
  
  
The search bar at the top of Wireshark allows the packets to be filtered using powerful expressions. You can also right-click packets on certain columns and click
`Apply as Filter > Selected`
to apply the same criteria on the selected column to filter all packets in the capture. For instance, if you right-click and do this for a packet sent by the CryptoHack server in the "Source" column, the
`ip.src == 178.62.74.206`
filter will be applied. To remove the filter clear the search bar and hit enter.
  
  
How many packets were received by the CryptoHack.org server (i.e. CryptoHack.org was the destination) in this capture?
  
  
**Challenge files:**
  
-
[cryptohack.org.pcapng](/static/challenges/cryptohack_6b3a90f7c585d399088758fda92fb9f6.org.pcapng)
