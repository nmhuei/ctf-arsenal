Title: Secure Protocols
Category: Crypto on the Web
Stage: TLS Part 1: The Protocol
Challenge ID: secure-protocols
Points: 5
