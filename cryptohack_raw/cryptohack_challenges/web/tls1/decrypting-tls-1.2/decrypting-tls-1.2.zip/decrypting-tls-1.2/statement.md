Let's rewind for a moment and talk about TLS 1.2, and why it has been superseded by TLS 1.3.
  
  
Attached is a packet capture "tls2.cryptohack.org.pcapng" of a TLS 1.2 connection being made to
`tls2.cryptohack.org`
using the
`curl`
command-line tool. Unlike the TLS 1.3 connection we were looking at in the previous packet capture, more of the handshake is visible in plaintext.
  
  
**Plaintext Certificate**
  
  
In packet 12 sent from the server to our laptop, we can see the full TLS Certificate. In TLS 1.3, the certificate is encrypted. Network security devices that run on corporate networks often relied on passively monitoring certificates to work out which connections to block; they can no longer use this method for TLS 1.3 connections.
  
  


Network security devices now use other methods to snoop on TLS 1.3 connections, we'll cover that in a later challenge.
  
  
**Client Key Exchange**
  
  
In packet 14 sent from laptop to server, there is a Client Key Exchange. Either RSA, various types of DHKE (Diffie-Hellmann Key Exchange), or PSK (Pre-Shared Key) algorithms can be used for key exchange. If RSA is used, then the client generates a random value called the premaster secret, encrypts it using the public key from the certificate sent by the server, and sends this to the server. Both laptop and server now have the means to calculate the master secret and therefore the shared session key, by combining the premaster secret with random values. If Diffie-Hellman is used as the key exchange algorithm, the client and server send each other their Diffie-Hellmann public values, allowing the same premaster secret to be calculated by both sides.
  
  
TLS 1.3 completely removed the Client Key Exchange step. It is no longer needed thanks to the more limited set of supported algorithms. Only Ephemeral Diffie Hellman key exchanges are supported (plus the much less commonly used PSK). The client now guesses which cipher suite the server will accept, and sends the Diffie-Hellman parameters in the Client Hello. Ultimately this saves a full network roundtrip when establishing a connection, making TLS 1.3 noticeably faster when browsing the Internet.
  
  
**Decrypting non-ephemeral TLS 1.2**
  
  
A major weakness of pre-TLS 1.3 cipher suites is that many cipher suites used long-term RSA (or less commonly static DH) keys for key exchange. As we just noted, the client sends the premaster secret encrypted by the RSA public key in the server certificate. We'll discuss how this relates to forward secrecy further in the next challenge. For now, you'll use the fact to decrypt a TLS 1.2 stream.
  
  
In the attached PCAP file for this challenge, the connection was made using the
`TLS_RSA_WITH_AES_256_GCM_SHA384`
cipher suite (
`AES256-GCM-SHA384`
in OpenSSL format). This uses RSA for key exchange.
  
  
You've hacked the
`tls2.cryptohack.org`
server and obtained the certificate's RSA private key. Use it to decrypt the TLS connection and find the flag in the HTTP/2 stream.
  
  


In Wireshark's "TLS Decrypt" dialogue, you don't need to worry about the IP address, port or other fields except "Key File". Select the file and Wireshark will figure out the rest.
  
  
**Challenge files:**
  
-
[tls2.cryptohack.org.pcapng](/static/challenges/tls2_f84f9216f7bd77b7a1337889393296e1.cryptohack.org.pcapng)
  
-
[privkey.pem](/static/challenges/privkey_aa0c8200134016bdbbb9e521b6e5f3e4.pem)
  
  
**Resources:**
  
-
[Wireshark: TLS Decryption](https://wiki.wireshark.org/TLS#tls-decryption)
