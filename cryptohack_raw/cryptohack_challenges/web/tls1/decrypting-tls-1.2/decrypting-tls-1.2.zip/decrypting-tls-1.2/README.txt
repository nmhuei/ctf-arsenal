Title: Decrypting TLS 1.2
Category: Crypto on the Web
Stage: TLS Part 1: The Protocol
Challenge ID: decrypting-tls12
Points: 30
