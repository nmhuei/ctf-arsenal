Title: Megalomaniac 3
Category: Crypto on the Web
Stage: Cloud
Challenge ID: mega3
Points: 120
