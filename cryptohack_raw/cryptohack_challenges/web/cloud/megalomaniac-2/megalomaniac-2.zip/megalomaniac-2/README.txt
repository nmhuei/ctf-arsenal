Title: Megalomaniac 2
Category: Crypto on the Web
Stage: Cloud
Challenge ID: mega2
Points: 120
