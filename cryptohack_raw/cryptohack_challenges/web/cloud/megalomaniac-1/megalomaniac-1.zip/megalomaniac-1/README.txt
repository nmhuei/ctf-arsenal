Title: Megalomaniac 1
Category: Crypto on the Web
Stage: Cloud
Challenge ID: mega1
Points: 100
