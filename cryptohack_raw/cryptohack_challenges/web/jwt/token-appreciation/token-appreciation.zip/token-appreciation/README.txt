Title: Token Appreciation
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: token-appreciation
Points: 5
