Title: No Way JOSE
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: no-way-jose
Points: 20
