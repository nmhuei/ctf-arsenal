Title: RSA or HMAC? Part 2
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: rsa-or-hmac-2
Points: 100
