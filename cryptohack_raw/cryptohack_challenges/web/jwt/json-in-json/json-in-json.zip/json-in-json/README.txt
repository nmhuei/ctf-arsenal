Title: JSON in JSON
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: json-in-json
Points: 40
