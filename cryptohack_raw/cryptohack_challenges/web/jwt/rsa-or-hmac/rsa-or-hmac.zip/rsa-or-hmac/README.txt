Title: RSA or HMAC?
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: rsa-or-hmac
Points: 35
