Title: JWT Sessions
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: jwt-sessions
Points: 10
