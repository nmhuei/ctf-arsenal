Title: JWT Secrets
Category: Crypto on the Web
Stage: JSON Web Tokens
Challenge ID: jwt-secrets
Points: 25
