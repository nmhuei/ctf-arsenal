Title: Edwards Goes Degenerate
Category: Elliptic Curves
Stage: Edwards Curves
Challenge ID: degenerate
Points: 100
