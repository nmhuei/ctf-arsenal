Title: An Evil Twisted Mind
Category: Elliptic Curves
Stage: Parameter Choice 2
Challenge ID: evil_twisted_mind
Points: 175
