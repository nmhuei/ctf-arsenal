Title: Real Curve Crypto
Category: Elliptic Curves
Stage: Parameter Choice 2
Challenge ID: real_curves
Points: 200
