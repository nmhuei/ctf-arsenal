Title: Checkpoint
Category: Elliptic Curves
Stage: Parameter Choice 2
Challenge ID: checkpoint
Points: 150
