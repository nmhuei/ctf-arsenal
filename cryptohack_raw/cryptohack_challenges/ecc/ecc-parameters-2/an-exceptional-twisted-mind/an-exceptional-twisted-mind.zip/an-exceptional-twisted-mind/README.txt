Title: An Exceptional Twisted Mind
Category: Elliptic Curves
Stage: Parameter Choice 2
Challenge ID: exceptional_twisted_mind
Points: 125
