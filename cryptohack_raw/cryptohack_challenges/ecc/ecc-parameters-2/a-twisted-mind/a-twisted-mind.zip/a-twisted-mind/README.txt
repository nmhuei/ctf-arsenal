Title: A Twisted Mind
Category: Elliptic Curves
Stage: Parameter Choice 2
Challenge ID: twisted_mind
Points: 80
