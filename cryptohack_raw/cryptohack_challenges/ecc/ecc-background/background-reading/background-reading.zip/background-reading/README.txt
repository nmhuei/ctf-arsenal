Title: Background Reading
Category: Elliptic Curves
Stage: Background
Challenge ID: bg
Points: 5
