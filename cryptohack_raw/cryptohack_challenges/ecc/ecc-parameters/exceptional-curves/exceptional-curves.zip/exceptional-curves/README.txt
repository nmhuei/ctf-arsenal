Title: Exceptional Curves
Category: Elliptic Curves
Stage: Parameter Choice
Challenge ID: exceptional
Points: 100
