Title: Elliptic Nodes
Category: Elliptic Curves
Stage: Parameter Choice
Challenge ID: node
Points: 150
