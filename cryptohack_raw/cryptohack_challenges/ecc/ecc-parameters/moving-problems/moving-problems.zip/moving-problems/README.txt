Title: Moving Problems
Category: Elliptic Curves
Stage: Parameter Choice
Challenge ID: moving
Points: 150
