Title: Micro Transmissions
Category: Elliptic Curves
Stage: Parameter Choice
Challenge ID: micro
Points: 120
