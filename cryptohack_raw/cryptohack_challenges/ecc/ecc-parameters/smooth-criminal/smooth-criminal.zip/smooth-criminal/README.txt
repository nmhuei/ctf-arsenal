Title: Smooth Criminal
Category: Elliptic Curves
Stage: Parameter Choice
Challenge ID: criminal
Points: 60
