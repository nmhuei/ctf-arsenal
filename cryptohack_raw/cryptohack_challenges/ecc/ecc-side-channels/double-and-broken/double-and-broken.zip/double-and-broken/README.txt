Title: Double and Broken
Category: Elliptic Curves
Stage: Side Channels
Challenge ID: double_and_broken
Points: 50
