Title: Montgomery's Ladder
Category: Elliptic Curves
Stage: Side Channels
Challenge ID: ladder
Points: 40
