Title: Scalar Multiplication
Category: Elliptic Curves
Stage: Starter
Challenge ID: ecc2
Points: 35
