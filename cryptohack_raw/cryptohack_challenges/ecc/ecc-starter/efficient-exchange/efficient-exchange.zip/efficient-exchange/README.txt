Title: Efficient Exchange
Category: Elliptic Curves
Stage: Starter
Challenge ID: ecc4
Points: 50
