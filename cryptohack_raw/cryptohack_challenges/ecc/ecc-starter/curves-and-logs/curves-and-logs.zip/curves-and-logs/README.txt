Title: Curves and Logs
Category: Elliptic Curves
Stage: Starter
Challenge ID: ecc3
Points: 40
