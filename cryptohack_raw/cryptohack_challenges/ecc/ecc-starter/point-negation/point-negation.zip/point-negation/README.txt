Title: Point Negation
Category: Elliptic Curves
Stage: Starter
Challenge ID: ecc0
Points: 10
