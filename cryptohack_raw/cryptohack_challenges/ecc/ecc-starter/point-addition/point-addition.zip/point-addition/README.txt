Title: Point Addition
Category: Elliptic Curves
Stage: Starter
Challenge ID: ecc1
Points: 30
