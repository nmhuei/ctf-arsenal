Title: Digestive
Category: Elliptic Curves
Stage: Signatures
Challenge ID: digestive
Points: 60
