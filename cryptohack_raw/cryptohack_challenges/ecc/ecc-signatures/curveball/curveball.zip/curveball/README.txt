Title: Curveball
Category: Elliptic Curves
Stage: Signatures
Challenge ID: curveball
Points: 100
