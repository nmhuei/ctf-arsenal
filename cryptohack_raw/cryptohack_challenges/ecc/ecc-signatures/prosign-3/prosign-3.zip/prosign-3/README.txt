Title: ProSign 3
Category: Elliptic Curves
Stage: Signatures
Challenge ID: ps3
Points: 100
