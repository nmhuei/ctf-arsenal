Title: No Random, No Bias
Category: Elliptic Curves
Stage: Signatures
Challenge ID: norandom
Points: 120
