Title: Hex
Category: General
Stage: Encoding
Challenge ID: enc2
Points: 5
