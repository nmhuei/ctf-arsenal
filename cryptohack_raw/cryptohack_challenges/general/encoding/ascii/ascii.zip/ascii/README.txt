Title: ASCII
Category: General
Stage: Encoding
Challenge ID: enc1
Points: 5
