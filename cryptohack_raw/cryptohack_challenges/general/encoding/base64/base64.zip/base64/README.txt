Title: Base64
Category: General
Stage: Encoding
Challenge ID: enc3
Points: 10
