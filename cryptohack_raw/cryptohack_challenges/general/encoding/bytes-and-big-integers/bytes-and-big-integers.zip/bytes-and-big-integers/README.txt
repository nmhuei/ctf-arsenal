Title: Bytes and Big Integers
Category: General
Stage: Encoding
Challenge ID: enc4
Points: 10
