Title: Encoding Challenge
Category: General
Stage: Encoding
Challenge ID: enc_interactive
Points: 40
