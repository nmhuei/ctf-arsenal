Title: SSH Keys
Category: General
Stage: Data Formats
Challenge ID: ssh-keys
Points: 35
