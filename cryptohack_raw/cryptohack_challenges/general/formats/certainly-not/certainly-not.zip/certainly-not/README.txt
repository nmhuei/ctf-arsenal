Title: CERTainly not
Category: General
Stage: Data Formats
Challenge ID: certainly
Points: 30
