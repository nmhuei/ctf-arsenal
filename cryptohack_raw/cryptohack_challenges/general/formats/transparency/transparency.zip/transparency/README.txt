Title: Transparency
Category: General
Stage: Data Formats
Challenge ID: transparency
Points: 50
