Title: XOR Starter
Category: General
Stage: XOR
Challenge ID: xor0
Points: 10
