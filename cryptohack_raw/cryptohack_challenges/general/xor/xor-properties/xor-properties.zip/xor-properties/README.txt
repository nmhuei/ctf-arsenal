Title: XOR Properties
Category: General
Stage: XOR
Challenge ID: xor1
Points: 15
