Title: You either know, XOR you don't
Category: General
Stage: XOR
Challenge ID: xorkey1
Points: 30
