Title: Lemur XOR
Category: General
Stage: XOR
Challenge ID: xorimg1
Points: 40
