Title: Favourite byte
Category: General
Stage: XOR
Challenge ID: xorkey0
Points: 20
