Title: Modular Arithmetic 1
Category: General
Stage: Mathematics
Challenge ID: ma0
Points: 20
