Title: Modular Arithmetic 2
Category: General
Stage: Mathematics
Challenge ID: ma1
Points: 20
