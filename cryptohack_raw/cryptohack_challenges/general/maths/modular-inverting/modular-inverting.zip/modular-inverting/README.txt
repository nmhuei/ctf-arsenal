Title: Modular Inverting
Category: General
Stage: Mathematics
Challenge ID: mdiv
Points: 25
