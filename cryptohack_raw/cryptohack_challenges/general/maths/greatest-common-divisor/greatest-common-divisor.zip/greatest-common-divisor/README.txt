Title: Greatest Common Divisor
Category: General
Stage: Mathematics
Challenge ID: gcd
Points: 15
