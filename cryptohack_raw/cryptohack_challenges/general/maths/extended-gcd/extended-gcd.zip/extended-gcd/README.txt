Title: Extended GCD
Category: General
Stage: Mathematics
Challenge ID: egcd
Points: 20
