Title: MDFlag
Category: Hash Functions
Stage: Length Extension
Challenge ID: mdflag
Points: 125
