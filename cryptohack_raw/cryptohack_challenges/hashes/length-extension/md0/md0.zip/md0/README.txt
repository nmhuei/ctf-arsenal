Title: MD0
Category: Hash Functions
Stage: Length Extension
Challenge ID: md0
Points: 80
