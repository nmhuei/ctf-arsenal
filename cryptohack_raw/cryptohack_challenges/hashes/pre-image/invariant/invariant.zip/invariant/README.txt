Title: Invariant
Category: Hash Functions
Stage: Pre-image attacks
Challenge ID: invariant
Points: 250
