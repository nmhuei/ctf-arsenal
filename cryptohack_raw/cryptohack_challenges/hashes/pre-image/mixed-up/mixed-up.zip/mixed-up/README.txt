Title: Mixed Up
Category: Hash Functions
Stage: Pre-image attacks
Challenge ID: mixed_up
Points: 120
