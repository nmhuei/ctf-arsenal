Title: WOTS Up
Category: Hash Functions
Stage: Hash-based Cryptography
Challenge ID: wots_up-ecsc_2023_norway2023
Points: 75
