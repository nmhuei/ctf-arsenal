Title: WOTS Up 2
Category: Hash Functions
Stage: Hash-based Cryptography
Challenge ID: wots_up_2-ecsc_2023_norway202
Points: 90
