Title: Merkle Trees
Category: Hash Functions
Stage: Hash-based Cryptography
Challenge ID: merkletrees
Points: 25
