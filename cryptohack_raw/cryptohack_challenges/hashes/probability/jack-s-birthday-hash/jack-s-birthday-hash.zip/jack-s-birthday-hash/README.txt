Title: Jack's Birthday Hash
Category: Hash Functions
Stage: Probability
Challenge ID: birthday1
Points: 20
