Title: Jack's Birthday Confusion
Category: Hash Functions
Stage: Probability
Challenge ID: birthday2
Points: 30
