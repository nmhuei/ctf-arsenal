Title: PriMeD5
Category: Hash Functions
Stage: Collisions
Challenge ID: primed5
Points: 100
