Title: Collider
Category: Hash Functions
Stage: Collisions
Challenge ID: collider
Points: 50
