Title: Twin Keys
Category: Hash Functions
Stage: Collisions
Challenge ID: twinkeys
Points: 100
