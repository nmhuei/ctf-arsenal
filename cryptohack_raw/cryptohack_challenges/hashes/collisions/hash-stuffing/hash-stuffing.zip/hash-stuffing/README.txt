Title: Hash Stuffing
Category: Hash Functions
Stage: Collisions
Challenge ID: stuffing
Points: 50
