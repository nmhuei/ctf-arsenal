Title: No Difference
Category: Hash Functions
Stage: Collisions
Challenge ID: no_difference
Points: 175
